from afterglow.parsing.tokenizer import (
    block_end,
    closing as find_closing,
    header_end,
    next_arm,
    number,
    split,
    tokenize,
)

STEPS = 4000
TRIPS = 300


class Unknown:

    def __repr__(self):
        return "unknown"


UNKNOWN = Unknown()


class Slot(Unknown):

    __slots__ = ("table", "index", "origin")

    def __init__(self, table, index, origin=None):
        self.table = table
        self.index = index
        self.origin = origin

    def __repr__(self):
        return f"{self.table}[{self.index!r}]"


class Table:

    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return f"table:{self.name}"


class Value:

    __slots__ = ("number", "origin")

    def __init__(self, value, origin=None):
        self.number = value
        self.origin = origin

    def __repr__(self):
        return f"{self.number}"


class Text:

    __slots__ = ("text", "origin")

    def __init__(self, text, origin=None):
        self.text = text
        self.origin = origin

    def __repr__(self):
        return repr(self.text)


BINARY = {"+": "ADD", "-": "SUB", "*": "MUL", "/": "DIV", "%": "MOD", "^": "POW", "..": "CONCAT"}


class Binary(Unknown):
    """An operation on two things that did not reduce to a number.

    Giving up here and calling the result unknown is what loses the arithmetic
    in an instruction this VM splits across dispatch steps: the step that
    computes `a + b` holds it in one of the interpreter's own locals, and only
    a later step writes it to a register. Keeping the shape until then is what
    lets that write still say what it added.
    """

    __slots__ = ("operator", "left", "right")

    def __init__(self, operator, left, right):
        self.operator = operator
        self.left = left
        self.right = right

    def __repr__(self):
        return f"({self.left!r} {self.operator} {self.right!r})"


class Write:

    __slots__ = ("holder", "key", "value")

    def __init__(self, holder, key, value):
        self.holder = holder
        self.key = key
        self.value = value

    def __repr__(self):
        return f"{self.holder}[{self.key!r}] = {self.value!r}"


class Stop(Exception):
    pass


class BreakSignal(Exception):
    pass


def run(tokens, names, pools, counter, at):
    machine = Machine(names, pools, counter, at)
    try:
        machine.block(tokens)
    except BreakSignal:
        pass
    return machine.writes, machine.names, machine.calls


class Machine:
    def __init__(self, names, pools, counter, at):
        self.names = dict(names)
        self.names[counter] = Value(at)
        self.pools = pools
        self.counter = counter
        self.writes = []
        self.calls = []
        self.steps = 0

    def block(self, tokens):
        at = 0
        while at < len(tokens):
            self.steps += 1
            if self.steps > STEPS:
                raise Stop("runaway")
            after = self.statement(tokens, at)
            if after <= at:
                raise Stop("no progress")
            at = after

    def statement(self, tokens, at):
        token = tokens[at]
        if token.is_("operator", ";"):
            return at + 1
        if token.kind == "keyword":
            if token.text == "if":
                return self.branch(tokens, at)
            if token.text in ("while", "repeat"):
                return self.loop(tokens, at)
            if token.text == "break":
                raise BreakSignal()
            if token.text == "for":
                return self.counted(tokens, at)
            if token.text in ("local", "then", "else", "end", "until", "do"):
                return at + 1
            raise Stop(token.text)
        return self.assignment(tokens, at)

    def assignment(self, tokens, at):
        stop = self.statement_end(tokens, at)
        equals = self.assignment_at(tokens, at, stop)
        if equals is None:
            return self.declaration(tokens, at, stop)
        target = self.place(tokens, at, equals)
        value, after = self.expression(tokens, equals + 1)
        if isinstance(target, str):
            self.names[target] = value
        else:
            self.writes.append(Write(target[0], target[1], value))
        return max(after, equals + 1)

    def declaration(self, tokens, at, stop):
        opening = next(
            (index for index in range(at, stop) if tokens[index].is_("operator", "(")), None
        )
        if opening is not None and stop > opening and tokens[stop - 1].is_("operator", ")"):
            called, _ = self.expression(tokens[at:opening], 0)
            arguments = self.parts(tokens[opening + 1 : stop - 1])
            count = 0 if len(arguments) == 1 and not arguments[0] else len(arguments)
            self.calls.append((called, count))
            return stop
        for index in range(at, stop):
            token = tokens[index]
            if token.kind == "name":
                self.names[token.text] = None
            elif not token.is_("operator", ","):
                raise Stop("not a declaration")
        return stop

    def place(self, tokens, at, equals):
        left = list(tokens[at:equals])
        if len(left) == 1 and left[0].kind == "name":
            return left[0].text
        opening = last_index(left)
        if opening is None:
            raise Stop("unreadable target")
        holder, _ = self.expression(left[:opening], 0)
        index, _ = self.expression(left[opening + 1 : len(left) - 1], 0)
        return holder, helper_key(index)

    def branch(self, tokens, at):
        end = helper_end(tokens, at + 1)
        index = at
        while True:
            then = helper_header(tokens, index + 1, "then")
            condition, _ = self.expression(tokens[index + 1 : then], 0)
            if vague(condition):
                raise Stop("branch on something not known")
            following = next_arm(tokens, then + 1, end)
            if true(condition):
                self.block(tokens[then + 1 : following if following is not None else end])
                break
            if following is None:
                break
            if tokens[following].is_("keyword", "else"):
                self.block(tokens[following + 1 : end])
                break
            index = following
        return end + 1

    def loop(self, tokens, at):
        repeating = tokens[at].is_("keyword", "repeat")
        opening = at if repeating else helper_header(tokens, at + 1, "do")
        end = helper_end(tokens, opening + 1)
        body = tokens[opening + 1 : end]
        test = tokens[at + 1 : opening] if not repeating else tokens[end + 1 :]

        after = end + 1
        try:
            while True:
                self.steps += 1
                if self.steps > STEPS:
                    raise Stop("runaway loop")
                if not repeating:
                    condition, _ = self.expression(test, 0)
                    if vague(condition):
                        raise Stop("loop on something not known")
                    if not true(condition):
                        break
                self.block(body)
                if repeating:
                    condition, after = self.expression(tokens, end + 1)
                    if true(condition):
                        break
        except BreakSignal:
            if repeating:
                _, after = self.expression(tokens, end + 1)
        return after

    def counted(self, tokens, at):
        do = helper_header(tokens, at + 1, "do")
        end = helper_end(tokens, do + 1)
        header = tokens[at + 1 : do]
        if len(header) < 3 or header[0].kind != "name" or not header[1].is_("operator", "="):
            raise Stop("not a counted loop")

        bounds = [self.expression(part, 0)[0] for part in split(header[2:])]
        if len(bounds) not in (2, 3) or not all(isinstance(bound, Value) for bound in bounds):
            raise Stop("loop bounds are not known")
        start, stop = bounds[0].number, bounds[1].number
        step = bounds[2].number if len(bounds) == 3 else 1
        if step == 0 or (stop - start) / step > TRIPS:
            raise Stop("too far round")

        name, body = header[0].text, tokens[do + 1 : end]
        try:
            index = start
            while (index <= stop) if step > 0 else (index >= stop):
                self.steps += 1
                if self.steps > STEPS:
                    raise Stop("runaway loop")
                self.names[name] = Value(index)
                self.block(body)
                index += step
        except BreakSignal:
            pass
        return end + 1

    def parts(self, tokens):
        parts, depth, cut = [], 0, 0
        for index, token in enumerate(tokens):
            if token.kind != "operator":
                continue
            if token.text in "([{":
                depth += 1
            elif token.text in ")]}":
                depth -= 1
            elif token.text == "," and depth == 0:
                parts.append(tokens[cut:index])
                cut = index + 1
        parts.append(tokens[cut:])
        return parts

    def expression(self, tokens, at):
        value, at = self.conjunction(tokens, at)
        while self.matches(tokens, at, "keyword", "or"):
            right, at = self.conjunction(tokens, at + 1)
            if vague(value):
                value = UNKNOWN
            elif not true(value):
                value = right
        return value, at

    def conjunction(self, tokens, at):
        value, at = self.comparison(tokens, at)
        while self.matches(tokens, at, "keyword", "and"):
            right, at = self.comparison(tokens, at + 1)
            if vague(value):
                value = UNKNOWN
            elif true(value):
                value = right
        return value, at

    def comparison(self, tokens, at):
        left, at = self.sum(tokens, at)
        while (
            at < len(tokens)
            and tokens[at].kind == "operator"
            and tokens[at].text in ("==", "~=", "<", "<=", ">", ">=")
        ):
            operator = tokens[at].text
            right, at = self.sum(tokens, at + 1)
            left = compare(operator, left, right)
        return left, at

    def sum(self, tokens, at):
        left, at = self.product(tokens, at)
        while (
            at < len(tokens)
            and tokens[at].kind == "operator"
            and tokens[at].text in ("+", "-", "..")
        ):
            operator = tokens[at].text
            right, at = self.product(tokens, at + 1)
            left = arithmetic(operator, left, right)
        return left, at

    def product(self, tokens, at):
        left, at = self.unary(tokens, at)
        while (
            at < len(tokens)
            and tokens[at].kind == "operator"
            and tokens[at].text in ("*", "/", "%")
        ):
            operator = tokens[at].text
            right, at = self.unary(tokens, at + 1)
            left = arithmetic(operator, left, right)
        return left, at

    def unary(self, tokens, at):
        if at < len(tokens) and tokens[at].is_("operator", "-"):
            value, at = self.unary(tokens, at + 1)
            return (Value(-value.number) if isinstance(value, Value) else UNKNOWN), at
        if self.matches(tokens, at, "keyword", "not"):
            value, at = self.unary(tokens, at + 1)
            return (UNKNOWN if vague(value) else not true(value)), at
        if at < len(tokens) and tokens[at].is_("operator", "#"):
            _, at = self.unary(tokens, at + 1)
            return UNKNOWN, at
        return self.power(tokens, at)

    def power(self, tokens, at):
        left, at = self.primary(tokens, at)
        if at < len(tokens) and tokens[at].is_("operator", "^"):
            right, at = self.unary(tokens, at + 1)
            return arithmetic("^", left, right), at
        return left, at

    def primary(self, tokens, at):
        if at >= len(tokens):
            raise Stop("ran out of expression")
        token = tokens[at]

        if token.kind == "number":
            return Value(number(token.text)), at + 1
        if token.kind == "string":
            return UNKNOWN, at + 1
        if token.kind == "keyword" and token.text in ("true", "false", "nil"):
            return {"true": True, "false": False, "nil": None}[token.text], at + 1
        if token.is_("operator", "{"):
            return UNKNOWN, require_closing(tokens, at) + 1
        if token.is_("operator", "("):
            end = require_closing(tokens, at)
            value, _ = self.expression(tokens[at + 1 : end], 0)
            return self.suffixes(tokens, end + 1, value)
        if token.kind == "name":
            if token.text not in self.names:
                if at + 1 >= len(tokens) or not tokens[at + 1].is_("operator", "["):
                    raise Stop(f"{token.text} is not known here")
                self.names[token.text] = Table(token.text)
            return self.suffixes(tokens, at + 1, self.names[token.text])
        raise Stop(f"unexpected {token.text}")

    def suffixes(self, tokens, at, value):
        while at < len(tokens) and tokens[at].is_("operator", "["):
            end = require_closing(tokens, at)
            index, _ = self.expression(tokens[at + 1 : end], 0)
            value = self.read(value, index)
            at = end + 1
        if (
            at < len(tokens)
            and tokens[at].kind == "operator"
            and tokens[at].text in ("(", ".", ":")
        ):
            raise Stop("a call")
        return value, at

    def read(self, holder, index):
        key = helper_key(index)
        if key is None or not isinstance(holder, (Table, Slot)):
            return UNKNOWN
        where = holder.name if isinstance(holder, Table) else holder
        if isinstance(holder, Table):
            found = self.pools.get(holder.name, {}).get(str(key))
            if isinstance(found, (int, float)) and not isinstance(found, bool):
                return Value(found, (holder.name, key))
            if isinstance(found, str) and not found.startswith("<"):
                return Text(found, (holder.name, key))
        origin = index.origin if isinstance(index, (Value, Text)) else None
        return Slot(where, key, origin)

    def matches(self, tokens, at, kind, text):
        return at < len(tokens) and tokens[at].kind == kind and tokens[at].text == text

    def statement_end(self, tokens, at):
        depth = 0
        for index in range(at, len(tokens)):
            token = tokens[index]
            if token.kind == "operator":
                if token.text in "([{":
                    depth += 1
                elif token.text in ")]}":
                    depth -= 1
                elif token.text == ";" and depth <= 0:
                    return index
            elif token.kind == "keyword" and depth <= 0:
                return index
        return len(tokens)

    def assignment_at(self, tokens, at, stop):
        depth = 0
        for index in range(at, stop):
            token = tokens[index]
            if token.kind != "operator":
                continue
            if token.text in "([{":
                depth += 1
            elif token.text in ")]}":
                depth -= 1
            elif token.text == "=" and depth == 0:
                return index
            elif token.text == "," and depth == 0:
                raise Stop("more than one target")
        return None


def last_index(tokens):
    if not tokens or not tokens[-1].is_("operator", "]"):
        return None
    depth = 0
    for index in range(len(tokens) - 1, -1, -1):
        token = tokens[index]
        if token.kind != "operator":
            continue
        if token.text in ")]}":
            depth += 1
        elif token.text in "([{":
            depth -= 1
            if depth == 0:
                return index if token.text == "[" else None
    return None


def require_closing(tokens, start):
    found = find_closing(tokens, start)
    if found is None:
        raise Stop("unbalanced")
    return found


def helper_end(tokens, at):
    found = block_end(tokens, at)
    if found is None:
        raise Stop("no end")
    return found


def helper_header(tokens, at, text):
    found = header_end(tokens, at, text)
    if found is None:
        raise Stop("no " + text)
    return found


def helper_key(value):
    if isinstance(value, Text):
        return value.text
    if not isinstance(value, Value):
        return None
    try:
        whole = float(value.number).is_integer()
    except (OverflowError, ValueError):
        return None
    return int(value.number) if whole else value.number


def vague(value):
    return isinstance(value, Unknown)


def true(value):
    return value is not False and value is not None and not vague(value)


def helper_same(left, right):
    if isinstance(left, Text) and isinstance(right, Text):
        return left.text == right.text
    return left is right


def arithmetic(operator, left, right):
    if not isinstance(left, Value) or not isinstance(right, Value):
        return shaped(operator, left, right)
    a, b = left.number, right.number
    try:
        if operator == "+":
            return Value(a + b)
        if operator == "-":
            return Value(a - b)
        if operator == "*":
            return Value(a * b)
        if operator == "/":
            return Value(a / b) if b else UNKNOWN
        if operator == "%":
            return Value(a % b) if b else UNKNOWN
        if operator == "^":
            return Value(a**b) if abs(b) < 1024 and abs(a) < 2**64 else UNKNOWN
    except (OverflowError, ZeroDivisionError, ValueError):
        return UNKNOWN
    return UNKNOWN


def shaped(operator, left, right):
    """What was operated on, when what came out is not a number."""
    if operator not in BINARY:
        return UNKNOWN
    if not all(isinstance(side, (Slot, Value, Text)) for side in (left, right)):
        return UNKNOWN
    return Binary(operator, left, right)


def compare(operator, left, right):
    if vague(left) or vague(right):
        return UNKNOWN
    if not isinstance(left, Value) or not isinstance(right, Value):
        if operator not in ("==", "~="):
            return UNKNOWN
        same = helper_same(left, right)
        return same if operator == "==" else not same
    a, b = left.number, right.number
    return {"==": a == b, "~=": a != b, "<": a < b, "<=": a <= b, ">": a > b, ">=": a >= b}[
        operator
    ]


REGISTERS = 256


class Reader:

    def __init__(self, bodies, register, streams, dispatch, pools=()):
        self.handlers = {op: tokenize(body) for op, body in bodies.items()}
        self.register = register
        self.counter = dispatch["counter"]
        self.variable = dispatch["variable"]
        self.globals = dispatch.get("globals")
        self.code = dispatch.get("code")
        self.pools = set(pools)
        named = set(streams) | self.pools | {register}
        named.update(name for name in (self.code, self.globals) if name)
        self.tables = {name: Table(name) for name in named}
        self.carried = None

    def read(self, op, pc, pools, function=None):
        tokens = self.handlers.get(op)
        if tokens is None:
            self.carried = None
            return None
        names = dict(self.tables)
        if self.carried and self.carried[0] == (function, pc - 1):
            names.update(self.carried[1])
        names[self.variable] = Value(op)
        try:
            writes, left, calls = run(tokens, names, pools, self.counter, pc)
        except Stop:
            self.carried = None
            return None
        self.carried = ((function, pc), left) if not writes else None
        return self.describe(writes, left.get(self.counter), pc, calls)

    def describe(self, writes, counter, pc, calls=()):
        moved = counter.number if isinstance(counter, Value) and counter.number != pc else None
        found = self.effect(writes) or self.called(calls)
        if found is None and moved is not None:
            found = {"name": "JMP", "roles": {}}
        if found is not None and moved is not None:
            found["counter"] = moved
        return found

    def called(self, calls):
        for value, arguments in reversed(calls):
            function = self.into(value)
            if function is not None:
                return {"name": "CALL", "roles": {"function": function, "arguments": arguments}}
        return None

    def effect(self, writes):
        cleared = self.cleared(writes)
        if cleared is not None:
            return cleared
        for write in reversed(writes):
            found = (
                self.through(write) if self.into(write.holder) is not None else self.stored(write)
            )
            if found is not None:
                return found
        return None

    def cleared(self, writes):
        touched = set()
        for write in writes:
            if not isinstance(write.holder, Table) or write.holder.name != self.register:
                return None
            if write.value is not None or helper_register(write.key) is None:
                return None
            touched.add(helper_register(write.key))
        if not touched:
            return None
        whole = max(touched) - min(touched) + 1 == len(touched)
        return {
            "name": "LOADNIL",
            "roles": {"target": min(touched), "through": max(touched) if whole else min(touched)},
        }

    def into(self, holder):
        if isinstance(holder, Slot) and holder.table == self.register:
            return helper_register(holder.index)
        return None

    def stored(self, write):
        if isinstance(write.holder, Slot) and write.holder.table in self.pools:
            source = self.into(write.value) if isinstance(write.value, Slot) else None
            roles = {
                "pool": write.holder.table,
                "table": write.holder.index,
                "table_kind": "POOL",
            }
            if source is not None:
                roles["from"] = source
            found = {"name": "SETTABLE", "roles": roles}
            keyed(found, write.key)
            if isinstance(write.value, bool):
                roles["value"] = write.value
            elif isinstance(write.value, (Text, Value)):
                roles["value"] = literal(write.value)
            return found
        if not isinstance(write.holder, Table):
            return None
        name = write.holder.name
        if name == self.globals:
            source = self.into(write.value) if isinstance(write.value, Slot) else None
            roles = {"from": source} if source is not None else {}
            return (
                {"name": "SETGLOBAL", "roles": roles, "constant": write.key}
                if isinstance(write.key, str)
                else None
            )
        if name != self.register or helper_register(write.key) is None:
            return None
        return self.loaded(helper_register(write.key), write.value)

    def loaded(self, target, value):
        roles = {"target": target}
        if isinstance(value, Binary):
            return self.computed(target, value) or {"roles": roles}
        if isinstance(value, bool):
            return {"name": "LOADBOOL", "roles": dict(roles, value=value)}
        if isinstance(value, Text):
            return {"name": "LOADK", "roles": roles, "constant": value.text}
        if isinstance(value, Value):
            return {"name": "LOADN", "roles": dict(roles, value=value.number)}
        if isinstance(value, Table):
            return {"name": "JUNK", "roles": roles}
        if value is None:
            return {"name": "LOADNIL", "roles": roles}
        if isinstance(value, Slot):
            through = self.into(value)
            if through is not None:
                return {"name": "MOVE", "roles": {**roles, "from": through}}
            if value.table == self.globals and isinstance(value.index, str):
                return {"name": "GETGLOBAL", "roles": roles, "constant": value.index}
            if value.table in self.pools:
                return {"name": "LOADK", "roles": dict(roles, **{"from": value.index})}
            inner = self.into(value.table) if isinstance(value.table, Slot) else None
            if inner is not None:
                found = {"name": "GETTABLE", "roles": dict(roles, table=inner)}
                keyed(found, value.index)
                return found
            if isinstance(value.table, Slot) and value.table.origin is None and value.origin:
                return {"name": "GETUPVAL", "roles": dict(roles, **{"from": value.index})}
        return {"roles": roles}

    def computed(self, target, value):
        roles = {"target": target}
        for side, operand in (("left", value.left), ("right", value.right)):
            if isinstance(operand, Slot):
                where = self.into(operand)
                if where is None:
                    return None
                roles[side] = where
            elif isinstance(operand, Value):
                roles[side] = operand.number
                roles[side + "_kind"] = "NUM"
            else:
                return None
        return {"name": BINARY[value.operator], "roles": roles}

    def through(self, write):
        roles = {"table": self.into(write.holder)}
        source = self.into(write.value) if isinstance(write.value, Slot) else None
        if source is not None:
            roles["from"] = source
        found = {"name": "SETTABLE", "roles": roles}
        keyed(found, write.key)
        if isinstance(write.value, bool):
            roles["value"] = write.value
        elif isinstance(write.value, (Text, Value)):
            roles["value"] = literal(write.value)
        return found


def keyed(found, key):
    if isinstance(key, str):
        found["constant"] = key
    elif isinstance(key, (int, float)) and not isinstance(key, bool):
        found["roles"]["key"] = key


def literal(value):
    return value.text if isinstance(value, Text) else value.number


def helper_register(key):
    if isinstance(key, bool) or not isinstance(key, (int, float)):
        return None
    return int(key) if 0 <= key < REGISTERS and float(key).is_integer() else None
