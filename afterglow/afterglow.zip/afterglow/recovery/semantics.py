MIN_OBSERVATIONS = 3

ENCODINGS = {
    "absolute": lambda value, pc: value,
    "next": lambda value, pc: value + 1,
    "relative": lambda value, pc: pc + value,
    "relative-next": lambda value, pc: pc + value + 1,
}


def jumps(taken, functions):
    operands = {
        (function["id"], instruction["pc"]): instruction["operands"]
        for function in functions
        for instruction in function["instructions"]
    }
    votes = {}
    for jump in taken:
        found = operands.get((jump["function"], jump["pc"]))
        if not found:
            continue
        for slot, value in found.items():
            for encoding, decode in ENCODINGS.items():
                if decode(value, jump["pc"]) != jump["went_to"]:
                    continue
                for who in (jump["function"], None):
                    scores = votes.setdefault((who, jump["op"]), {})
                    key = (slot, encoding)
                    scores[key] = scores.get(key, 0) + 1

    return {key: max(scores, key=lambda vote: scores[vote]) for key, scores in votes.items()}


JUMP_OBSERVATIONS = 8


def jump_kinds(effects):
    """Opcodes named by what they did to the counter rather than by their code.

    Watching the registers cannot name these: they never touch one. Watching
    where control went next can. An opcode seen moving the counter and never
    seen writing a register is a jump; one that moves it only sometimes has a
    test behind it, which is worth saying even when what the test reads is
    not recoverable — a branch reported as unconditional is a lie, but a
    branch reported as a branch is the truth as far as it goes.
    """
    moved, stayed, wrote = {}, {}, set()
    for effect in effects:
        op = effect["op"]
        if effect["changed"]:
            wrote.add(op)
        where = stayed if effect["next_pc"] == effect["pc"] + 1 else moved
        where[op] = where.get(op, 0) + 1

    found = {}
    for op, times in moved.items():
        if op in wrote or times + stayed.get(op, 0) < JUMP_OBSERVATIONS:
            continue
        found[op] = "JMP" if not stayed.get(op) else "JMPIF"
    return found


def transitions(taken):
    return {(jump["function"], jump["pc"]): jump["went_to"] for jump in taken}


def encoding(jump_slots):
    votes = {}
    for slot, name in jump_slots.values():
        votes[name] = votes.get(name, 0) + 1
    return max(votes, key=lambda name: votes[name]) if votes else None


def landing(value, pc, name):
    if name in ("absolute", "relative"):
        return value
    return value + 1


def target(instruction, jump_slots, function=None):
    found = jump_slots.get((function, instruction["op"])) or jump_slots.get(
        (None, instruction["op"])
    )
    if not found:
        return None
    slot, encoding = found
    if slot not in instruction["operands"]:
        return None
    return ENCODINGS[encoding](instruction["operands"][slot], instruction["pc"])


def global_names(loads):
    """Where a register was seen taking a global, and which global it was.

    The VM reports some loads a step after the instruction that made them, so
    each sighting also speaks for the instruction before it — but only where
    that one was not seen loading a global of its own. A guess must not
    displace a sighting.
    """
    found, guessed = {}, {}
    for load in loads:
        value = load["value"]
        if not (value.startswith("<global ") and value.endswith(">")):
            continue
        name = value[len("<global ") : -1]
        found[(load.get("function"), load["pc"])] = name
        guessed.setdefault((load.get("function"), load["pc"] - 1), name)
    for where, name in guessed.items():
        found.setdefault(where, name)
    return found


def loaded_constants(loads, register=None, effects=(), recent=()):
    seen = {}
    for load in loads:
        value = load.get("value")
        if not isinstance(value, str) or value.startswith("<global "):
            continue
        if register is not None and not load.get("reg", "").startswith(register + "["):
            continue
        seen.setdefault((load.get("function"), load["pc"]), set()).add(value)
    for effect in list(effects) + list(recent):
        changed = effect.get("changed") or []
        if len(changed) == 1:
            name, tagged = changed[0].get("register", ""), changed[0].get("after")
        else:
            name, tagged = effect.get("register", ""), effect.get("after")
        if register is not None and not name.startswith(register + "["):
            continue
        value = scalar_tag(tagged)
        if value is not None:
            seen.setdefault((effect.get("function"), effect["pc"]), set()).add(value)
    return {where: next(iter(values)) for where, values in seen.items() if len(values) == 1}


def scalar_tag(tagged):
    if not isinstance(tagged, str):
        return None
    kind, _, value = tagged.partition(":")
    if kind == "s":
        return value
    if kind == "b":
        return value == "true"
    if kind != "n":
        return None
    try:
        number = float(value)
    except ValueError:
        return None
    return int(number) if number.is_integer() else number


def pool_constants(observed, pools=()):
    pools = set(pools or ())
    seen = {}
    for entry in observed:
        if pools and entry.get("name") not in pools:
            continue
        where = (entry.get("function"), entry.get("index"))
        seen.setdefault(where, set()).add((type(entry.get("value")).__name__, entry.get("value")))
    return {
        where: next(iter(values))[1]
        for where, values in seen.items()
        if len(values) == 1
    }


def constant_slots(loads, effects, functions):
    pools = {function["id"]: function.get("pools") or {} for function in functions}
    opcodes = {
        (function["id"], instruction["pc"]): instruction["op"]
        for function in functions
        for instruction in function["instructions"]
    }

    votes = {}
    for load in witnessed(loads, effects):
        function = load.get("function")
        for pc in (load["pc"], load["pc"] - 1):
            opcode = opcodes.get((function, pc))
            if opcode is None:
                continue
            for slot, pool in (pools.get(function) or {}).items():
                if pool.get(str(pc)) == load["value"]:
                    votes.setdefault(opcode, {})
                    votes[opcode][slot] = votes[opcode].get(slot, 0) + 1
    return {op: max(scores, key=lambda slot: scores[slot]) for op, scores in votes.items()}


def witnessed(loads, effects):
    for load in loads:
        yield load
    for effect in effects:
        changed = effect.get("changed")
        after = changed[0]["after"] if changed and len(changed) == 1 else effect.get("after")
        if after is None:
            continue
        kind, _, rest = after.partition(":")
        if kind not in ("n", "s"):
            continue
        yield {
            "function": effect["function"],
            "pc": effect["pc"],
            "op": effect["op"],
            "value": float(rest) if kind == "n" else rest,
        }


def destinations(writes, traced):
    operands = helper_operands(traced)
    watched = {}
    for write in writes:
        instruction = operands.get((write["function"], write["pc"]))
        if not instruction:
            continue
        table, _, index = write["register"].partition("[")
        watched.setdefault(write["op"], []).append(
            {"index": int(index.rstrip("]")), "operands": instruction}
        )

    found = {}
    for op, observations in watched.items():
        if len(observations) < MIN_OBSERVATIONS:
            continue
        slot = helper_destination(observations)
        if slot:
            found[op] = {"destination": slot}
    return found


def infer(effects, traced):
    operands = helper_operands(traced)
    watched = helper_watched(effects, operands)

    inferred = {}
    for op, observations in watched.items():
        if len(observations) < MIN_OBSERVATIONS:
            continue
        facts = {}
        destination = helper_destination(observations)
        if destination:
            facts["destination"] = destination
        name = helper_name(observations)
        if name:
            facts["name"] = name
        if facts:
            inferred[op] = facts
    return inferred


def helper_operands(traced):
    return {
        (function["id"], instruction["pc"]): instruction["operands"]
        for function in traced
        for instruction in function["code"]
    }


def helper_watched(effects, operands):
    watched = {}
    for effect in effects:
        if len(effect["changed"]) != 1:
            continue
        instruction = operands.get((effect["function"], effect["pc"]))
        if not instruction:
            continue
        register = effect["changed"][0]["register"]
        table, _, index = register.partition("[")
        watched.setdefault(effect["op"], []).append(
            {
                "index": int(index.rstrip("]")),
                "value": helper_value(effect["changed"][0]["after"]),
                "before": {key: helper_value(tag) for key, tag in effect["before"].items()},
                "table": table,
                "operands": instruction,
            }
        )
    return watched


def helper_value(tag):
    kind, _, rest = tag.partition(":")
    if kind == "n":
        return float(rest)
    if kind == "s":
        return rest
    if kind == "b":
        return rest == "true"
    if kind == "z":
        return None
    return ObservedObject(kind)


class ObservedObject:

    def __init__(self, kind):
        self.kind = kind

    def __eq__(self, other):
        return False


def helper_destination(observations):
    slots = set(observations[0]["operands"])
    for observation in observations:
        slots &= {
            slot for slot, value in observation["operands"].items() if value == observation["index"]
        }
        if not slots:
            return None
    return sorted(slots)[0]


def helper_name(observations):
    for name, fits in (("CONCAT", concat), ("MOVE", move), ("LOADNIL", nil)):
        if all(fits(observation) for observation in observations):
            return name
    return None


def helper_registers(observation):
    prefix = observation["table"] + "["
    return {
        int(key[len(prefix) : -1]): value
        for key, value in observation["before"].items()
        if key.startswith(prefix)
    }


def helper_sources(observation):
    registers = helper_registers(observation)
    return [registers[value] for value in observation["operands"].values() if value in registers]


def concat(observation):
    if not isinstance(observation["value"], str):
        return False
    sources = [source for source in helper_sources(observation) if isinstance(source, str)]
    return any(a + b == observation["value"] for a in sources for b in sources)


def move(observation):
    value = observation["value"]
    if value is None or isinstance(value, ObservedObject):
        return False
    return any(source == value for source in helper_sources(observation))


def nil(observation):
    return observation["value"] is None
