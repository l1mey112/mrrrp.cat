from afterglow.parsing.tokenizer import number, tokenize

BINARY = {"+": "ADD", "-": "SUB", "*": "MUL", "/": "DIV", "%": "MOD", "^": "POW", "..": "CONCAT"}
COMPARE = {"==": "EQ", "~=": "NE", "<": "LT", "<=": "LE", ">": "GT", ">=": "GE"}
UNARY = {"-": "UNM", "#": "LEN", "not": "NOT"}


def tables(bodies, counter):
    streams, indexed = set(), {}
    for body in bodies.values():
        tokens = tokenize(body)
        for i, token in enumerate(tokens):
            if reads_at(tokens, i, counter):
                streams.add(token.text)
                if i >= 2 and tokens[i - 1].is_("operator", "[") and tokens[i - 2].kind == "name":
                    name = tokens[i - 2].text
                    indexed[name] = indexed.get(name, 0) + 1
    if not indexed:
        return None, streams, set()
    register = max(indexed, key=lambda name: indexed[name])
    return register, streams, {name for name in indexed if name != register}


def globals_pool(bodies, register, counter):
    """The table the handlers read globals out of and write them back into.

    It is shaped exactly like the register file -- `j[R[O]]`, a table indexed
    by what a stream holds -- so counting how often each candidate appears
    cannot separate them, and ranking by rarity picks whichever scratch local
    happened to be indexed once.

    What does separate it is that a VM needs both directions. The globals
    table is the only one read in value position *and* assigned through, so
    requiring both leaves the real one standing. Two shapes are excluded
    first: the register file, and any table whose element is indexed again
    (`_[h[O]][l[O]]`), which makes it a table of tables -- upvalues, not
    globals.
    """
    reads, writes = {}, {}
    for body in bodies.values():
        tokens = tokenize(body)
        for i, token in enumerate(tokens):
            if token.kind != "name" or token.text == register:
                continue
            if not (
                i + 1 < len(tokens)
                and tokens[i + 1].is_("operator", "[")
                and reads_at(tokens, i + 2, counter)
            ):
                continue

            after = tokens[i + 7] if i + 7 < len(tokens) else None
            if after is not None and after.is_("operator", "["):
                continue
            side = writes if (after is not None and after.is_("operator", "=")) else reads
            side[token.text] = side.get(token.text, 0) + 1

    both = [name for name in reads if name in writes]
    if not both:
        return None
    return max(both, key=lambda name: reads[name] + writes[name])


def reads_at(tokens, i, counter):
    return (
        tokens[i].kind == "name"
        and i + 3 < len(tokens)
        and tokens[i + 1].is_("operator", "[")
        and tokens[i + 2].is_("name", counter)
        and tokens[i + 3].is_("operator", "]")
    )


def bare(tokens):
    changed = True
    while changed:
        changed = False
        for i, token in enumerate(tokens):
            if not token.is_("operator", "("):
                continue
            if i > 0 and (
                tokens[i - 1].kind in ("name", "string")
                or tokens[i - 1].is_("operator", "]")
                or tokens[i - 1].is_("operator", ")")
            ):
                continue
            close = helper_closing(tokens, i)
            if close is not None and is_value(tokens, i + 1, close):
                tokens = tokens[:i] + tokens[i + 1 : close] + tokens[close + 1 :]
                changed = True
                break
    return tokens


def helper_closing(tokens, start):
    depth = 0
    for i in range(start, len(tokens)):
        if tokens[i].kind == "operator" and tokens[i].text in "([":
            depth += 1
        elif tokens[i].kind == "operator" and tokens[i].text in ")]":
            depth -= 1
            if depth == 0:
                return i if tokens[i].text == ")" else None
    return None


def is_value(tokens, start, stop):
    if start >= stop or tokens[start].kind != "name":
        return False
    i = start + 1
    while i < stop:
        if not tokens[i].is_("operator", "["):
            return False
        depth = 0
        while i < stop:
            if tokens[i].kind == "operator" and tokens[i].text in "([":
                depth += 1
            elif tokens[i].kind == "operator" and tokens[i].text in ")]":
                depth -= 1
                if depth == 0:
                    i += 1
                    break
            i += 1
        else:
            return False
    return True


class Atom:

    __slots__ = ("kind", "name", "stream")

    def __init__(self, kind, name=None, stream=None):
        self.kind = kind
        self.name = name
        self.stream = stream

    def __repr__(self):
        return f"{self.kind}({self.name},{self.stream})"

    def is_op(self, text):
        return self.kind == "OP" and self.name == text


def helper_atoms(tokens, register, counter):
    atoms = []
    i, n = 0, len(tokens)
    while i < n:
        token = tokens[i]
        if token.kind == "name" and i + 1 < n and tokens[i + 1].is_("operator", "["):
            inner = i + 2
            if (
                reads_at(tokens, inner, counter)
                and inner + 4 < n
                and tokens[inner + 4].is_("operator", "]")
            ):
                kind = "REG" if token.text == register else "POOL"
                atoms.append(Atom(kind, token.text, tokens[inner].text))
                i = inner + 5
                continue
            if (
                tokens[inner].is_("name", counter)
                and inner + 1 < n
                and tokens[inner + 1].is_("operator", "]")
            ):
                atoms.append(Atom("IMM", token.text))
                i = inner + 2
                continue
        if token.kind == "number":
            atoms.append(Atom("NUM", number(token.text)))
        elif token.kind == "keyword" and token.text == "nil":
            atoms.append(Atom("NIL"))
        elif token.kind == "keyword" and token.text in ("true", "false"):
            atoms.append(Atom("BOOL", token.text == "true"))
        elif token.kind == "name":
            atoms.append(Atom("NAME", token.text))
        else:
            atoms.append(Atom("OP", token.text))
        i += 1
    return atoms


def helper_statements(atoms):
    statements, current = [], []
    for atom in atoms:
        if atom.is_op(";"):
            if current:
                statements.append(current)
            current = []
        else:
            current.append(atom)
    if current:
        statements.append(current)
    return statements


def instruction(body, register, counter, globals_pool=None, interpreter=()):
    if not body.strip():

        return {"name": "NOP", "operands": {}}
    statements = helper_statements(helper_atoms(bare(tokenize(body)), register, counter))
    found = returned(statements)
    if found:
        return found
    found = closure(statements)
    if found:
        return found
    found = tforloop(statements, register, counter)
    if found:
        return found
    for statement in statements:
        found = helper_self(statement, register)
        if found:
            return found
    for statement in statements:
        found = call(statement, statements, register)
        if found:
            return found
    found = fill_or_copy(statements, register, counter)
    if found:
        return found
    for statement in statements:
        found = junk(statement, interpreter)
        if found:
            return found
    found = setlist(statements, register, counter)
    if found:
        return found
    for statement in statements:
        found = shape(trimmed(statement), statements, counter, globals_pool)
        if found:
            return jump_kind(found, statements, counter) if found["name"] == "JMP" else found
    return micro(statements, register, counter)


def tforloop(statements, register, counter):
    """A generic iterator call whose successful results enter registers."""
    base_name, base_stream = None, None
    for statement in statements:
        if (
            len(statement) == 3
            and statement[0].kind == "NAME"
            and statement[1].is_op("=")
            and statement[2].kind == "IMM"
        ):
            base_name, base_stream = statement[0].name, statement[2].name
            break
    if base_name is None:
        return None
    returned = []
    for statement in statements:
        equals = next((i for i, atom in enumerate(statement) if atom.is_op("=")), None)
        if equals is None or not any(atom.is_op("(") for atom in statement[equals + 1 :]):
            continue
        returned = [atom.name for atom in statement[:equals] if atom.kind == "NAME"]
        if len(returned) >= 2:
            break
    if len(returned) < 2:
        return None
    offsets = set()
    for statement in statements:
        for at in range(len(statement) - 7):
            part = statement[at : at + 8]
            if (
                part[0].kind == "NAME"
                and part[0].name == register
                and part[1].is_op("[")
                and part[2].kind == "NAME"
                and part[2].name == base_name
                and part[3].is_op("+")
                and part[4].kind == "NUM"
                and part[5].is_op("]")
                and part[6].is_op("=")
                and part[7].kind == "NAME"
                and part[7].name in returned
            ):
                offsets.add(int(part[4].name))
    if not offsets or offsets != set(range(1, max(offsets) + 1)):
        return None
    jump = None
    for statement in statements:
        if (
            len(statement) == 3
            and statement[0].kind == "NAME"
            and statement[0].name == counter
            and statement[1].is_op("=")
            and statement[2].kind == "IMM"
        ):
            jump = statement[2].name
            break
    if jump is None:
        return None
    return {
        "name": "TFORLOOP",
        "operands": {
            "target": base_stream,
            "count": max(offsets),
            "to": jump,
        },
    }


def setlist(statements, register, counter):
    """A run of registers copied into a table.

    The container reaches for `table.move` once at startup and keeps it in a
    numbered slot, so filling a table from consecutive registers reads as a
    bare call into that slot: `q[5](J,R+1,R+W[u],_+1,G)`, with `R` the base
    register, `W[u]` how many, and `G` the table the base register holds.
    Nothing else in the interpreter hands the whole register file to a helper
    alongside a range computed out of it, and a run of the payload confirms
    which function it is -- the step is seen calling `table.move`.
    """
    for statement in statements:
        if assignment_at(statement) is not None:
            continue
        arguments = handed(statement)
        if arguments is None or len(arguments) != 5:
            continue
        if (
            len(arguments[0]) != 1
            or arguments[0][0].kind != "NAME"
            or arguments[0][0].name != register
        ):
            continue
        base = from_stream(statements, arguments[1][0])
        count = next((atom.name for atom in arguments[2] if atom.kind == "IMM"), None)
        if base is None or count is None:
            continue
        operands = {"target": base, "count": count}
        offset = from_stream(statements, arguments[3][0])
        if offset is not None:
            operands["offset"] = offset
        return {"name": "SETLIST", "operands": operands}
    return None


def handed(statement):
    """The arguments of a call into one of the interpreter's numbered slots."""
    if (
        len(statement) < 7
        or statement[0].kind != "NAME"
        or not statement[1].is_op("[")
        or statement[2].kind != "NUM"
        or not statement[3].is_op("]")
        or not statement[4].is_op("(")
        or not statement[-1].is_op(")")
    ):
        return None
    arguments, current, depth = [], [], 0
    for atom in statement[5:-1]:
        if atom.kind == "OP":
            if atom.name in "([":
                depth += 1
            elif atom.name in ")]":
                depth -= 1
            elif atom.name == "," and depth == 0:
                arguments.append(current)
                current = []
                continue
        current.append(atom)
    arguments.append(current)
    return arguments if all(arguments) else None


def trimmed(statement):
    depth, cut = 0, 0
    for i, atom in enumerate(statement):
        if atom.kind == "OP":
            if atom.name in "([":
                depth += 1
            elif atom.name in ")]":
                depth -= 1
            elif depth == 0 and atom.name in ("then", "do", "else", "repeat"):
                cut = i + 1
    return statement[cut:]


INVERSE = {
    "==": "~=",
    "~=": "==",
    "<": ">=",
    "<=": ">",
    ">": "<=",
    ">=": "<",
    "true": "false",
    "false": "true",
}


def helper_condition(statements, counter):
    for statement in statements:
        for i, atom in enumerate(statement):
            if not (atom.kind == "OP" and atom.name == "if"):
                continue
            test = read_test(until_then(statement[i + 1 :]))
            if not test:
                continue
            if counter is not None and jumps_in_else(statement[i + 1 :], counter):
                return dict(test, test=INVERSE.get(test["test"], test["test"]))
            return test
    return None


def jumps_in_else(atoms, counter):
    depth, past_else = 0, False
    for index, atom in enumerate(atoms):
        if (
            atom.kind == "NAME"
            and atom.name == counter
            and index + 1 < len(atoms)
            and atoms[index + 1].is_op("=")
        ):
            return past_else
        if atom.kind != "OP":
            continue
        if atom.name in ("if", "while", "for", "function"):
            depth += 1
        elif atom.name == "end":
            depth = max(0, depth - 1)
        elif atom.name == "else" and depth == 0:
            past_else = True
    return False


def until_then(atoms):
    for i, atom in enumerate(atoms):
        if atom.kind == "OP" and atom.name == "then":
            return atoms[:i]
    return atoms


def read_test(atoms):
    negated = False
    while True:
        atoms = unwrapped(atoms)
        if not (atoms and atoms[0].kind == "OP" and atoms[0].name == "not"):
            break
        negated = not negated
        atoms = atoms[1:]

    if len(atoms) == 3 and atoms[1].kind == "OP" and atoms[1].name in COMPARE:
        operator = atoms[1].name if negated else INVERSE[atoms[1].name]
        return {
            "test": operator,
            "left": atoms[0].stream or atoms[0].name,
            "left_kind": atoms[0].kind,
            "right": atoms[2].stream or atoms[2].name,
            "right_kind": atoms[2].kind,
        }
    if len(atoms) == 1 and atoms[0].kind in ("REG", "POOL"):
        return {
            "test": "true" if negated else "false",
            "left": atoms[0].stream,
            "left_kind": atoms[0].kind,
        }
    return None


def jump_kind(jump, statements, counter):
    tests = any(
        atom.kind == "OP" and atom.name in ("if", "while")
        for statement in statements
        for atom in statement
    )
    writes = any(statement and statement[0].kind == "REG" for statement in statements)
    if not tests:
        return jump
    operands = dict(jump["operands"])
    condition = helper_condition(statements, counter)
    if condition:
        operands.update(condition)
    return {"name": "FORLOOP" if writes else "JMPIF", "operands": operands}


def fill_or_copy(statements, register, counter):
    atoms = [atom for statement in statements for atom in statement]
    if not any(atom.kind == "OP" and atom.name == "for" for atom in atoms):
        return None
    touches_registers = any(
        (atom.kind == "REG") or (atom.kind == "NAME" and atom.name == register) for atom in atoms
    )
    if not touches_registers:
        return None
    if any(atom.kind == "NIL" for atom in atoms):
        bounds = [atom.name for atom in atoms if atom.kind == "IMM"]

        operands = {"from": bounds[0], "through": bounds[1]} if len(bounds) >= 2 else {}
        return {"name": "LOADNIL", "operands": operands}
    if fills_registers(statements, register):
        return {"name": "VARARG", "operands": counted_from(statements)}
    return None


def fills_registers(statements, register):
    """Whether a counted loop is what copies the varargs into the registers.

    Plenty of handlers run a loop without being one — the one that builds a
    closure walks its upvalues the same way — so the loop has to be seen
    writing the register file before its bounds mean anything.
    """
    for statement in statements:
        seen = False
        for index, atom in enumerate(statement):
            if atom.is_op("for"):
                seen = True
                continue
            if not (seen and atom.kind == "NAME" and atom.name == register):
                continue
            if index + 1 >= len(statement) or not statement[index + 1].is_op("["):
                continue
            if assigned_after(statement, index + 1):
                return True
    return False


def assigned_after(statement, opening):
    """Whether what follows is written to, rather than only read."""
    depth = 0
    for atom in statement[opening:]:
        if atom.kind != "OP":
            continue
        if atom.name in "([":
            depth += 1
        elif atom.name in ")]":
            depth -= 1
        elif atom.name == "=" and depth == 0:
            return True
    return False


def counted_from(statements):
    """The register a loop over the register file starts writing at.

    Both shapes this VM uses say it in the loop header — `for n=1,O[P]` counts
    from a fixed register, `for V=k,k+(a[P]-1)` from one an earlier step read
    out of a stream.
    """
    for statement in statements:
        for i, atom in enumerate(statement):
            if not atom.is_op("for") or i + 3 >= len(statement):
                continue
            if not statement[i + 2].is_op("="):
                continue
            header = statement[i + 3 :]
            start = until_comma(header)
            if len(start) != 1:
                continue
            found = helper_bound(statements, start[0])
            if found is None:
                continue
            operands = dict(found)

            last = helper_bound(statements, helper_stop(header))
            if last is not None:
                operands.update({"through" + key[6:]: value for key, value in last.items()})
            return operands
    return {}


def helper_bound(statements, atom):
    if atom is None:
        return None
    if atom.kind == "NUM":
        return {"target": atom.name, "target_kind": "NUM"}
    if atom.kind == "IMM":
        return {"target": atom.name}
    if atom.kind == "NAME":
        stream = from_stream(statements, atom)
        if stream is not None:
            return {"target": stream}
    return None


def helper_stop(header):
    """The loop's upper bound, when it is a single thing."""
    rest = header[len(until_comma(header)) + 1 :]
    for index, atom in enumerate(rest):
        if atom.is_op("do"):
            rest = rest[:index]
            break
    return rest[0] if len(rest) == 1 else None


def until_comma(atoms):
    depth = 0
    for i, atom in enumerate(atoms):
        if atom.kind != "OP":
            continue
        if atom.name in "([":
            depth += 1
        elif atom.name in ")]":
            depth -= 1
        elif atom.name == "," and depth == 0:
            return atoms[:i]
    return atoms


def micro(statements, register, counter):
    wrote_local = False
    for statement in statements:
        at = assignment_at(statement)
        if at is None:
            return None
        target = statement[:at]
        if len(target) == 1 and target[0].kind == "NAME" and target[0].name == counter:
            return None
        if len(target) == 1 and target[0].kind == "NAME":
            wrote_local = True
            continue
        if (
            len(target) == 3
            and target[0].kind == "NAME"
            and target[1].is_op("[")
            and target[2 - 1].kind == "NAME"
        ):
            return {"name": "STORE", "operands": {}}
        if target and target[0].kind == "NAME" and target[1].is_op("["):
            return {"name": "STORE", "operands": {}}
        return None
    return {"name": "SETUP", "operands": {}} if wrote_local else None


def returns(statement):
    return bool(statement) and statement[0].kind == "OP" and statement[0].name == "return"


def returned(statements):
    statement = next((part for part in statements if returns(part)), None)
    if statement is None:
        return None
    values = [atom for atom in statement[1:] if not atom.is_op(",")]
    if not values:
        return {"name": "RETURN", "operands": {}}
    if values[0].kind == "BOOL":
        values = values[1:]
    if not values:
        return {"name": "RETURN", "operands": {}}

    bindings = {}
    for part in statements:
        at = assignment_at(part)
        if at == 1 and part[0].kind == "NAME" and len(part) == 3:
            bindings[part[0].name] = part[2]
    source = values[0]
    if source.kind == "NAME":
        source = bindings.get(source.name, source)
    if source.kind != "IMM":
        return {"name": "RETURN", "operands": {}}

    operands = {"from": source.name}
    last = values[-1]
    if last.kind == "NUM" and last.name == 0:
        operands["count"] = -1
    elif last.kind == "NUM" and last.name >= 1:
        operands["count"] = int(last.name) - 1
    elif len(values) >= 2 and values[-1].kind == "NAME" and values[-1].name == values[0].name:
        operands["count"] = 1
    return {"name": "RETURN", "operands": operands}


def makes_closure(statement):
    return any(atom.kind == "OP" and atom.name == "function" for atom in statement)


def closure(statements):
    if not any(makes_closure(statement) for statement in statements):
        return None
    for statement in reversed(statements):
        at = assignment_at(statement)
        if at is None or at == 0:
            continue
        target = statement[0]
        if target.kind == "REG":
            return {"name": "CLOSURE", "operands": {"target": target.stream}}
    return {"name": "CLOSURE", "operands": {}}


def helper_self(statement, register):
    at = assignment_at(statement)
    if at is None or at < 5:
        return None
    target = statement[:at]
    if not (target[0].kind == "NAME" and target[0].name == register):
        return None
    if not (target[1].is_op("[") and target[-1].is_op("]")):
        return None
    return (
        {"name": "SELF", "operands": {}}
        if any(atom.kind == "OP" and atom.name == "+" for atom in target)
        else None
    )


def junk(statement, interpreter):
    at = assignment_at(statement)
    if at is None:
        return None
    target, rest = statement[:at], unwrapped(statement[at + 1 :])
    if (
        len(target) == 1
        and target[0].kind == "REG"
        and len(rest) == 1
        and rest[0].kind == "NAME"
        and rest[0].name in interpreter
    ):
        return {"name": "JUNK", "operands": {"target": target[0].stream}}
    return None


def call(statement, statements, register):
    for i, atom in enumerate(statement):
        if atom.kind == "REG" and i + 1 < len(statement) and statement[i + 1].is_op("("):
            return called(statement, i + 1, atom.stream)
        named = (
            atom.kind == "NAME"
            and atom.name == register
            and i + 4 < len(statement)
            and statement[i + 1].is_op("[")
            and statement[i + 3].is_op("]")
            and statement[i + 4].is_op("(")
        )
        if named:
            return called(statement, i + 4, from_stream(statements, statement[i + 2]))
    return None


def called(statement, opening, function):
    operands = {"function": function, "results": 1 if assignment_at(statement) else 0}
    count = arity(statement, opening)
    if count is not None:
        operands["arguments"] = count
    return {"name": "CALL", "operands": operands}


def arity(statement, opening):
    closing = None
    depth = 0
    for i in range(opening, len(statement)):
        atom = statement[i]
        if atom.kind != "OP":
            continue
        if atom.name in "([":
            depth += 1
        elif atom.name in ")]":
            depth -= 1
            if depth == 0:
                closing = i
                break
    if closing is None:
        return None
    inside = statement[opening + 1 : closing]
    if not inside:
        return 0
    if any(atom.is_op("(") for atom in inside):
        return None
    depth, count = 0, 1
    for atom in inside:
        if atom.kind != "OP":
            continue
        if atom.name in "([":
            depth += 1
        elif atom.name in ")]":
            depth -= 1
        elif atom.name == "," and depth == 0:
            count += 1
    return count


def from_stream(statements, atom):
    if atom.kind != "NAME":
        return None
    for statement in statements:
        if (
            len(statement) >= 3
            and statement[0].kind == "NAME"
            and statement[0].name == atom.name
            and statement[1].is_op("=")
            and statement[2].kind == "IMM"
        ):
            return statement[2].name
    return None


def assignment_at(statement):
    depth = 0
    for i, atom in enumerate(statement):
        if atom.kind == "OP":
            if atom.name in "([":
                depth += 1
            elif atom.name in ")]":
                depth -= 1
            elif atom.name == "=" and depth == 0:
                return i
    return None


def unwrapped(atoms):
    while len(atoms) >= 2 and atoms[0].is_op("(") and atoms[-1].is_op(")"):
        atoms = atoms[1:-1]
    return atoms


def shape(statement, statements, counter, globals_pool):
    at = assignment_at(statement)
    if at is None:
        return None
    target, rest = statement[:at], unwrapped(statement[at + 1 :])
    if not rest:
        return None

    if len(target) == 1 and target[0].kind == "NAME" and target[0].name == counter:
        source = rest[0]
        if source.kind == "IMM":
            return {"name": "JMP", "operands": {"to": source.name}}
        if source.kind == "NAME" and source.name == counter:
            return {"name": "JMP", "operands": {"by": helper_offset(rest)}}
        return None

    if len(target) == 1 and target[0].kind == "POOL" and target[0].name == globals_pool:

        if len(rest) == 1 and rest[0].kind == "REG":
            return {
                "name": "SETGLOBAL",
                "operands": {"from": rest[0].stream, "key": target[0].stream},
            }
        if len(rest) == 1 and rest[0].kind in ("IMM", "NUM"):

            operands = {"key": target[0].stream}
            operands.update(helper_operand("from", rest[0]))
            return {"name": "SETGLOBAL", "operands": operands}
        return None

    if len(target) != 1 or target[0].kind != "REG":
        if len(target) > 1:
            base = target[0]
            slotted = numbered(target)
            if slotted is not None and slotted[0] == "[" and len(rest) == 1:
                source = rest[0]
                if source.kind == "REG":
                    return {
                        "name": "SETUPVAL",
                        "operands": {"from": source.stream, "upvalue": slotted[1]},
                    }
            if base.kind == "REG":
                operands = {"table": base.stream}
                if rest[0].kind == "BOOL":
                    operands["value"] = rest[0].name
                elif rest[0].kind in ("IMM", "NUM"):

                    operands.update(helper_operand("from", rest[0]))
                else:
                    operands["from"] = rest[0].stream or rest[0].name
                operands.update(helper_operand("key", subscript(target)))
                return {"name": "SETTABLE", "operands": operands}
            if len(rest) == 1 and rest[0].kind == "REG":
                store = "SETGLOBAL" if pooled(statements, base) is not None else "SETTABLE"
                return {"name": store, "operands": {"from": rest[0].stream}}
        return None
    target = target[0]

    if len(rest) == 1:
        source = rest[0]
        if source.kind == "NIL":
            return made("LOADNIL", target.stream)
        if source.kind == "BOOL":
            return {"name": "LOADBOOL", "operands": {"target": target.stream, "value": source.name}}
        if source.kind == "IMM":

            return {
                "name": "LOADK",
                "operands": {"target": target.stream, "from": source.name, "from_kind": "IMM"},
            }
        if source.kind == "REG":
            return made("MOVE", target.stream, source.stream)
        if source.kind == "POOL":
            name = "GETGLOBAL" if source.name == globals_pool else "LOADK"
            return made(name, target.stream, source.stream)
        if source.kind == "NUM":
            return {"name": "LOADN", "operands": {"target": target.stream, "value": source.name}}
        if source.kind == "NAME" and source.name == globals_pool:
            return made("GETFENV", target.stream)
        if source.kind == "NAME" and from_call(statements, source):

            return made("CLOSURE", target.stream)

    if len(rest) == 2 and rest[0].is_op("{") and rest[1].is_op("}"):
        return made("NEWTABLE", target.stream)

    if len(rest) == 3 and rest[1].kind == "OP":
        left, right = rest[0], rest[2]
        named = BINARY.get(rest[1].name) or COMPARE.get(rest[1].name)
        values = ("REG", "POOL", "IMM", "NUM")
        if named and left.kind in values and right.kind in values:
            return {
                "name": named,
                "operands": {
                    "target": target.stream,
                    "left": left.stream or left.name,
                    "left_kind": left.kind,
                    "right": right.stream or right.name,
                    "right_kind": right.kind,
                },
            }

    if len(rest) == 2 and rest[0].kind == "OP" and rest[0].name in UNARY:
        return made(UNARY[rest[0].name], target.stream, rest[1].stream or rest[1].name)

    if rest[0].kind == "NAME" and len(rest) > 1 and rest[1].is_op("["):
        holder = pooled(statements, rest[0])
        if holder is not None:
            return made("GETUPVAL", target.stream, holder or None)

    if rest[0].kind in ("REG", "POOL") and len(rest) > 1 and rest[1].is_op("["):
        operands = {"target": target.stream, "table": rest[0].stream}
        operands.update(helper_operand("key", subscript(rest)))
        return {"name": "GETTABLE", "operands": operands}

    slotted = numbered(rest)
    if slotted is not None:
        opening, operand = slotted
        if opening == "(":

            return {"name": "NEWTABLE", "operands": {"target": target.stream, "size": operand}}

        return made("GETUPVAL", target.stream, operand)
    return None


def numbered(rest):
    """`q[15][W[u]]` or `q[15](W[u])`: one of the interpreter's numbered slots
    reached with a raw operand. Returns which bracket and the stream."""
    if (
        len(rest) != 7
        or rest[0].kind != "NAME"
        or not rest[1].is_op("[")
        or rest[2].kind != "NUM"
        or not rest[3].is_op("]")
        or rest[5].kind != "IMM"
    ):
        return None
    for opening, closing in (("(", ")"), ("[", "]")):
        if rest[4].is_op(opening) and rest[6].is_op(closing):
            return opening, rest[5].name
    return None


def subscript(atoms):
    if len(atoms) < 4 or not atoms[1].is_op("[") or not atoms[-1].is_op("]"):
        return None
    inner = atoms[2:-1]
    return inner[0] if len(inner) == 1 else None


def helper_operand(role, atom):
    if atom is None or atom.kind not in ("REG", "IMM", "POOL", "NUM"):
        return {}
    if atom.kind == "NUM":
        return {role: atom.name, role + "_kind": "NUM"}
    return {role: atom.stream or atom.name, role + "_kind": atom.kind}


def helper_offset(rest):
    if len(rest) == 3 and rest[1].kind == "OP" and rest[2].kind == "NUM":
        return rest[2].name if rest[1].name == "+" else -rest[2].name
    return None


def made(name, target, source=None):
    operands = {"target": target}
    if source is not None:
        operands["from"] = source
    return {"name": name, "operands": operands}


def from_call(statements, atom):
    """Whether a local this handler set was filled in by calling something."""
    for statement in statements:
        if (
            len(statement) < 3
            or statement[0].kind != "NAME"
            or statement[0].name != atom.name
            or not statement[1].is_op("=")
        ):
            continue
        if any(later.is_op("(") for later in statement[2:]):
            return True
    return False


def pooled(statements, atom):
    """The stream a local was read from, if it came out of one of the VM's pools.

    Returns None when it did not; the empty string when it did but through no
    stream this instruction names.
    """
    if atom.kind != "NAME":
        return None
    for statement in statements:
        if (
            len(statement) >= 3
            and statement[0].kind == "NAME"
            and statement[0].name == atom.name
            and statement[1].is_op("=")
            and statement[2].kind == "POOL"
        ):
            return statement[2].stream or ""
    return None


FRAGMENT_BLOCKERS = (
    "if",
    "elseif",
    "else",
    "then",
    "for",
    "while",
    "repeat",
    "until",
    "do",
    "end",
    "function",
    "return",
    "break",
    "local",
    "goto",
    "in",
)
FRAGMENTS = ("SETUP", "STORE")


def fuse(bodies, register, counter, globals_pool=None, interpreter=()):
    """One operation spread over a run of instructions.

    Luraph splits a register move into three opcodes and passes the pieces
    through the interpreter's own locals: one caches the register file, the
    next reads the operands, the last does the store. Read one at a time none
    of them is an instruction -- `R=(J);` says nothing at all. Substituting
    the locals back puts the operation together again, and then it lifts like
    any other handler.

    Returns the lifted instruction and, for each stream it reads, which member
    of the run read it. That matters: the operands are in that instruction's
    row, not the first one's.
    """
    joined = inlined(bodies, register, counter, interpreter)
    if joined is None:
        return None, {}
    found = instruction(joined, register, counter, globals_pool, interpreter)
    if not found or not found["name"] or found["name"] in FRAGMENTS + ("NOP",):
        return None, {}
    where = {}
    for index, body in enumerate(bodies):
        for stream in helper_reads(body, counter):
            where.setdefault(stream, index)
    return found, where


def inlined(bodies, register, counter, interpreter):
    """A run of handlers with the interpreter's own locals substituted back.

    Only plain assignments are followed. A handler that branches or loops is
    doing something on its own and is not a piece of anything.
    """
    bound, kept = {}, []
    for body in bodies:
        tokens = tokenize(body)
        if not tokens or any(
            token.kind == "keyword" and token.text in FRAGMENT_BLOCKERS for token in tokens
        ):
            return None
        for statement in split(tokens):
            at = equals_at(statement)
            if not at:
                return None
            target, source = statement[:at], statement[at + 1 :]
            if any(token.is_("operator", ",") for token in target):
                return None
            filled = substituted(source, bound)
            if (
                len(target) == 1
                and target[0].kind == "name"
                and target[0].text not in interpreter
                and target[0].text not in (counter, register)
            ):
                bound[target[0].text] = "(" + filled + ")"
                continue
            kept.append(substituted(target, bound) + "=" + filled)
    if not kept:
        return None
    return ";".join(kept) + ";"


def substituted(tokens, bound):
    return " ".join(
        bound.get(token.text, token.text) if token.kind == "name" else token.text
        for token in tokens
    )


def split(tokens):
    """A handler's statements, by the semicolons between them."""
    lines, current, depth = [], [], 0
    for token in tokens:
        if token.kind == "operator":
            if token.text in "([":
                depth += 1
            elif token.text in ")]":
                depth -= 1
            elif token.text == ";" and depth == 0:
                if current:
                    lines.append(current)
                current = []
                continue
        current.append(token)
    if current:
        lines.append(current)
    return lines


def equals_at(tokens):
    depth = 0
    for index, token in enumerate(tokens):
        if token.kind != "operator":
            continue
        if token.text in "([":
            depth += 1
        elif token.text in ")]":
            depth -= 1
        elif token.text == "=" and depth == 0:
            return index
    return None


def helper_reads(body, counter):
    """The streams a handler indexes with the program counter."""
    tokens = tokenize(body)
    return {tokens[index].text for index in range(len(tokens)) if reads_at(tokens, index, counter)}
