import operator

from afterglow.generation import disassembler as disasm

from . import control_flow as structure

TESTS = {
    "==": operator.eq,
    "~=": operator.ne,
    "<": operator.lt,
    "<=": operator.le,
    ">": operator.gt,
    ">=": operator.ge,
}

LOADS = ("LOADK", "LOADN")

BRANCHES = ("JMP", "JMPIF")

RANGES = {"LOADNIL": ("target", "through"), "VARARG": ("target", "through")}

SIDES = ("left", "right")

READS = ("from", "table", "function", "left", "right")

OPAQUE = ("JUNK", "SETUP", "STORE")

PURE = (
    "LOADK",
    "LOADN",
    "LOADNIL",
    "LOADBOOL",
    "MOVE",
    "GETGLOBAL",
    "GETUPVAL",
    "NEWTABLE",
    "GETFENV",
    "GETTABLE",
    "ADD",
    "SUB",
    "MUL",
    "DIV",
    "MOD",
    "POW",
    "UNM",
    "NOT",
    "LEN",
    "CONCAT",
    "EQ",
    "NE",
    "LT",
    "LE",
    "GT",
    "GE",
)

ROUNDS = 8

INDEXED = ("GETTABLE", "SETTABLE", "SELF")

POOL_KEYS = 5

POOL_AGREEMENT = 0.9


class Missing:
    pass


MISSING = Missing()


def annotated(instructions, executed, pools, globals_at=()):
    if not instructions or not pools:
        return instructions
    out = []
    for number, body in by_function(instructions):
        out.extend(annotate_body(body, executed.get(number, ()), pools, globals_at))
    return out


def by_function(instructions):
    groups, order = {}, []
    for instruction in instructions:
        number = instruction["function"]
        if number not in groups:
            groups[number] = []
            order.append(number)
        groups[number].append(instruction)
    return [(number, groups[number]) for number in order]


def annotate_body(body, executed, pools, globals_at):
    bound = helper_bound(body, pools)
    blocks = structure.basic_blocks(body)
    graph = structure.flow(blocks)
    entry, reached = propagate(blocks, graph, executed, bound)

    out = []
    for number, block in enumerate(blocks):
        values = dict(entry[number]) if number in reached else {}
        for instruction in block["instructions"]:
            out.append(named(instruction, values, bound, globals_at))
            step(instruction, values, bound)
    return out


def helper_bound(body, pools):
    used = {}
    for instruction in body:
        if instruction["name"] != "GETTABLE":
            continue
        roles = instruction.get("roles") or {}
        key = literal(roles, instruction)
        table = roles.get("table")
        if table is None or not isinstance(key, (int, float)) or isinstance(key, bool):
            continue
        used.setdefault(int(table), set()).add(int(key))

    bound = {}
    for register, keys in used.items():
        if len(keys) < POOL_KEYS:
            continue
        fit, pool = max(
            ((len(keys & set(pool)) / len(keys), pool) for pool in pools.values()),
            key=lambda scored: (scored[0], -len(scored[1])),
        )
        if fit >= POOL_AGREEMENT:
            bound[register] = pool
    return bound


def literal(roles, instruction):
    if roles.get("key_kind") not in ("IMM", "NUM", "POOL"):
        return None
    constant = instruction.get("constant")
    if isinstance(constant, str):
        return constant
    return roles.get("key")


def helper_key(instruction, values):
    roles = instruction.get("roles") or {}
    if roles.get("key_kind") == "REG" and roles.get("key") is not None:
        return values.get(int(roles["key"]), None)
    found = literal(roles, instruction)
    if found is None and isinstance(instruction.get("constant"), str):
        return instruction["constant"]
    return found


def helper_fetched(instruction, values, bound):
    roles = instruction.get("roles") or {}
    table = roles.get("table")
    if table is None or int(table) not in bound:
        return MISSING
    key = helper_key(instruction, values)
    if key is None:
        return MISSING
    return bound[int(table)].get(key)


def named(instruction, values, bound, globals_at):
    if instruction["name"] not in INDEXED:
        return instruction
    if instruction["name"] == "GETTABLE":
        found = helper_fetched(instruction, values, bound)
        if found is not MISSING:
            resolved = helper_constant(instruction, found, globals_at)
            if resolved is not instruction:
                return resolved
    key = helper_key(instruction, values)
    if not isinstance(key, str):
        return marked(instruction, bound)
    roles = {
        name: value
        for name, value in (instruction.get("roles") or {}).items()
        if name not in ("key", "key_kind")
    }
    found = dict(instruction, roles=roles, constant=key)
    found["text"] = disasm.render(found)
    return found


def marked(instruction, bound):
    roles = instruction.get("roles") or {}
    table = roles.get("table")
    if table is None or int(table) not in bound or roles.get("table_kind"):
        return instruction
    return dict(instruction, roles=dict(roles, table_kind="POOL"))


def helper_constant(instruction, value, globals_at):
    target = (instruction.get("roles") or {}).get("target")
    if target is None:
        return instruction
    if isinstance(value, dict):
        name = globals_at.get(value.get("$id") or value.get("$ref"))
        if name is None:
            return instruction
        found = dict(instruction, name="GETGLOBAL", roles={"target": target}, constant=name)
    elif isinstance(value, str) and not value.startswith("<"):
        found = dict(instruction, name="LOADK", roles={"target": target}, constant=value)
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        found = dict(instruction, name="LOADK", roles={"target": target}, constant=value)
    elif value is None:
        found = dict(instruction, name="LOADNIL", roles={"target": target})
        found.pop("constant", None)
    else:
        return instruction
    found["text"] = disasm.render(found)
    return found


def resolved(instructions, executed=()):
    for _ in range(ROUNDS):
        found = once(instructions, executed)
        if len(found) == len(instructions):
            return found
        instructions = found
    return instructions


def once(instructions, executed):
    if not instructions:
        return instructions
    states = helper_states(instructions)
    if not states:
        return instructions

    blocks = structure.basic_blocks(instructions)
    graph = structure.flow(blocks)
    entry, reached = propagate(blocks, graph, executed)
    landings = threads(blocks, graph, entry)

    kept, rewritten = [], {}
    for number, block in enumerate(blocks):
        if number not in reached:
            continue
        values = dict(entry[number])
        last = block["instructions"][-1]
        for instruction in block["instructions"]:
            taken = decide(instruction, values)
            step(instruction, values)
            if taken is False:
                continue
            landing = landings.get(number) if instruction is last else None
            rewritten[instruction["pc"]] = helper_rewritten(instruction, taken, landing)
            kept.append(instruction)

    kept = swept(without(kept, states), states)
    return helper_reached(
        instructions,
        blocks,
        graph,
        [rewritten[one["pc"]] for one in kept],
        {one["pc"] for one in kept},
    )


def helper_reached(instructions, blocks, graph, kept, surviving):
    landing = helper_landings(blocks, graph, surviving)
    out = []
    for instruction in kept:
        target = (instruction.get("roles") or {}).get("to")
        if target is None or landing.get(int(target), int(target)) == int(target):
            out.append(instruction)
            continue
        roles = dict(instruction["roles"])
        found = landing[int(target)]
        if found is None:
            roles.pop("to", None)
        else:
            roles["to"] = found
        moved = dict(instruction, roles=roles)
        moved["text"] = disasm.render(moved)
        out.append(moved)
    return out


def helper_landings(blocks, graph, surviving):
    reaches = {}
    for number, block in enumerate(blocks):
        alive = [one for one in block["instructions"] if one["pc"] in surviving]
        reaches[number] = alive[0]["pc"] if alive else None

    changed = True
    while changed:
        changed = False
        for number in graph:
            if reaches[number] is not None:
                continue
            following = graph[number]["fall"]
            if following is None:
                following = graph[number]["jump"]
            if following is not None and reaches.get(following) is not None:
                reaches[number] = reaches[following]
                changed = True
    return {block["pc"]: reaches[number] for number, block in enumerate(blocks)}


def swept(instructions, states):
    if not instructions:
        return instructions
    blocks = structure.basic_blocks(instructions)
    graph = structure.flow(blocks)
    surviving = mentioned(instructions) - states
    live = liveness(blocks, graph, surviving)

    dropped = set()
    for number, block in enumerate(blocks):
        after = set(helper_after(graph[number], live, surviving))
        for instruction in reversed(block["instructions"]):
            target = sole_write(instruction)
            if target is not None and target not in after:
                dropped.add(id(instruction))
                continue
            after = (after - helper_written(instruction)) | reading(instruction, surviving)
    return [instruction for instruction in instructions if id(instruction) not in dropped]


def reading(instruction, surviving):
    if instruction["name"] == "CLOSURE" or opaque(instruction):
        return surviving
    return reads(instruction)


def mentioned(instructions):
    found = set()
    for instruction in instructions:
        found |= helper_written(instruction) | reads(instruction)
    return found


def helper_after(edges, live, surviving):
    following = [edge for edge in (edges["fall"], edges["jump"]) if edge is not None]
    if not following:
        return surviving
    return set().union(*(live[edge] for edge in following))


def liveness(blocks, graph, surviving):
    gen, kill = {}, {}
    for number, block in enumerate(blocks):
        used, written = set(), set()
        for instruction in reversed(block["instructions"]):
            writes = helper_written(instruction)
            used = (used - writes) | reading(instruction, surviving)
            written |= writes
        gen[number], kill[number] = used, written

    before = {number: [] for number in graph}
    for number, edges in graph.items():
        for edge in (edges["fall"], edges["jump"]):
            if edge is not None:
                before[edge].append(number)

    live = {number: set(gen[number]) for number in graph}
    pending = sorted(graph, reverse=True)
    while pending:
        number = pending.pop()
        found = gen[number] | (helper_after(graph[number], live, surviving) - kill[number])
        if found != live[number]:
            live[number] = found
            pending.extend(before[number])
    return live


def sole_write(instruction):
    if instruction["name"] not in PURE:
        return None
    written = helper_written(instruction)
    return written.pop() if len(written) == 1 else None


def helper_rewritten(instruction, taken, landing):
    roles = dict(instruction.get("roles") or {})
    if landing is not None and roles.get("to") is not None:
        roles["to"] = landing
    if taken:
        roles = {key: value for key, value in roles.items() if key == "to"}
    if not taken and roles == (instruction.get("roles") or {}):
        return instruction
    instruction = dict(instruction, roles=roles)
    if taken:
        instruction["name"] = "JMP"
    instruction["text"] = disasm.render(instruction)
    return instruction


def threads(blocks, graph, entry):
    landings = {}
    for number, block in enumerate(blocks):
        if graph[number]["jump"] is None:
            continue
        values = dict(entry[number])
        for instruction in block["instructions"][:-1]:
            step(instruction, values)
        landing = through(blocks, graph, graph[number]["jump"], values)
        if landing is not None and landing != number:
            landings[number] = blocks[landing]["pc"]
    return landings


def through(blocks, graph, start, values):
    seen, at = set(), start
    while at not in seen and sideless(blocks[at]):
        seen.add(at)
        edges = graph[at]
        if edges["conditional"]:
            going = decide(blocks[at]["instructions"][-1], values)
            if going is None:
                break
            following = edges["jump"] if going else edges["fall"]
        else:
            following = edges["jump"] if edges["jump"] is not None else edges["fall"]
        if following is None:
            break
        at = following
    return None if at == start else at


def sideless(block):
    return all(instruction["name"] in BRANCHES for instruction in block["instructions"])


def without(instructions, states):
    read = set()
    for instruction in instructions:
        read |= reads(instruction)
    dead = states - read
    return [instruction for instruction in instructions if not loads_into(instruction, dead)]


def loads_into(instruction, registers):
    found = helper_loaded(instruction)
    return found is not None and found[0] in registers


def reads(instruction):
    roles = instruction.get("roles") or {}
    if opaque(instruction):
        return set()
    found = set()
    for role in READS:
        value = roles.get(role)
        if value is None or roles.get(role + "_kind") in ("IMM", "NUM"):
            continue
        found.add(int(value))
    if instruction["name"] == "CALL" and roles.get("function") is not None:
        callee = int(roles["function"])
        count = roles.get("arguments")
        if count is None:
            count = instruction.get("fills") or 0
        found.update(range(callee + 1, callee + int(count) + 1))
    return found


def helper_tested(instruction):
    roles = instruction.get("roles") or {}
    if instruction["name"] != "JMPIF" or roles.get("test") not in TESTS:
        return set()
    return {
        int(roles[side])
        for side in SIDES
        if roles.get(side + "_kind") == "REG" and roles.get(side) is not None
    }


def helper_states(instructions):
    loaded, tested = set(), set()
    for instruction in instructions:
        found = helper_loaded(instruction)
        if found and not isinstance(found[1], str):
            loaded.add(found[0])
        tested |= helper_tested(instruction)
    return loaded & tested


def helper_loaded(instruction):
    if instruction["name"] not in LOADS:
        return None
    roles = instruction.get("roles") or {}
    target = roles.get("target")
    if target is None:
        target = instruction.get("writes")
    if target is None:
        return None
    value = instruction.get("constant") if instruction["name"] == "LOADK" else roles.get("value")
    if isinstance(value, bool) or not isinstance(value, (int, float, str)):
        return None
    return int(target), value


def helper_written(instruction):
    name = instruction["name"]
    roles = instruction.get("roles") or {}
    found = set()
    target = roles.get("target")
    if target is None:
        target = instruction.get("writes")
    if target is not None:
        found.add(int(target))
        if name == "SELF":
            found.add(int(target) + 1)
    if name in RANGES:
        first, last = (roles.get(role) for role in RANGES[name])
        if first is None:
            first = target
        if first is not None and last is not None and last >= first:
            found.update(range(int(first), int(last) + 1))
    if name == "CALL" and roles.get("function") is not None:
        callee = int(roles["function"])
        found.update(range(callee, callee + max(int(roles.get("results") or 0), 1)))
    return found


def opaque(instruction):
    return instruction["name"].startswith("VM-OP") or instruction["name"] in OPAQUE


def step(instruction, values, bound=()):
    found = helper_loaded(instruction)
    if found:
        values[found[0]] = found[1]
        return
    if opaque(instruction):
        values.clear()
        return
    if instruction["name"] == "GETTABLE" and bound:
        target = (instruction.get("roles") or {}).get("target")
        if target is not None:
            fetched = helper_fetched(instruction, values, bound)
            if isinstance(fetched, str) and fetched.startswith("<"):
                fetched = None
            if isinstance(fetched, (str, int, float)) and not isinstance(fetched, bool):
                values[int(target)] = fetched
            else:
                values.pop(int(target), None)
            return
    copy = helper_copy(instruction)
    if copy is not None:
        target, source = copy
        if source in values:
            values[target] = values[source]
        else:
            values.pop(target, None)
        return
    for register in helper_written(instruction):
        values.pop(register, None)


def helper_copy(instruction):
    roles = instruction.get("roles") or {}
    if instruction["name"] != "MOVE" or roles.get("from_kind") in ("IMM", "NUM"):
        return None
    target, source = roles.get("target"), roles.get("from")
    if target is None or source is None:
        return None
    return int(target), int(source)


def decide(instruction, values):
    roles = instruction.get("roles") or {}
    if instruction["name"] != "JMPIF" or roles.get("to") is None:
        return None
    test = TESTS.get(roles.get("test"))
    if test is None:
        return None
    left, right = (helper_side(roles, side, values) for side in SIDES)
    if left is None or right is None or kind(left) != kind(right):
        return None
    return not test(left, right)


def kind(value):
    return "text" if isinstance(value, str) else "number"


def helper_side(roles, side, values):
    value = roles.get(side)
    if value is None:
        return None
    if roles.get(side + "_kind") in ("IMM", "NUM"):
        return value
    if roles.get(side + "_kind") == "REG":
        return values.get(int(value))
    return None


def propagate(blocks, graph, executed, bound=()):
    seeds = {0}
    while True:
        entry, reached = walked(blocks, graph, seeds, bound)
        missed = {
            number
            for number, block in enumerate(blocks)
            if number not in reached and ran(block, executed)
        }
        if not missed:
            return entry, reached
        seeds |= missed


def ran(block, executed):
    if sideless(block):
        return False
    return any(instruction["pc"] in executed for instruction in block["instructions"])


def walked(blocks, graph, seeds, bound=()):
    entry = {number: {} for number in graph}
    reached = set(seeds)
    pending = sorted(seeds)
    while pending:
        number = pending.pop()
        values = dict(entry[number])
        going = None
        for instruction in blocks[number]["instructions"]:
            going = decide(instruction, values)
            step(instruction, values, bound)
        for edge in successors(graph[number], going):
            if narrowed(entry, reached, edge, values):
                pending.append(edge)
    return entry, reached


def successors(edges, going):
    if edges["conditional"] and going is not None:
        return [edges["jump"] if going else edges["fall"]]
    return [edge for edge in (edges["fall"], edges["jump"]) if edge is not None]


def narrowed(entry, reached, edge, values):
    if edge not in reached:
        reached.add(edge)
        entry[edge] = dict(values)
        return True
    kept = {
        register: value for register, value in entry[edge].items() if values.get(register) == value
    }
    if len(kept) == len(entry[edge]):
        return False
    entry[edge] = kept
    return True
