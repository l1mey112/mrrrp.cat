"""Luraph's environment table.

The runtime caches everything it will ever reach for into one table, built
once at startup and read by every other prototype. Globals go in as
`GETGLOBAL R15 = _G['bit32']`, `R15 = R15['band']`, `SETTABLE R14[169] = R15`;
the method names used to index them go in beside those, as string stores.
The rest of the container is then full of `R1[169]` and `R5[R1[95]]` where
the source said `bit32.band` and `string.byte`.

Replaying the builder recovers the slot map, and with it those reads become
names again. Which raw operand carries the slot in a string store is
randomised per file, so it is voted for by how well its values line up with
the slots the container actually reads.
"""

from . import control_flow as structure

NAME_START = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
NAME_REST = NAME_START | set("0123456789")
INDEXED = ("GETTABLE", "SELF")
AGREEMENT = 3
LEAST = 2


def discover(bodies):
    """The environment's slot map: `{slot: (kind, value)}`, kind being
    `global` for a cached global and `string` for a cached name."""
    globals_at, builder = globals(bodies)
    if not globals_at:
        return {}
    wanted = read_slots(bodies, globals_at)
    strings_at = strings(bodies.get(builder) or [], wanted)
    found = {slot: ("string", value) for slot, value in strings_at.items()}
    found.update({slot: ("global", name) for slot, name in globals_at.items()})
    return found


def globals(bodies):
    """slot -> dotted global name, from whichever prototype stores the most."""
    best, builder = {}, None
    for number, body in bodies.items():
        found = replay(body)
        if len(found) > len(best):
            best, builder = found, number
    return best, builder


def replay(instructions):
    """Walk the builder's stores, following linearised order: the builder is
    itself flattened, so reading it as written attributes a store to whatever
    global happens to sit above it in the file."""
    known, found = {}, {}
    for entry in structure.linear(instructions):
        name = entry.get("name")
        roles = entry.get("roles") or {}
        constant = entry.get("constant")
        target = roles.get("target")

        if name == "GETGLOBAL":
            if target is not None:
                if isinstance(constant, str):
                    known[target] = constant
                else:
                    known.pop(target, None)
            continue

        if name == "MOVE":
            source = roles.get("from")
            if target is not None:
                if source in known:
                    known[target] = known[source]
                else:
                    known.pop(target, None)
            continue

        if name == "GETTABLE":
            table = roles.get("table")
            if target is None:
                continue
            if table in known and isinstance(constant, str) and is_name(constant):
                known[target] = known[table] + "." + constant
            else:
                known.pop(target, None)
            continue

        if name == "SETTABLE":
            slot = slot_of(entry)
            source = roles.get("from")
            if slot is not None and source in known:
                found[slot] = known[source]
            continue

        if target is not None:
            known.pop(target, None)
    return found


def strings(instructions, wanted):
    """slot -> cached name, from the builder's string stores.

    A string store puts the name in the constant and the slot in one of the
    raw operands. Which operand that is changes per file, so each candidate
    is scored by how many of its values are slots the container reads.
    """
    stores = [
        entry
        for entry in instructions
        if entry.get("name") == "SETTABLE" and isinstance(entry.get("constant"), str)
    ]
    if not stores or not wanted:
        return {}

    votes = {}
    for entry in stores:
        for stream, value in (entry.get("operands") or {}).items():
            if integer(value) is not None:
                votes.setdefault(stream, set()).add(integer(value))
    best, score = None, 0
    for stream, values in votes.items():
        agree = len(values & wanted)
        if agree > score:
            best, score = stream, agree
    if best is None or score < AGREEMENT:
        return {}

    found = {}
    for entry in stores:
        slot = integer((entry.get("operands") or {}).get(best))
        if slot is not None:
            found[slot] = entry["constant"]
    return found


def read_slots(bodies, globals_at):
    """Every integer slot the container reads out of an environment table."""
    wanted = set()
    for body in bodies.values():
        tables = helper_tables(body, globals_at)
        if not tables:
            continue
        for entry in body:
            if entry.get("name") not in INDEXED:
                continue
            if (entry.get("roles") or {}).get("table") not in tables:
                continue
            slot = slot_of(entry)
            if slot is not None:
                wanted.add(slot)
    return wanted


def annotate(instructions, mapping):
    """Mark every read of a known slot with what it resolves to."""
    if not mapping:
        return instructions
    tables = helper_tables(instructions, mapping)
    if not tables:
        return instructions
    for entry in instructions:
        if entry.get("name") != "GETTABLE":
            continue
        if (entry.get("roles") or {}).get("table") not in tables:
            continue
        slot = slot_of(entry)
        found = mapping.get(slot) if slot is not None else None
        if found is not None:
            entry["env_kind"], entry["env"] = found
    return instructions


def helper_tables(instructions, mapping):
    """Registers holding the environment table.

    A register qualifies once it is indexed by two slots the map knows.
    Counting unknown slots against it would be circular — the map starts
    small, so the registers that would grow it get vetoed for the very
    reads that have not been resolved yet.
    """
    hits = {}
    for entry in instructions:
        if entry.get("name") not in INDEXED:
            continue
        table = (entry.get("roles") or {}).get("table")
        slot = slot_of(entry)
        if table is None or slot is None or slot not in mapping:
            continue
        hits.setdefault(table, set()).add(slot)
    return {table for table, slots in hits.items() if len(slots) >= LEAST}


def slot_of(entry):
    """The integer key this instruction indexes with, or None."""
    constant = entry.get("constant")
    if constant is not None:
        return integer(constant)
    roles = entry.get("roles") or {}
    if roles.get("key_kind") == "REG":
        return None
    return integer(roles.get("key"))


def integer(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return int(value)


def is_name(text):
    if not text or text[0] not in NAME_START:
        return False
    return all(character in NAME_REST for character in text)


def plain(name):
    """Whether a resolved global can stand on its own as a name."""
    return is_name(name)
