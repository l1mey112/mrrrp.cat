from afterglow.parsing.tokenizer import block_end, number, tokenize

MAX_RANGE = 16
OPCODE_CEILING = 255


class Range:

    def __init__(self, low=0, high=OPCODE_CEILING, excluded=frozenset()):
        self.low = low
        self.high = high
        self.excluded = frozenset(excluded)

    def values(self):
        return [value for value in range(self.low, self.high + 1) if value not in self.excluded]

    def narrowed(self, operator, value):
        low, high, excluded = self.low, self.high, set(self.excluded)
        if operator == "<":
            high = min(high, value - 1)
        elif operator == "<=":
            high = min(high, value)
        elif operator == ">":
            low = max(low, value + 1)
        elif operator == ">=":
            low = max(low, value)
        elif operator == "==":
            low, high = max(low, value), min(high, value)
        elif operator == "~=":
            excluded.add(value)
        return Range(low, high, excluded)


OPPOSITE = {"<": ">=", "<=": ">", ">": "<=", ">=": "<", "==": "~=", "~=": "=="}


def handlers(source, opcode_variable):
    tokens = tokenize(source)
    start = dispatch(tokens, opcode_variable)
    if start is None:
        return {}

    found = {}
    walk(tokens, start, len(tokens), Range(), opcode_variable, source, found)
    return found


def dispatch(tokens, variable):
    for index, token in enumerate(tokens):
        if token.is_("keyword", "if") and condition(tokens, index + 1, variable)[0]:
            return index
    return None


def walk(tokens, start, stop, allowed, variable, source, found):
    index = start
    while index < stop:
        token = tokens[index]
        if not (token.is_("keyword", "if") or token.is_("keyword", "elseif")):
            break

        test, after = condition(tokens, index + 1, variable)
        if not test:

            if token.is_("keyword", "elseif"):
                record(tokens, index, stop, allowed, variable, source, found)
            break
        operator, value, negated = test
        if negated:
            operator = OPPOSITE[operator]

        body_start, body_stop, next_index, kind = branch(tokens, after)
        taken = allowed.narrowed(operator, value)
        record(tokens, body_start, body_stop, taken, variable, source, found)

        allowed = allowed.narrowed(OPPOSITE[operator], value)
        if kind == "elseif":
            index = next_index
            continue
        if kind == "else":
            record(tokens, next_index[0], next_index[1], allowed, variable, source, found)
        return


def record(tokens, start, stop, allowed, variable, source, found):
    if start >= stop:

        values = allowed.values()
        if values and len(values) <= MAX_RANGE:
            for value in values:
                found.setdefault(value, "")
        return
    if tokens[start].is_("keyword", "if") and condition(tokens, start + 1, variable)[0]:
        walk(tokens, start, stop, allowed, variable, source, found)
        return

    values = allowed.values()
    if not values or len(values) > MAX_RANGE:
        return
    body = source[tokens[start].start : tokens[stop - 1].start + len(tokens[stop - 1].text)]
    if tokens[start].is_("keyword", "elseif"):
        body = "if" + body[len("elseif") :]
    for value in values:
        found.setdefault(value, body)


def condition(tokens, index, variable):
    negated = False
    if tokens[index].is_("keyword", "not"):
        negated = True
        index += 1
    depth = 0
    while tokens[index].is_("operator", "("):
        depth += 1
        index += 1

    if not tokens[index].is_("name", variable):
        return None, index
    operator = tokens[index + 1]
    if operator.kind != "operator" or operator.text not in OPPOSITE:
        return None, index
    value = number(tokens[index + 2].text) if tokens[index + 2].kind == "number" else None
    if value is None:
        return None, index

    index += 3
    while depth and tokens[index].is_("operator", ")"):
        depth -= 1
        index += 1
    if depth or not tokens[index].is_("keyword", "then"):
        return None, index
    return (operator.text, int(value), negated), index + 1


def branch(tokens, start):
    depth = 0
    header = False
    index = start
    while index < len(tokens):
        token = tokens[index]
        if token.kind == "keyword":
            if token.text in ("while", "for"):
                depth += 1
                header = True
            elif token.text == "do":
                if header:
                    header = False
                else:
                    depth += 1
            elif token.text in ("if", "function", "repeat"):
                depth += 1
            elif token.text in ("end", "until"):
                if depth == 0 and token.text == "end":
                    return start, index, index + 1, "end"
                depth -= 1
            elif depth == 0 and token.text == "elseif":
                return start, index, index, "elseif"
            elif depth == 0 and token.text == "else":
                body_start = index + 1
                body_stop = block_end(tokens, body_start) or len(tokens)
                return start, index, (body_start, body_stop), "else"
        index += 1
    return start, index, index, "end"
