BOOKKEEPING = ("JUNK", "SETUP", "STORE")
UNCONDITIONAL = "JMP"
STOPS = ("RETURN",)
TESTS = {
    "==": "==",
    "~=": "~=",
    "<": "<",
    "<=": "<=",
    ">": ">",
    ">=": ">=",
    "true": "",
    "false": "not ",
}


def linear(instructions):
    if not instructions:
        return []
    blocks = basic_blocks(instructions)
    graph = flow(blocks)
    order = helper_order(graph)
    position = {block: index for index, block in enumerate(order)}

    out = []
    for index, block in enumerate(order):
        out.extend(blocks[block]["instructions"])
        falls = graph[block]["fall"]
        if falls is None or position.get(falls) == index + 1:
            continue
        out.append(
            {
                "pc": None,
                "op": -1,
                "name": "JMP",
                "operands": {},
                "roles": {"to": blocks[falls]["pc"]},
                "synthetic": True,
            }
        )
    return tightened(out)


def tightened(instructions):
    while True:
        skipped, kept = {}, []
        for index, one in enumerate(instructions):
            if one["name"] == UNCONDITIONAL and index + 1 < len(instructions):
                target = helper_target(one)
                if target is not None and instructions[index + 1]["pc"] == target:
                    if one["pc"] is not None:
                        skipped[one["pc"]] = target
                    continue
            kept.append(one)
        if len(kept) == len(instructions):
            return kept
        instructions = retargeted(kept, skipped) if skipped else kept


def retargeted(instructions, skipped):
    """Point every jump at where its target ended up.

    Removing a jump that landed on the next instruction leaves anything
    aiming at that jump aiming at nothing, so those are walked forward to
    whatever the removed jump itself reached.

    The walk has to finish on an instruction that is still here. Blocks are
    laid out in reverse postorder rather than by pc, so a removed jump can
    point backwards and a chain of them can close into a cycle; the old walk
    stopped on `seen` and handed back whichever removed pc it happened to be
    holding. When that pc was the jump's own, the result was a jump onto
    itself -- an infinite empty loop. Six of those reached iy.lua's chunk and
    one landed in the entry block, which is why a decompiler read eight
    instructions of an 18000-instruction chunk and stopped.
    """
    live = {one["pc"] for one in instructions if one["pc"] is not None}

    def settled(pc):
        seen = set()
        while pc not in live and pc in skipped and pc not in seen:
            seen.add(pc)
            pc = skipped[pc]
        return pc if pc in live else None

    out = []
    for one in instructions:
        target = helper_target(one)
        if target is None or target in live:
            out.append(one)
            continue
        landed = settled(target)
        if landed is None or landed == one["pc"]:

            out.append(one)
            continue
        roles = dict(one["roles"])
        roles["to"] = landed
        out.append(dict(one, roles=roles))
    return out


def code(instructions):
    if not instructions:
        return []
    blocks = basic_blocks(instructions)
    if not blocks:
        return []
    graph = flow(blocks)
    order = helper_order(graph)
    dominators = helper_dominators(order, graph)
    loops, branches = helper_regions(blocks, graph, order, dominators)
    return render(blocks, order, loops, branches)


def basic_blocks(instructions):
    by_pc = {instruction["pc"]: instruction for instruction in instructions}
    leaders = {instructions[0]["pc"]}
    for position, instruction in enumerate(instructions):
        target = helper_target(instruction)
        if target is None:
            continue
        if target in by_pc:
            leaders.add(target)
        if position + 1 < len(instructions):
            leaders.add(instructions[position + 1]["pc"])

    blocks, current = [], None
    for instruction in instructions:
        if instruction["pc"] in leaders or current is None:
            current = {"pc": instruction["pc"], "instructions": []}
            blocks.append(current)
        current["instructions"].append(instruction)
    return blocks


def flow(blocks):
    at = {block["pc"]: number for number, block in enumerate(blocks)}
    graph = {}
    for number, block in enumerate(blocks):
        last = block["instructions"][-1]
        target = helper_target(last)
        jump = at.get(target) if target is not None else None
        falls = number + 1 if number + 1 < len(blocks) else None
        if last["name"] == UNCONDITIONAL:
            falls = None
        if last["name"] in STOPS:
            falls, jump = None, None
        graph[number] = {
            "fall": falls,
            "jump": jump,
            "conditional": jump is not None and falls is not None,
        }
    return graph


def helper_target(instruction):
    target = (instruction.get("roles") or {}).get("to")
    return int(target) if target is not None else None


def helper_order(graph):
    """Lay the blocks out to read like the program the obfuscator shuffled.

    Reverse postorder: every edge that is not a way back into the block it
    came from points forward, so nothing reads as a loop that is not one, and
    a block sits directly after the one it falls out of, because the walk
    takes the jump first and finishes the fall-through last.
    """
    order = priority(graph)
    return grouped(order, helper_cycles(graph, order))


def helper_cycles(graph, order):
    dominators = helper_dominators(order, graph)
    coming = {}
    for block, edges in graph.items():
        for edge in (edges["fall"], edges["jump"]):
            if edge is not None:
                coming.setdefault(edge, set()).add(block)

    found = {}
    for block, edges in graph.items():
        for edge in (edges["fall"], edges["jump"]):
            if edge is None or edge not in dominators.get(block, ()):
                continue
            body, pending = {edge}, [block]
            while pending:
                one = pending.pop()
                if one in body:
                    continue
                body.add(one)
                pending.extend(coming.get(one, ()))
            found.setdefault(edge, set()).update(body)
    return found


def grouped(order, cycles):
    out = list(order)
    for head in sorted(cycles, key=lambda one: len(cycles[one])):
        body = cycles[head]
        if head not in out:
            continue
        spot = out.index(head)
        inside = [block for block in out if block in body]
        before = [block for block in out[:spot] if block not in body]
        after = [block for block in out[spot:] if block not in body]
        out = before + inside + after
    return out


def priority(graph):
    seen, order = set(), []

    def walk(start):
        finished = []
        seen.add(start)
        stack = [(start, 0)]
        while stack:
            block, step = stack.pop()
            edges = (graph[block]["jump"], graph[block]["fall"])
            while step < len(edges) and (edges[step] is None or edges[step] in seen):
                step += 1
            if step == len(edges):
                finished.append(block)
                continue
            stack.append((block, step + 1))
            seen.add(edges[step])
            stack.append((edges[step], 0))
        order.extend(reversed(finished))

    walk(0)
    for number in sorted(graph):
        if number not in seen:
            walk(number)
    return order


def helper_dominators(order, graph):
    position = {block: i for i, block in enumerate(order)}
    predecessors = {block: set() for block in order}
    for block in order:
        for edge in (graph[block]["fall"], graph[block]["jump"]):
            if edge in predecessors:
                predecessors[edge].add(block)

    dominators = {block: set(order) for block in order}
    if order:
        dominators[order[0]] = {order[0]}
    changed = True
    while changed:
        changed = False
        for block in order[1:]:
            incoming = [
                dominators[before]
                for before in predecessors[block]
                if before != block and before in position
            ]
            found = (set.intersection(*incoming) if incoming else set()) | {block}
            if found != dominators[block]:
                dominators[block] = found
                changed = True
    return dominators


def helper_regions(blocks, graph, order, dominators):
    position = {block: i for i, block in enumerate(order)}
    loops, branches = [], []

    for block in order:
        edges = graph[block]
        for edge in (edges["fall"], edges["jump"]):
            if edge is None or edge not in position:
                continue
            if position[edge] <= position[block] and edge in dominators[block]:
                loops.append((position[edge], position[block]))
        if edges["conditional"] and edges["jump"] in position:
            over = position[edges["jump"]] - 1
            if over > position[block]:
                branches.append((position[block], over))

    return nested(loops, "loop"), nested(branches, "branch")


def nested(regions, kind):
    kept = []
    for start, stop in sorted(regions, key=lambda r: (r[0], -(r[1] - r[0]))):
        if stop <= start:
            continue
        if all(fits(start, stop, other) for other in kept):
            kept.append((start, stop))
    return [(start, stop, kind) for start, stop in kept]


def fits(start, stop, other):
    outer_start, outer_stop = other
    return (outer_start <= start and stop <= outer_stop) or stop < outer_start or start > outer_stop


def render(blocks, order, loops, branches):
    opens, closes = {}, {}
    for start, stop, kind in loops + branches:
        opens.setdefault(start, []).append((stop, kind))
        closes[stop] = closes.get(stop, 0) + 1
    for position in opens:
        opens[position].sort(reverse=True)

    inside = {stop for _start, stop, kind in loops if kind == "loop"}
    following = {
        block: order[index + 1] if index + 1 < len(order) else None
        for index, block in enumerate(order)
    }
    lines, depth = [], 0
    for index, block in enumerate(order):
        last = blocks[block]["instructions"][-1]
        for stop, kind in opens.get(index, []):
            latch = blocks[order[stop]]["instructions"] if stop < len(order) else None
            lines.append(open(depth, kind, blocks[block]["instructions"], latch))
            depth += 1

        for instruction in blocks[block]["instructions"]:
            if instruction["name"] in BOOKKEEPING:
                continue
            if instruction is last and structural(index, opens, closes, inside):
                continue
            if instruction is last and falls_through(blocks, helper_target(last), following[block]):
                continue
            lines.append("  " * depth + (instruction.get("text") or instruction["name"]))

        for _ in range(closes.get(index, 0)):
            depth = max(0, depth - 1)
            lines.append("  " * depth + "end")
    while depth > 0:
        depth -= 1
        lines.append("  " * depth + "end")
    return lines


def falls_through(blocks, target, next_block):
    if target is None or next_block is None:
        return False
    return blocks[next_block]["pc"] == target


def structural(index, opens, closes, inside):
    return index in closes or index in inside


def open(depth, kind, instructions, latch=None):
    prefix = "  " * depth
    if kind == "loop":
        condition = helper_test(latch) if latch else "..."
        return prefix + ("while true do" if condition == "..." else f"while {condition} do")
    return prefix + f"if {helper_test(instructions)} then"


COMPARISONS = {"EQ": "==", "NE": "~=", "LT": "<", "LE": "<=", "GT": ">", "GE": ">="}


def helper_test(instructions):
    jump = instructions[-1]
    spelled = from_roles(jump.get("roles") or {})
    if spelled:
        return spelled
    for instruction in reversed(instructions[:-1]):
        operator = COMPARISONS.get(instruction["name"])
        if not operator:
            continue
        roles = instruction.get("roles") or {}
        left, right = roles.get("left"), roles.get("right")
        if left is not None and right is not None:
            return f"R{left:g} {operator} R{right:g}"
        return instruction.get("text", "...").split("= ", 1)[-1]
    return "..."


def from_roles(roles):
    test = roles.get("test")
    if test is None:
        return None
    if test in ("true", "false"):
        left = operand(roles, "left")
        return f"{TESTS[test]}{left}" if left else None
    left, right = operand(roles, "left"), operand(roles, "right")
    if not left or not right:
        return None
    return f"{left} {test} {right}"


def operand(roles, side):
    value = roles.get(side)
    if value is None:
        return None
    if roles.get(side + "_kind") == "REG":
        return f"R{value:g}"
    return f"{value:g}"
