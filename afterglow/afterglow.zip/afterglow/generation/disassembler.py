from afterglow.recovery import semantics

GLOBAL = "<global "

WEAK = ("JUNK", "SETUP", "STORE")

JUMPS = ("JMP", "JMPIF", "FORLOOP", "TFORLOOP")

LITERAL = ("test", "arguments", "results", "count", "value")

NAMED = ("GETGLOBAL", "SETGLOBAL", "GETTABLE", "SETTABLE", "SELF")


def chosen(offered, wants_name):
    if wants_name:
        for value in offered:
            if isinstance(value, str):
                return value
    for value in offered:
        if value is not None:
            return value
    return None


def listing(
    layer,
    functions,
    traced,
    names,
    inferred=None,
    jump_slots=None,
    constant_slots=None,
    globals_at=None,
    reader=None,
    transitions=None,
    lifted=(),
    flat=None,
    flat_columns=None,
    loaded_at=None,
    pool_values=None,
):
    inferred = inferred or {}
    jump_slots = jump_slots or {}
    constant_slots = constant_slots or {}
    globals_at = globals_at or {}
    transitions = transitions or {}
    loaded_at = loaded_at or {}
    pool_values = pool_values or {}
    stepping = semantics.encoding(jump_slots)
    slot_by_function = helper_slots(functions, traced)
    witnessed = {
        (function["id"], instruction["pc"])
        for function in traced
        for instruction in function["code"]
    }
    flat_columns = dict(flat_columns or {})
    flat_columns.update(indexed_columns(functions, slot_by_function, inferred, flat, flat_columns))
    code = []
    for function in functions:
        slot_of = slot_by_function.get(function["id"], {})
        contents = helper_contents(function, slot_of, reader)
        for instruction in function["instructions"]:
            facts = inferred.get(instruction["op"], {})
            entry = {
                "function": function["id"],
                "pc": instruction["pc"],
                "op": instruction["op"],
                "name": names.get(instruction["op"])
                or facts.get("name")
                or "VM-OP_%d" % instruction["op"],
                "operands": instruction["operands"],
            }
            destination = slot_of.get(facts.get("destination"))
            if destination in instruction["operands"]:
                entry["writes"] = instruction["operands"][destination]
            if "patched_from" in instruction:
                entry["patched_from"] = instruction["patched_from"]

            roles = {}
            handled = facts.get("operands") or {}
            for role, stream in handled.items():
                if role in LITERAL or role.endswith("_kind"):
                    roles[role] = stream
                    continue
                slot = slot_of.get(stream)
                if slot in instruction["operands"]:
                    roles[role] = instruction["operands"][slot]
                elif handled.get(role + "_kind") == "NUM" and isinstance(stream, (int, float)):
                    roles[role] = stream
            went_to = transitions.get((function["id"], instruction["pc"]))
            if went_to is None:
                went_to = semantics.target(instruction, jump_slots, function["id"])
            if went_to is not None:
                roles["to"] = went_to
            ran = (
                reader.read(instruction["op"], instruction["pc"], contents, function["id"])
                if reader
                else None
            )
            if ran:
                for role, value in ran.get("roles", {}).items():
                    roles.setdefault(role, value)
                if ran.get("counter") is not None and "to" not in roles and stepping:
                    roles["to"] = semantics.landing(ran["counter"], instruction["pc"], stepping)

                if ran.get("name") and (
                    entry["name"].startswith("VM-OP")
                    or entry["name"] in WEAK
                    or instruction["op"] not in lifted
                ):
                    entry["name"] = ran["name"]
            if entry["name"] not in JUMPS and facts.get("handler"):

                roles.pop("to", None)
            if roles:
                entry["roles"] = roles

            pools = function.get("pools") or {}
            watched = watched_constant(
                pools, constant_slots.get(instruction["op"]), instruction["pc"]
            )
            named = named_constant(pools, roles, entry["name"])
            from_flat = flat_constant(
                flat, instruction, (flat_columns or {}).get(instruction["op"])
            )
            witnessed_global = globals_at.get((function["id"], instruction["pc"]))
            witnessed_constant = loaded_at.get((function["id"], instruction["pc"]))
            pooled_constant = pool_values.get((function["id"], roles.get("from")))
            offered = [
                witnessed_global if entry["name"] == "GETGLOBAL" else None,
                witnessed_constant if entry["name"] == "LOADK" else None,
                pooled_constant if entry["name"] == "LOADK" else None,
                ran.get("constant") if ran else None,
                watched,
                named,
                from_flat,
                instruction.get("constant"),
            ]
            found = chosen(offered, entry["name"] in NAMED)
            if found is not None:
                entry["constant"] = found
            elif entry["name"] == "LOADK" and missing_source(instruction, handled, slot_of):
                entry["name"] = "LOADNIL"
                entry["roles"] = {"target": roles.get("target")}
            elif entry["name"] == "LOADK" and roles.get("from") is not None:
                entry["name"] = "LOADPOOL"

            entry["text"] = render(entry)
            if (function["id"], instruction["pc"]) in witnessed:
                entry["confidence"] = "witnessed"
            elif instruction["op"] in lifted:
                entry["confidence"] = "static"
            elif not entry["name"].startswith("VM-OP"):
                entry["confidence"] = "inferred"
            else:
                entry["confidence"] = "unresolved"
            code.append(entry)
    return code


def missing_source(instruction, handled, slot_of):
    stream = handled.get("from")
    slot = slot_of.get(stream)
    return (
        stream is not None
        and slot is not None
        and slot not in instruction["operands"]
        and slot not in instruction.get("present", ())
    )


INDEX_AGREEMENT = 0.98
INDEX_LEAST = 8
INDEX_SPREAD = 4


def indexed_columns(functions, slot_by_function, inferred, flat, known):
    """Columns carrying a constant index for opcodes the pool vote missed.

    A constant operand is `(index << 3) | tag`, so a column holding one lands
    inside the pool on every row that uses it. Columns the lifter already gave
    a role are left alone; among the rest, a column that lands in range for
    effectively every instance and takes a spread of values is the index. The
    spread matters: the opcode's own column is constant per opcode and would
    otherwise score perfectly.
    """
    if not flat:
        return {}
    seen = {}
    for function in functions:
        slot_of = slot_by_function.get(function["id"], {})
        for instruction in function["instructions"]:
            op = instruction["op"]
            row = instruction.get("row")
            if op in known or not row:
                continue
            claimed = set()
            for role, stream in (inferred.get(op, {}).get("operands") or {}).items():
                if role.endswith("_kind") or role in LITERAL:
                    continue
                slot = slot_of.get(stream)
                if slot is not None:
                    claimed.add(slot)
            for slot, value in enumerate(row):
                if slot in claimed:
                    continue
                index = value >> 3
                tally = seen.setdefault(op, {}).setdefault(slot, [0, 0, set()])
                tally[0] += 0 < index <= len(flat)
                tally[1] += 1
                tally[2].add(index)

    found = {}
    for op, columns in seen.items():
        best, score = None, 0.0
        for slot, (fits, total, spread) in columns.items():
            if total < INDEX_LEAST or len(spread) < INDEX_SPREAD:
                continue
            share = fits / total
            if share > score:
                best, score = slot, share
        if best is not None and score >= INDEX_AGREEMENT:
            found[op] = best
    return found


def helper_contents(function, slot_of, reader):
    if not reader:
        return {}
    pools = function.get("pools") or {}
    contents = {name: pools[slot_of[name]] for name in reader.tables if slot_of.get(name) in pools}
    if reader.code:
        contents[reader.code] = {
            str(entry["pc"]): entry["op"] for entry in function["instructions"]
        }
    return contents


SLOT_AGREEMENT = 0.4


def helper_slots(functions, traced):
    by_id = {function["id"]: function for function in traced}
    per_function = {}
    for function in functions:
        watched = by_id.get(function["id"])
        if not watched:
            continue
        named_at = {entry["pc"]: entry["operands"] for entry in watched["code"]}
        agreement, seen = {}, {}
        for instruction in function["instructions"]:
            named = named_at.get(instruction["pc"])
            if not named:
                continue
            for name, value in named.items():
                seen[name] = seen.get(name, 0) + 1
                for slot, slot_value in instruction["operands"].items():
                    if slot_value == value:
                        agreement.setdefault(name, {})
                        agreement[name][slot] = agreement[name].get(slot, 0) + 1

        slots = {}
        for name, scores in agreement.items():
            slot, hits = max(scores.items(), key=lambda item: item[1])
            if hits >= SLOT_AGREEMENT * seen[name]:
                slots[name] = slot
        per_function[function["id"]] = slots

    tally = {}
    for slots in per_function.values():
        for name, slot in slots.items():
            tally.setdefault(name, {})
            tally[name][slot] = tally[name].get(slot, 0) + 1
    shared = {
        name: max(scores.items(), key=lambda item: item[1])[0] for name, scores in tally.items()
    }
    for function in functions:
        if function.get("stream_names"):
            per_function[function["id"]] = {name: name for name in function["stream_names"]}
        else:
            per_function.setdefault(function["id"], shared)
    return per_function


ARITHMETIC = {
    "ADD": "+",
    "SUB": "-",
    "MUL": "*",
    "DIV": "/",
    "MOD": "%",
    "POW": "^",
    "CONCAT": "..",
}
COMPARISON = {"EQ": "==", "NE": "~=", "LT": "<", "LE": "<=", "GT": ">", "GE": ">="}
UNARY = {"UNM": "-", "NOT": "not ", "LEN": "#"}

TAKEN = {"==": "~=", "~=": "==", "<": ">=", "<=": ">", ">": "<=", ">=": "<"}


def lua(value):
    """A recovered constant as Lua spells it, not as Python does."""
    if isinstance(value, bool):
        return "true" if value else "false"
    return repr(value)


def render(instruction):
    name = instruction["name"]
    roles = instruction.get("roles", {})
    literals = instruction.get("literals", {})
    constant = instruction.get("constant")
    value = lua(constant) if constant is not None else None

    def register(role, default="?"):

        if role in literals:
            return lua(literals[role])
        if role in roles and not numeric(roles[role]):
            return lua(roles[role])
        if role in roles and roles.get(role + "_kind") in ("IMM", "NUM"):
            return f"{roles[role]:g}"
        if role in roles and plausible(roles[role]):
            return f"R{roles[role]:g}"
        if role == "target" and plausible(instruction.get("writes")):
            return f"R{instruction['writes']:g}"
        return default

    if name == "LOADK":
        if (
            constant is None
            and roles.get("from_kind") in ("IMM", "NUM")
            and roles.get("from") is not None
        ):

            return f"{register('target')} = {register('from')}"
        return f"{register('target')} = {value or helper_slot(roles, 'from')}"
    if name == "LOADPOOL":
        source = roles.get("from")
        where = f"{source:g}" if numeric(source) else "?"
        return f"{register('target')} = pool[{where}]"
    if name in ("LOADN", "LOADBOOL"):
        stored = roles.get("value")
        return f"{register('target')} = {lua(stored) if stored is not None else '?'}"
    if name == "LOADNIL":
        return f"{register('target', register('from'))} = nil"
    if name == "MOVE":
        return f"{register('target')} = {register('from')}"
    if name == "GETGLOBAL":
        return f"{register('target')} = _G[{value or helper_slot(roles, 'from')}]"
    if name == "SETGLOBAL":
        return f"_G[{value or helper_slot(roles, 'key')}] = {register('from')}"
    if name == "SETUPVAL":
        source = roles.get("upvalue", 0)
        left = f"upvalue_{source:g}" if numeric(source) else lua(source)
        return f"{left} = {register('from')}"
    if name == "GETUPVAL":
        source = roles.get("from", 0)
        return (
            f"{register('target')} = upvalue_{source:g}"
            if numeric(source)
            else f"{register('target')} = {lua(source)}"
        )
    if name in UNARY:
        return f"{register('target')} = {UNARY[name]}{register('from')}"
    if name == "NEWTABLE":
        return f"{register('target')} = {{}}"
    if name == "SETLIST":
        base, count = roles.get("target"), roles.get("count")
        if plausible(base) and plausible(count) and count:

            first = (roles.get("offset") or 0) + 1
            return f"R{base:g}[{first:g}...] = " f"R{base + 1:g}..R{base + count:g}"
        return f"{register('target')}[...] = ..."
    if name == "NOP":
        return "-- nothing"
    if name == "CLOSURE":
        return f"{register('target')} = function"
    if name == "GETFENV":
        return f"{register('target')} = _G"
    if name == "GETTABLE":
        resolved = instruction.get("env")
        if resolved is not None:
            if instruction.get("env_kind") == "string":
                return f"{register('target')} = {lua(resolved)}"
            if "." in resolved:
                return f"{register('target')} = {resolved}"
            return f"{register('target')} = _G[{lua(resolved)}]"
        return f"{register('target')} = {register('table')}[{reaching(roles, value)}]"
    if name == "SETTABLE":
        stored = roles.get("value")
        right = lua(stored) if stored is not None else register("from")
        if roles.get("table_kind") == "POOL":
            pool = roles.get("pool") or "pool"
            table = roles.get("table", "?")
            return f"{pool}[{table}][{reaching(roles, value)}] = {right}"
        return f"{register('table')}[{reaching(roles, value)}] = {right}"
    if name == "SELF":
        return f"{register('target')} = {register('table')}:{constant or '?'}"
    if name == "CALL":
        return f"{register('function')}(...)"
    if name == "RETURN":
        count = roles.get("count")
        if count == -1:
            return f"return {register('from')}..."
        if numeric(count) and count > 0:
            last = roles.get("from", 0) + count - 1
            return f"return {register('from')}..R{last:g}"
        return "return"
    if name in ("JMP", "JMPIF", "FORLOOP", "TFORLOOP"):
        target = roles.get("to")
        where = f"pc {target:g}" if target is not None else "?"
        if name == "JMP":
            return f"goto {where}"
        if name == "FORLOOP":
            return f"loop to {where}"
        if name == "TFORLOOP":
            return f"iterate {register('target')}; goto {where}"
        test = roles.get("test")
        if test in TAKEN:
            return f"if {register('left')} {TAKEN[test]} " f"{register('right')} goto {where}"
        if test == "true":
            return f"if not {register('left')} goto {where}"
        if test == "false":
            return f"if {register('left')} goto {where}"
        return f"if ... goto {where}"
    if name in ARITHMETIC:
        return (
            f"{register('target')} = {register('left')} " f"{ARITHMETIC[name]} {register('right')}"
        )
    if name in COMPARISON:
        return (
            f"{register('target')} = {register('left')} " f"{COMPARISON[name]} {register('right')}"
        )
    if constant is not None:
        return f"-- {name}, holding {value}"
    return f"-- {name}"


REGISTERS = 256

CONSTANT_ROLE = {
    "LOADK": "from",
    "GETGLOBAL": "from",
    "SETGLOBAL": "key",
    "GETTABLE": "key",
    "SETTABLE": "key",
}


def flat_constant(flat, instruction, column):
    """The container's constant for this instruction: the voted column's
    raw value is `(flat index << 3) | tag`, so pcs that never executed
    (no pool entry ever filled) still resolve."""
    if not flat or column is None:
        return None
    row = instruction.get("row")
    if not row or column >= len(row):
        return None
    index = row[column] >> 3
    if not 0 < index <= len(flat):
        return None
    value = flat[index - 1]
    if isinstance(value, bytes):
        return value.decode("latin-1")
    if isinstance(value, (str, int, float)) and not isinstance(value, bool):
        return value
    return None


def watched_constant(pools, slot, pc):
    if slot is None or slot not in pools:
        return None
    return pools[slot].get(str(pc))


def named_constant(pools, roles, name):
    role = CONSTANT_ROLE.get(name)
    if role is None or not isinstance(roles.get(role), (int, float)):
        return None
    found = [pool.get(str(int(roles[role]))) for pool in pools.values()]
    found = [value for value in found if value is not None]
    return found[0] if len({repr(value) for value in found}) == 1 else None


def reaching(roles, constant):
    if constant is not None:
        return constant
    if not isinstance(roles.get("key"), (int, float)):
        return "?"
    if roles.get("key_kind") == "REG":
        return f"R{roles['key']:g}"
    return f"{roles['key']:g}"


def numeric(value):
    """Whether an operand is a number at all.

    A constant column holds the payload's own strings, so an operand is not
    always something to index a register file or a pool with. Everything that
    formats a value as a number has to ask this first.
    """
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def plausible(value):
    return numeric(value) and 0 <= value < REGISTERS


def helper_slot(roles, role):
    if role not in roles:
        return "K?"
    found = roles[role]

    return f"K[{found:g}]" if numeric(found) else lua(found)


def payload_functions(layer):
    calls = layer["calls"]
    if not calls:

        return {function["id"] for function in layer["protos"]}
    first = min(call["step"] for call in calls)
    mine = {call["function"] for call in calls}
    for function in layer["protos"]:
        if function["first_step"] >= first:
            mine.add(function["id"])
    return mine


def witnessed_names(layer, constants):
    names = {}
    for call in layer["calls"]:
        names[call["op"]] = "CALL"

    previous = {}
    for load in layer["trace"]["loads"]:
        op, register, value = load["op"], load["reg"], load["value"]
        if value.startswith(GLOBAL) and value.endswith(">"):
            names.setdefault(op, "GETGLOBAL")
            continue
        before = previous.get(register)
        if before and value != before and value.startswith(before):
            names[op] = "CONCAT"
        elif value in constants:
            names.setdefault(op, "LOADK")
        previous[register] = value
    return names
