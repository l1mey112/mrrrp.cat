from afterglow.parsing.tokenizer import number, tokenize

OPENERS = ("while", "for", "if", "do", "repeat", "function", "elseif", "else")
CLOSERS = ("end", "until", "else", "elseif")
ARITHMETIC = {"+": lambda a, b: a + b, "-": lambda a, b: a - b, "*": lambda a, b: a * b}
COMPARISONS = {"==", "~=", "<", "<=", ">", ">="}
PASSES = 6

deep_optimization = False


def deep(on):
    global deep_optimization
    deep_optimization = bool(on)


def fold(lines):
    statements = [helper_statement(line) for line in lines]
    statements = [s for s in statements if s is not None and s.tokens]
    statements = settle(statements)
    if deep_optimization:
        statements = unroll_state_machines(statements)
        statements = settle(statements)

    statements = self_calls(statements)
    statements = settle(statements)
    statements = method_calls(statements)
    statements = drop_unread(statements)
    statements = labels(statements)
    return rendered(statements)


def settle(statements):
    for _ in range(PASSES):
        before = len(statements)
        statements = drop_self_assignments(statements)
        statements = helper_inline(statements)
        if deep_optimization:
            statements = propagate_literals(statements)
        statements = constants(statements)
        if deep_optimization:
            statements = fold_expressions(statements)
            statements = fold_control_flow(statements)
        statements = drop_unread(statements)
        if len(statements) == before:
            break
    return statements


def self_calls(statements):
    """Put back the method call the VM's SELF was split into.

    unluac spells SELF as a copy of the receiver and a fetch of the method
    onto a register of its own, and the call then reads both. Dropping the
    fetch leaves the receiver still standing in its own register at the call,
    so the three become `receiver:method(...)`. The three need not be
    adjacent — the obfuscator's own statements get in between — but nothing
    that touches any of the three registers may.
    """
    dropped = set()
    for index in range(len(statements)):
        if index in dropped:
            continue
        found = self_call(statements, index, dropped)
        if found is None:
            continue
        fetch_at, call_at, rebuilt = found
        statements[call_at] = rebuilt
        dropped.add(fetch_at)

        copied = assignment(statements[index])
        if copied and not read_later(statements, call_at + 1, copied[0], dropped):
            dropped.add(index)
    return [s for i, s in enumerate(statements) if i not in dropped]


def self_call(statements, index, dropped):
    copy = statements[index]
    copied = assignment(copy)
    if not copied:
        return None
    held, source = copied
    if len(source) != 1 or not temporary(source[0]):
        return None
    receiver = source[0].text

    fetch_at = next_touching(statements, index + 1, {held, receiver}, copy.indent, dropped)
    if fetch_at is None:
        return None
    fetched = assignment(statements[fetch_at])
    if not fetched:
        return None
    target, method = fetched
    if (
        len(method) != 3
        or method[0].text != receiver
        or method[1].text != "."
        or method[2].kind != "name"
    ):
        return None

    call_at = next_touching(
        statements, fetch_at + 1, {held, receiver, target}, copy.indent, dropped
    )
    if call_at is None:
        return None
    tokens = statements[call_at].tokens
    made = assignment(statements[call_at])
    if made:
        if made[0] != target:
            return None
        tokens = made[1]
    if (
        len(tokens) < 4
        or tokens[0].text != target
        or tokens[1].text != "("
        or tokens[-1].text != ")"
    ):
        return None
    if tokens[2].kind != "name" or tokens[2].text != held:
        return None

    rest = tokens[4:-1] if tokens[3].text == "," else tokens[3:-1]
    body = (
        [helper_token(receiver), helper_token(":"), method[2], helper_token("(")]
        + list(rest)
        + [helper_token(")")]
    )
    if made:
        body = [helper_token(target), helper_token("=")] + body
    return fetch_at, call_at, Statement(statements[call_at].indent, body)


def next_touching(statements, start, names, indent, dropped):
    """The next statement that names any of these registers, if nothing in the
    way changes the shape the match depends on."""
    for position in range(start, len(statements)):
        if position in dropped:
            continue
        statement = statements[position]
        if statement.indent != indent or boundary(statement):
            return None
        if any(token.kind == "name" and token.text in names for token in statement.tokens):
            return position
    return None


class Statement:
    __slots__ = ("indent", "tokens")

    def __init__(self, indent, tokens):
        self.indent = indent
        self.tokens = tokens

    @property
    def text(self):
        return "  " * self.indent + helper_text(self.tokens)


def helper_statement(line):
    stripped = line.strip()
    if not stripped:
        return None
    indent = (len(line) - len(line.lstrip())) // 2
    return Statement(indent, tokenize(stripped))


def helper_text(tokens):
    out = []
    for index, token in enumerate(tokens):
        if out and spaced(tokens[index - 1], token):
            out.append(" ")
        out.append(token.text)
    return "".join(out)


CLINGS_LEFT = (",", ")", "]", ";", ".", ":")
CLINGS_RIGHT = ("(", "[", ".", ":", "#")


def spaced(previous, token):
    if token.text in CLINGS_LEFT or previous.text in CLINGS_RIGHT:
        return False
    if token.text in ("(", "[") and (previous.kind == "name" or previous.text in (")", "]")):
        return False
    return True


def temporary(token):
    if token.kind != "name" or not token.text.startswith("L"):
        return False
    body = token.text[1:]
    if "_" not in body:
        return False
    left, _, right = body.partition("_")
    return left.isdigit() and right.isdigit()


def assignment(statement):
    tokens = statement.tokens
    if len(tokens) < 3 or not temporary(tokens[0]):
        return None
    if not (tokens[1].kind == "operator" and tokens[1].text == "="):
        return None
    return tokens[0].text, tokens[2:]


def helper_reads(statement, name):
    tokens = statement.tokens
    start = 2 if assignment(statement) and tokens[0].text == name else 0
    return sum(1 for token in tokens[start:] if token.kind == "name" and token.text == name)


def pure(tokens):
    for index, token in enumerate(tokens):
        if token.text in ("(", "{") and index and tokens[index - 1].kind in ("name",):
            return False
        if token.text == ":":
            return False
    return True


def drop_self_assignments(statements):
    kept = []
    for statement in statements:
        found = assignment(statement)
        if found and len(found[1]) == 1 and found[1][0].text == found[0]:
            continue
        kept.append(statement)
    return kept


def helper_inline(statements):
    dropped = set()
    for position, statement in enumerate(statements):
        if position in dropped:
            continue
        found = assignment(statement)
        if not found:
            continue
        name, value = found
        if any(token.kind == "name" and token.text == name for token in value):
            continue
        target = consumer(statements, position, name, value, dropped)
        if target is None:
            continue
        statements[target].tokens = substitute(statements[target].tokens, name, value)
        dropped.add(position)
    return [s for i, s in enumerate(statements) if i not in dropped]


def consumer(statements, source, name, value, dropped):
    reads = {token.text for token in value if token.kind == "name"}
    indent = statements[source].indent
    found = None
    for position in range(source + 1, len(statements)):
        if position in dropped:
            continue
        statement = statements[position]
        if statement.indent != indent or boundary(statement):
            break
        count = helper_reads(statement, name)
        if count > 1:
            return None
        if count == 1:
            if found is not None:
                return None
            found = position
            written = assignment(statement)
            if written and written[0] == name:
                break

            if read_later(statements, position + 1, name, dropped):
                return None
            break
        written = assignment(statement)
        if written and written[0] == name:
            break
        if written and written[0] in reads:
            return None
        if not pure(value) or not pure(statement.tokens):
            return None
    return found


def read_later(statements, start, name, dropped):
    for position in range(start, len(statements)):
        if position in dropped:
            continue
        statement = statements[position]
        if helper_reads(statement, name):
            return True
        written = assignment(statement)
        if written and written[0] == name:
            return False
    return False


def boundary(statement):
    first = statement.tokens[0].text if statement.tokens else ""
    return first in OPENERS or first in CLOSERS


def substitute(tokens, name, value):
    start = 0

    if (
        len(tokens) >= 2
        and tokens[0].kind == "name"
        and tokens[0].text == name
        and tokens[1].kind == "operator"
        and tokens[1].text == "="
    ):
        start = 2

    out = list(tokens[:start])
    for token in tokens[start:]:
        if token.kind == "name" and token.text == name:
            out.extend(wrapped(value))
        else:
            out.append(token)
    return out


def wrapped(value):
    return list(value) if is_primary(value) else [helper_token("("), *value, helper_token(")")]


def is_primary(value):
    if not value or value[0].kind not in ("name", "string", "number"):
        return False
    index, depth = 1, 0
    while index < len(value):
        token = value[index]
        if token.kind == "operator" and token.text in "([":
            depth += 1
        elif token.kind == "operator" and token.text in ")]":
            depth -= 1
            if depth < 0:
                return False
        elif depth == 0:
            if token.kind == "operator" and token.text == ".":
                pass
            elif token.kind == "name" and value[index - 1].text == ".":
                pass
            else:
                return False
        index += 1
    return depth == 0


def constants(statements):
    for statement in statements:
        tokens, out, index = statement.tokens, [], 0
        while index < len(tokens):
            folded = fold_arithmetic(tokens, index)
            if folded is not None:
                out.append(folded)
                index += 3
                continue
            out.append(tokens[index])
            index += 1
        statement.tokens = out
    return statements


def fold_arithmetic(tokens, index):
    if index + 2 >= len(tokens):
        return None
    left, operator, right = tokens[index], tokens[index + 1], tokens[index + 2]
    if left.kind != "number" or right.kind != "number":
        return None
    if operator.kind != "operator" or operator.text not in ARITHMETIC:
        return None
    value = ARITHMETIC[operator.text](number(left.text), number(right.text))
    return helper_token(("%g" % value), kind="number")


def drop_unread(statements):
    read = set()
    for statement in statements:
        if deep_optimization and declaration(statement):

            continue
        found = assignment(statement)
        start = 2 if found else 0
        for token in statement.tokens[start:]:
            if temporary(token):
                read.add(token.text)

    kept = []
    for statement in statements:
        found = assignment(statement)
        if found and found[0] not in read and pure(found[1]):
            continue
        kept.append(statement)
    return kept


def labels(statements):
    kept = []
    for index, statement in enumerate(statements):
        target = goto(statement)
        if target is not None and label(next(statements, index)) == target:
            continue
        kept.append(statement)

    jumped = {goto(statement) for statement in kept} - {None}
    return [
        statement for statement in kept if label(statement) is None or label(statement) in jumped
    ]


def next(statements, index):
    return statements[index + 1] if index + 1 < len(statements) else None


def goto(statement):
    tokens = statement.tokens if statement else []
    if len(tokens) == 2 and tokens[0].text == "goto" and tokens[1].kind == "name":
        return tokens[1].text
    return None


def label(statement):
    tokens = statement.tokens if statement else []
    if (
        len(tokens) == 5
        and tokens[0].text == ":"
        and tokens[1].text == ":"
        and tokens[2].kind == "name"
        and tokens[3].text == ":"
        and tokens[4].text == ":"
    ):
        return tokens[2].text
    return None


def method_calls(statements):
    """`a.m(a, ...)` is how a method call reads once the receiver is spelled out.

    The VM's SELF copies the receiver into a register of its own first, so the
    argument is usually not the receiver's name but a temporary holding it.
    Following that copy is what turns `t.GetService(u, "Players")` back into
    `t:GetService("Players")`.
    """
    alias = {}
    for statement in statements:
        tokens = statement.tokens
        for index in range(len(tokens) - 4):
            dot, name, opening, first = tokens[index + 1 : index + 5]
            if not (
                tokens[index].kind == "name"
                and dot.text == "."
                and name.kind == "name"
                and opening.text == "("
            ):
                continue
            receiver = tokens[index].text
            if first.kind != "name" or (
                first.text != receiver and alias.get(first.text) != receiver
            ):
                continue
            after = tokens[index + 5].text if index + 5 < len(tokens) else ")"
            rest = tokens[index + 6 :] if after == "," else tokens[index + 5 :]
            statement.tokens = tokens[: index + 1] + [helper_token(":"), name, opening] + list(rest)
            break
        note_alias(alias, statement)
    return statements


def note_alias(alias, statement):
    found = assignment(statement)
    if not found:
        return
    name, value = found
    for held in [key for key, other in alias.items() if key == name or other == name]:
        del alias[held]
    if len(value) == 1 and temporary(value[0]):
        alias[name] = value[0].text


def rendered(statements):
    alive = {
        token.text
        for statement in statements
        for token in statement.tokens
        if temporary(token) and not declaration(statement)
    }
    lines = []
    for statement in statements:
        tokens = statement.tokens
        if declaration(statement):
            names = [token for token in tokens[1:] if token.kind == "name" and token.text in alive]
            if not names:
                continue
            rebuilt = [tokens[0]]
            for position, token in enumerate(names):
                if position:
                    rebuilt.append(helper_token(","))
                rebuilt.append(token)
            statement.tokens = rebuilt
        lines.append(statement.text)
    return lines


def declaration(statement):
    tokens = statement.tokens
    return (
        bool(tokens)
        and tokens[0].is_("keyword", "local")
        and len(tokens) > 1
        and temporary(tokens[1])
    )


class MadeValue:

    __slots__ = ("kind", "text", "start")

    def __init__(self, text, kind):
        self.kind = kind
        self.text = text
        self.start = 0

    def is_(self, kind, text=None):
        return self.kind == kind and (text is None or self.text == text)


def helper_token(text, kind="operator"):
    return MadeValue(text, kind)


def helper_literal(token):
    """Return `(kind, value)` for a Lua literal token, or None."""
    if token.kind == "number":
        value = number(token.text)
        if value is None:
            return None
        return ("num", value)
    if token.kind == "string":
        return ("str", token.text)
    if token.kind == "keyword" and token.text in ("true", "false"):
        return ("bool", token.text == "true")
    if token.kind == "keyword" and token.text == "nil":
        return ("nil", None)
    return None


def compare(op_text, left, right):
    """(True, result) if the comparison folds cleanly; (False, _) otherwise."""
    left_kind, left_value = left
    right_kind, right_value = right
    if op_text in ("==", "~="):
        equal = (left_kind == right_kind) and (left_value == right_value)
        return True, (equal if op_text == "==" else not equal)

    if left_kind != right_kind or left_kind not in ("num", "str"):
        return False, None
    result = {
        "<": left_value < right_value,
        "<=": left_value <= right_value,
        ">": left_value > right_value,
        ">=": left_value >= right_value,
    }[op_text]
    return True, result


def fold_expressions(statements):
    for statement in statements:
        statement.tokens = fold_tokens(statement.tokens)
    return statements


def fold_tokens(tokens):
    """Fold `<lit> cmp <lit>`, `not <lit>`, `(<lit>)` inside one statement.
    Iterated until a pass makes no further change."""
    while True:
        out, index, changed = [], 0, False
        while index < len(tokens):
            reduced, step = reduce(tokens, index)
            if reduced is not None:
                out.append(reduced)
                index += step
                changed = True
                continue
            out.append(tokens[index])
            index += 1
        tokens = out
        if not changed:
            return tokens


def reduce(tokens, index):

    if index + 2 < len(tokens):
        opener, inside, closer = tokens[index], tokens[index + 1], tokens[index + 2]
        prior = tokens[index - 1] if index > 0 else None
        callish = prior is not None and (prior.kind == "name" or prior.text in (")", "]"))
        if (
            opener.text == "("
            and closer.text == ")"
            and helper_literal(inside) is not None
            and not callish
        ):
            return inside, 3

    if index + 2 < len(tokens):
        left = helper_literal(tokens[index])
        op = tokens[index + 1]
        right = helper_literal(tokens[index + 2])
        if (
            left is not None
            and right is not None
            and op.kind == "operator"
            and op.text in COMPARISONS
        ):
            ok, value = compare(op.text, left, right)
            if ok:
                return helper_token("true" if value else "false", kind="keyword"), 3

    if index + 1 < len(tokens):
        if tokens[index].is_("keyword", "not"):
            found = helper_literal(tokens[index + 1])
            if found is not None:
                truthy = helper_truthy(found)
                if truthy is not None:
                    return helper_token("false" if truthy else "true", kind="keyword"), 2

    return None, 0


def helper_truthy(literal):
    kind, value = literal
    if kind == "bool":
        return value
    if kind == "nil":
        return False
    if kind in ("num", "str"):
        return True
    return None


def propagate_literals(statements):
    dropped = set()
    index = 0
    while index < len(statements):
        found = assignment(statements[index])
        if not found:
            index += 1
            continue
        name, value = found
        if len(value) != 1 or helper_literal(value[0]) is None:
            index += 1
            continue
        constant = value[0]
        indent = statements[index].indent
        reach = linear_run(statements, index + 1, indent, dropped)
        rewrote = False
        for position in reach:
            if helper_reads(statements[position], name) == 0:
                continue
            statements[position].tokens = substitute(statements[position].tokens, name, [constant])
            rewrote = True
            written = assignment(statements[position])
            if written and written[0] == name:
                break
        if rewrote:

            pass
        index += 1
    return [s for i, s in enumerate(statements) if i not in dropped]


def linear_run(statements, start, indent, dropped):
    """Positions at `indent` reachable linearly from `start` without going
    through a control-flow boundary. This is the region where an assignment's
    value is still what it was at the assignment site."""
    positions = []
    for position in range(start, len(statements)):
        if position in dropped:
            continue
        statement = statements[position]
        if statement.indent < indent:
            break
        if statement.indent == indent:
            if boundary(statement):
                break
            positions.append(position)
    return positions


def fold_control_flow(statements):
    """Collapse `if true/false`, `while true do do break end body end`,
    `while false do body end`, `repeat body until true`, and the `while 0 do
    do break end body end` idiom Luraph emits for state-machine wrappers."""
    changed = True
    while changed:
        changed = False
        for pattern in (fold_dead_while, fold_dead_if, fold_dead_repeat):
            statements, did = pattern(statements)
            changed = changed or did
    return statements


def fold_dead_while(statements):
    """`while <truthy> do <exit> body end` -> the exit; `while false do body
    end` -> nothing. The Luraph state machine's block-wrap idiom decompiles
    as `while 0 do do break end body end` (0 is truthy in Lua but the immediate
    `do break end` still fires) and its cousin `while true do goto lbl end`,
    where the first body statement is an unconditional transfer that leaves
    the rest of the body unreachable. A body's own labels are scoped to it
    and cannot be jumped into from outside, so dropping the block is sound."""
    kept, index, changed = [], 0, False
    while index < len(statements):
        opener = statements[index]
        header = while_header(opener)
        is_while_zero = while_zero(opener)
        if header is None and not is_while_zero:
            kept.append(opener)
            index += 1
            continue
        end_at = matching_end(statements, index, opener.indent, "end")
        if end_at is None:
            kept.append(opener)
            index += 1
            continue
        if header is False:

            index = end_at + 1
            changed = True
            continue

        escape = first_body_escape(statements, index + 1, end_at, opener.indent + 1)
        if escape is not None:
            if escape == "wrap":

                index = end_at + 1
            elif escape == "break":

                index = end_at + 1
            else:

                kept.extend(dedented([escape], 1))
                index = end_at + 1
            changed = True
            continue
        kept.append(opener)
        index += 1
    return kept, changed


def first_body_escape(statements, body_start, end_at, indent):
    """If the first statement of the body at `indent` is an unconditional
    exit — `do break end`, `break`, `goto X`, or `return ...` — return an
    indicator: 'wrap' or 'break' for the two nothing-to-keep forms, or the
    escape Statement itself when the exit is worth keeping. A `goto X` is
    only an escape when `X` is defined outside the body: a jump forward to
    a label further down inside the block is how the state-machine unrolls,
    and dropping the block would erase the code the jump leads into."""
    for position in range(body_start, end_at):
        s = statements[position]
        if s.indent < indent:
            return None
        if s.indent > indent:
            continue
        tokens = s.tokens
        if (
            len(tokens) == 3
            and tokens[0].is_("keyword", "do")
            and tokens[1].is_("keyword", "break")
            and tokens[2].is_("keyword", "end")
        ):
            return "wrap"
        if len(tokens) == 1 and tokens[0].is_("keyword", "break"):
            return "break"
        if len(tokens) >= 1 and tokens[0].text == "goto":
            target = goto(s)
            if target is not None and labeled_in(statements, body_start, end_at, target):
                return None
            return s
        if len(tokens) >= 1 and tokens[0].is_("keyword", "return"):
            return s
        return None
    return None


def labeled_in(statements, start, end, name):
    """Is `::name::` defined anywhere in statements[start:end]?"""
    for position in range(start, end):
        if label(statements[position]) == name:
            return True
    return False


def fold_dead_if(statements):
    """`if true then A else B end` -> A; `if false then A else B end` -> B."""
    kept, index, changed = [], 0, False
    while index < len(statements):
        opener = statements[index]
        header = if_header(opener)
        if header is None:
            kept.append(opener)
            index += 1
            continue
        arms = if_arms(statements, index, opener.indent)
        if arms is None:
            kept.append(opener)
            index += 1
            continue
        end_at, chosen = choose_arm(arms, statements, header)
        if chosen is None:
            kept.append(opener)
            index += 1
            continue
        body_start, body_end = chosen
        kept.extend(dedented(statements[body_start:body_end], 1))
        index = end_at + 1
        changed = True
    return kept, changed


def fold_dead_repeat(statements):
    """`repeat body until true` -> body; a repeat whose body's first statement
    is an unconditional exit reduces to that exit (repeat always runs the body
    at least once, and the exit fires before `until` is reached). A repeat
    with `until false` stays: it is a hand-written infinite loop."""
    kept, index, changed = [], 0, False
    while index < len(statements):
        opener = statements[index]
        if not (
            opener.tokens and opener.tokens[0].is_("keyword", "repeat") and len(opener.tokens) == 1
        ):
            kept.append(opener)
            index += 1
            continue
        end_at = matching_end(statements, index, opener.indent, "until")
        if end_at is None:
            kept.append(opener)
            index += 1
            continue
        escape = first_body_escape(statements, index + 1, end_at, opener.indent + 1)
        if escape == "wrap" or escape == "break":
            index = end_at + 1
            changed = True
            continue
        if escape is not None:
            kept.extend(dedented([escape], 1))
            index = end_at + 1
            changed = True
            continue
        until = statements[end_at]
        if len(until.tokens) == 2 and until.tokens[1].is_("keyword", "true"):
            kept.extend(dedented(statements[index + 1 : end_at], 1))
            index = end_at + 1
            changed = True
            continue
        kept.append(opener)
        index += 1
    return kept, changed


def while_header(statement):
    """True/False if `while true do` or `while false do`; None otherwise."""
    tokens = statement.tokens
    if (
        len(tokens) < 3
        or not tokens[0].is_("keyword", "while")
        or not tokens[-1].is_("keyword", "do")
    ):
        return None
    body = tokens[1:-1]
    if len(body) == 1 and body[0].is_("keyword", "true"):
        return True
    if len(body) == 1 and body[0].is_("keyword", "false"):
        return False
    return None


def while_zero(statement):
    """`while 0 do` — Luraph's block-wrap header. 0 is truthy in Lua so this
    would loop forever without a break; only meaningful together with a
    guaranteed break at the top of the body."""
    tokens = statement.tokens
    return (
        len(tokens) == 3
        and tokens[0].is_("keyword", "while")
        and tokens[1].kind == "number"
        and tokens[1].text == "0"
        and tokens[-1].is_("keyword", "do")
    )


def if_header(statement):
    """The condition tokens of `if <cond> then`, or None if not that shape."""
    tokens = statement.tokens
    if (
        len(tokens) < 3
        or not tokens[0].is_("keyword", "if")
        or not tokens[-1].is_("keyword", "then")
    ):
        return None
    return tokens[1:-1]


def elseif_header(statement):
    tokens = statement.tokens
    if (
        len(tokens) < 3
        or not tokens[0].is_("keyword", "elseif")
        or not tokens[-1].is_("keyword", "then")
    ):
        return None
    return tokens[1:-1]


def is_else(statement):
    tokens = statement.tokens
    return len(tokens) == 1 and tokens[0].is_("keyword", "else")


def if_arms(statements, opener_at, indent):
    """A list of `(header, body_start, body_end)` for each if/elseif/else arm,
    followed by the position of the closing `end`. Returns None when the
    structure does not close cleanly at the same indent."""
    arms = []
    header = if_header(statements[opener_at])
    body_start = opener_at + 1
    end_at = None
    position = body_start
    while position < len(statements):
        s = statements[position]
        if s.indent == indent:
            if elseif_header(s) is not None:
                arms.append((header, body_start, position))
                header = elseif_header(s)
                body_start = position + 1
            elif is_else(s):
                arms.append((header, body_start, position))
                header = None
                body_start = position + 1
            elif s.tokens and s.tokens[0].is_("keyword", "end") and len(s.tokens) == 1:
                arms.append((header, body_start, position))
                end_at = position
                break
            elif boundary(s):
                return None
        position += 1
    if end_at is None:
        return None
    return arms, end_at


def choose_arm(arms_and_end, statements, opener_header):
    """Pick the arm whose header folds to a truthy literal; skip arms that
    fold to `false` or `nil`. Returns `(end_at, (body_start, body_end))` or
    `(_, None)` when an arm's guard folds to something Lua cannot decide at
    compile time (a data-dependent condition)."""
    arms, end_at = arms_and_end
    for header, body_start, body_end in arms:
        if header is None:
            return end_at, (body_start, body_end)
        folded = reduce_logical(fold_tokens(header))
        if len(folded) == 1:
            lit = helper_literal(folded[0])
            if lit is not None:
                truthy = helper_truthy(lit)
                if truthy:
                    return end_at, (body_start, body_end)
                if truthy is False:
                    continue
        return end_at, None

    return end_at, (end_at, end_at)


def matching_end(statements, opener_at, indent, closer_text):
    """Find the position of the statement at `indent` that closes the block
    opened at `opener_at`, matching `closer_text` on its first token."""
    for position in range(opener_at + 1, len(statements)):
        s = statements[position]
        if s.indent != indent:
            continue
        if s.tokens and s.tokens[0].is_("keyword", closer_text):
            return position
    return None


def first_is_break_wrap(statements, position, indent):
    """The statement at `position` is `do break end` at `indent` — the Luraph
    idiom that makes the enclosing loop exit before any body runs."""
    if position >= len(statements):
        return False
    s = statements[position]
    if s.indent != indent:
        return False
    tokens = s.tokens
    return (
        len(tokens) == 3
        and tokens[0].is_("keyword", "do")
        and tokens[1].is_("keyword", "break")
        and tokens[2].is_("keyword", "end")
    )


def dedented(statements, delta):
    """Return copies with `indent` reduced by `delta`, floored at zero."""
    out = []
    for statement in statements:
        moved = Statement(max(0, statement.indent - delta), statement.tokens)
        out.append(moved)
    return out


UNROLL_BUDGET = 128
LOGICALS = {"and", "or"}


def unroll_state_machines(statements):
    out = []
    index = 0
    while index < len(statements):
        found = try_unroll(statements, index)
        if found is None:
            out.append(statements[index])
            index += 1
            continue
        emitted, consumed = found
        out.extend(emitted)
        index += consumed
    return out


def try_unroll(statements, index):
    """Match a seed-plus-loop pair at `index` and simulate it. Returns
    `(replacement_statements, count)` when the block was fully unrolled;
    None when the pattern is not recognised or the simulation gives up."""
    seed = assignment(statements[index])
    if not seed:
        return None
    var, value = seed
    if len(value) != 1 or helper_literal(value[0]) is None:
        return None
    kind, initial = helper_literal(value[0])
    if kind != "num":
        return None
    indent = statements[index].indent

    loop_at = None
    scan = index + 1
    while scan < len(statements):
        s = statements[scan]
        if s.indent < indent:
            return None
        if s.indent == indent:
            if s.tokens and (
                s.tokens[0].is_("keyword", "while")
                or (len(s.tokens) == 1 and s.tokens[0].is_("keyword", "repeat"))
            ):
                loop_at = scan
                break
            if s.tokens and boundary(s):
                return None
            if reads_name(s, var) or (assignment(s) and assignment(s)[0] == var):
                return None
        scan += 1
    if loop_at is None:
        return None
    loop = statements[loop_at]

    if loop.tokens[0].is_("keyword", "while") and loop.tokens[-1].is_("keyword", "do"):
        return unroll_while(statements, index, loop_at, indent, var, initial)
    if len(loop.tokens) == 1 and loop.tokens[0].is_("keyword", "repeat"):
        return unroll_repeat(statements, index, loop_at, indent, var, initial)
    return None


def unroll_while(statements, seed_at, loop_at, indent, var, initial):
    end_at = matching_end(statements, loop_at, indent, "end")
    if end_at is None:
        return None
    cond = statements[loop_at].tokens[1:-1]
    body_start = loop_at + 1
    body_end = end_at

    emitted = simulate_while(
        statements, cond, body_start, body_end, indent + 1, indent, var, initial
    )
    if emitted is None:
        return None
    keep = [statements[i] for i in range(seed_at, loop_at)]
    return keep + emitted, end_at - seed_at + 1


def unroll_repeat(statements, seed_at, loop_at, indent, var, initial):
    until_at = matching_end(statements, loop_at, indent, "until")
    if until_at is None:
        return None
    cond = statements[until_at].tokens[1:]
    body_start = loop_at + 1
    body_end = until_at
    emitted = simulate_repeat(
        statements, cond, body_start, body_end, indent + 1, indent, var, initial
    )
    if emitted is None:
        return None
    keep = [statements[i] for i in range(seed_at, loop_at)]
    return keep + emitted, until_at - seed_at + 1


def simulate_while(statements, cond, body_start, body_end, indent, out, var, initial):
    state = {"value": initial}
    emitted = []
    for step in range(UNROLL_BUDGET):
        truth = evaluate(cond, var, state["value"])
        if truth is False:
            return emitted
        if truth is None:
            return None
        outcome = run_body(statements, body_start, body_end, indent, out, var, state, emitted)
        if outcome == "break":
            return emitted
        if outcome == "return":
            return emitted
        if outcome != "continue":
            return None
    return None


def simulate_repeat(statements, cond, body_start, body_end, indent, out, var, initial):
    state = {"value": initial}
    emitted = []
    for step in range(UNROLL_BUDGET):
        outcome = run_body(statements, body_start, body_end, indent, out, var, state, emitted)
        if outcome == "break" or outcome == "return":
            return emitted
        if outcome != "continue":
            return None
        truth = evaluate(cond, var, state["value"])
        if truth is True:
            return emitted
        if truth is None:
            return None
    return None


def run_body(statements, start, end, indent, out, var, state, emitted):
    """Walk one iteration of a loop body. Straight-line statements are
    appended to `emitted` at `out` (the target output indent) with the state
    variable's known value substituted into their right-hand sides; an
    if/elseif/else chain whose guards are state-variable comparisons is
    descended into on the arm that matches; an assignment to the state
    variable updates it and is dropped from the output. Data-dependent
    blocks that do not write the state variable are emitted verbatim, their
    internal structure preserved by shifting every statement inside them by
    a delta that puts the opener at `out`."""
    position = start
    while position < end:
        s = statements[position]
        if s.indent < indent:
            return "give_up"
        if s.indent > indent:
            position += 1
            continue
        tokens = s.tokens
        if not tokens:
            position += 1
            continue

        first = tokens[0]
        if first.is_("keyword", "break"):
            return "break"
        if first.is_("keyword", "return"):
            emitted.append(Statement(out, substitute(tokens, var, [literal_token(state["value"])])))
            return "return"
        if first.is_("keyword", "if"):

            inline = inline_if(s)
            if inline is not None:
                cond, exit_kind, exit_tokens = inline
                truth = evaluate(cond, var, state["value"])
                if truth is True:
                    if exit_kind == "break":
                        return "break"
                    if exit_kind == "return":
                        emitted.append(
                            Statement(
                                out, substitute(exit_tokens, var, [literal_token(state["value"])])
                            )
                        )
                        return "return"
                    if exit_kind == "goto":
                        emitted.append(Statement(out, exit_tokens))

                        return "break"
                if truth is False:
                    position += 1
                    continue
                if truth is None:

                    emitted.append(
                        Statement(out, substitute(tokens, var, [literal_token(state["value"])]))
                    )
                    position += 1
                    continue
            arm_at, block_end, taken = pick_if_arm(
                statements, position, indent, var, state["value"]
            )
            if arm_at is None:

                end_of_if = matching_end(statements, position, indent, "end")
                if end_of_if is None or writes_var(statements, position, end_of_if + 1, var):
                    return "give_up"
                emit_verbatim(
                    statements, position, end_of_if + 1, s.indent, out, var, state["value"], emitted
                )
                position = end_of_if + 1
                continue
            if taken is not None:
                arm_start, arm_end = taken
                outcome = run_body(
                    statements, arm_start, arm_end, indent + 1, out, var, state, emitted
                )
                if outcome != "continue":
                    return outcome
            position = block_end + 1
            continue
        if first.is_("keyword", "while") or first.is_("keyword", "repeat"):
            close = "end" if first.is_("keyword", "while") else "until"
            end_of = matching_end(statements, position, indent, close)
            if end_of is None:
                return "give_up"
            touches = writes_var(statements, position, end_of + 1, var)
            if touches:

                if first.is_("keyword", "while"):
                    outcome = simulate_nested_while(
                        statements, position, end_of, indent, out, var, state, emitted
                    )
                else:
                    outcome = simulate_nested_repeat(
                        statements, position, end_of, indent, out, var, state, emitted
                    )
                if outcome == "return":
                    return "return"
                if outcome != "exited":
                    return "give_up"
                position = end_of + 1
                continue

            emit_verbatim(
                statements, position, end_of + 1, s.indent, out, var, state["value"], emitted
            )
            position = end_of + 1
            continue

        found = assignment(s)
        if found and found[0] == var:
            _, rhs = found
            resolved = fold_tokens(substitute(rhs, var, [literal_token(state["value"])]))
            if len(resolved) != 1:
                return "give_up"
            lit = helper_literal(resolved[0])
            if lit is None or lit[0] != "num":
                return "give_up"
            state["value"] = lit[1]
            position += 1
            continue

        emitted.append(Statement(out, substitute(s.tokens, var, [literal_token(state["value"])])))
        position += 1
    return "continue"


def emit_verbatim(statements, start, end, source_indent, out, var, value, emitted):
    """Append statements[start:end] to `emitted` with their opener remapped
    to `out` and everything inside shifted by the same delta so the block's
    internal structure survives."""
    delta = out - source_indent
    for k in range(start, end):
        s = statements[k]
        emitted.append(
            Statement(max(0, s.indent + delta), substitute(s.tokens, var, [literal_token(value)]))
        )


def pick_if_arm(statements, opener_at, indent, var, value):
    """Pick which arm of an if/elseif/else chain the state variable's current
    value takes. Returns (opener_at, block_end, (body_start, body_end)) or
    (opener_at, block_end, None) when every arm was false and no else. Returns
    (None, None, None) when any arm's guard fails to fold against the state
    variable alone (a data-dependent guard)."""
    arms = if_arms(statements, opener_at, indent)
    if arms is None:
        return None, None, None
    arm_list, end_at = arms
    for header, body_start, body_end in arm_list:
        if header is None:
            return opener_at, end_at, (body_start, body_end)
        truth = evaluate(header, var, value)
        if truth is None:
            return None, None, None
        if truth:
            return opener_at, end_at, (body_start, body_end)
    return opener_at, end_at, None


def evaluate(cond, var, value):
    """Fold a condition against the state variable's known value. Returns
    True/False when the folded expression is a bare literal Lua can decide
    (a truthy literal maps to True, `false` and `nil` to False), or None
    when the expression still contains a name — the condition depends on
    something other than the state var and literals."""
    if not cond:
        return None
    subbed = substitute(cond, var, [literal_token(value)])
    reduced = reduce_logical(fold_tokens(subbed))
    if len(reduced) != 1:
        return None
    lit = helper_literal(reduced[0])
    if lit is None:
        return None
    return helper_truthy(lit)


def reduce_logical(tokens):
    """Fold `X and Y` / `X or Y` / `not Z` when their operands are literals."""
    changed = True
    while changed:
        changed = False
        out, index = [], 0
        while index < len(tokens):
            if index + 2 < len(tokens):
                left, op, right = tokens[index], tokens[index + 1], tokens[index + 2]
                if op.is_("keyword", "and") or op.is_("keyword", "or"):
                    left_lit = helper_literal(left)
                    right_lit = helper_literal(right)
                    if left_lit is not None and right_lit is not None:
                        left_truthy = helper_truthy(left_lit)
                        if left_truthy is None:
                            out.append(left)
                            index += 1
                            continue
                        if op.text == "and":
                            keep = right if left_truthy else left
                        else:
                            keep = left if left_truthy else right
                        out.append(keep)
                        index += 3
                        changed = True
                        continue
            if index + 1 < len(tokens):
                if tokens[index].is_("keyword", "not"):
                    lit = helper_literal(tokens[index + 1])
                    if lit is not None:
                        truthy = helper_truthy(lit)
                        if truthy is not None:
                            out.append(helper_token("false" if truthy else "true", kind="keyword"))
                            index += 2
                            changed = True
                            continue
            out.append(tokens[index])
            index += 1
        tokens = out
    return tokens


def single_literal(tokens):
    """The Python value of a single-token literal expression, or None (nil is
    represented as None too — callers that need to distinguish should check
    the token separately)."""
    if len(tokens) != 1:
        return "not-a-literal"
    lit = helper_literal(tokens[0])
    if lit is None:
        return "not-a-literal"
    return lit[1]


def literal_token(value):
    if isinstance(value, bool):
        return helper_token("true" if value else "false", kind="keyword")
    if isinstance(value, (int, float)):
        return helper_token(("%g" % value), kind="number")
    if isinstance(value, str):
        return helper_token(value, kind="string")
    return helper_token("nil", kind="keyword")


def substitute_var(statement, name, value):
    """Copy `statement` with every read of `name` replaced by the literal
    `value`. An assignment `name = ...` (LHS) keeps `name` on the left; index
    forms `name[…] = …` and `name.f = …` still read `name`, so those reads
    are substituted like any other."""
    lit_token = literal_token(value)
    return Statement(statement.indent, substitute(statement.tokens, name, [lit_token]))


def writes_var(statements, start, end, name):
    for position in range(start, end):
        found = assignment(statements[position])
        if found and found[0] == name:
            return True
    return False


def inline_if(statement):
    """`if <cond> then break end`, `if <cond> then return [values] end`, or
    `if <cond> then goto X end` on a single line — extract the condition and
    the exit form. Returns `(cond_tokens, kind, exit_tokens)` or None."""
    tokens = statement.tokens
    if (
        len(tokens) < 4
        or not tokens[0].is_("keyword", "if")
        or not tokens[-1].is_("keyword", "end")
    ):
        return None

    depth, then_at = 0, None
    for index in range(1, len(tokens) - 1):
        token = tokens[index]
        if token.kind == "operator" and token.text in "([{":
            depth += 1
        elif token.kind == "operator" and token.text in ")]}":
            depth -= 1
        elif token.is_("keyword", "then") and depth == 0:
            then_at = index
            break
    if then_at is None or then_at == 1:
        return None
    cond = tokens[1:then_at]
    body = tokens[then_at + 1 : -1]
    if not body:
        return None
    if len(body) == 1 and body[0].is_("keyword", "break"):
        return cond, "break", body
    if body[0].is_("keyword", "return"):
        return cond, "return", body
    if body[0].text == "goto" and len(body) == 2 and body[1].kind == "name":
        return cond, "goto", body
    return None


def reads_name(statement, name):
    """True if `name` appears anywhere in the statement's tokens as a name
    token — either read or written, but not counting a plain assignment's
    LHS since that is a write, not a read. (Index and field forms `a[x] = …`
    and `a.f = …` still read `a`, so their LHS names count.)"""
    tokens = statement.tokens
    start = 2 if assignment(statement) and tokens and tokens[0].text == name else 0
    return any(token.kind == "name" and token.text == name for token in tokens[start:])


def simulate_nested_while(statements, opener_at, end_at, indent, out, var, state, emitted):
    cond = statements[opener_at].tokens[1:-1]
    body_start = opener_at + 1
    body_end = end_at
    for step in range(UNROLL_BUDGET):
        truth = evaluate(cond, var, state["value"])
        if truth is False:
            return "exited"
        if truth is None:
            return "give_up"
        outcome = run_body(statements, body_start, body_end, indent + 1, out, var, state, emitted)
        if outcome == "break":
            return "exited"
        if outcome == "return":
            return "return"
        if outcome != "continue":
            return "give_up"
    return "give_up"


def simulate_nested_repeat(statements, opener_at, end_at, indent, out, var, state, emitted):
    cond = statements[end_at].tokens[1:]
    body_start = opener_at + 1
    body_end = end_at
    for step in range(UNROLL_BUDGET):
        outcome = run_body(statements, body_start, body_end, indent + 1, out, var, state, emitted)
        if outcome == "break":
            return "exited"
        if outcome == "return":
            return "return"
        if outcome != "continue":
            return "give_up"
        truth = evaluate(cond, var, state["value"])
        if truth is True:
            return "exited"
        if truth is None:
            return "give_up"
    return "give_up"
