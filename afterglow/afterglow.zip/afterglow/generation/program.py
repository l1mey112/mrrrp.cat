from afterglow.parsing.state import quote

CONSTRUCTOR = "Instance.new("


def source(layer):
    records = ordered(layer)
    uses = helper_uses(records)
    names = helper_names(records, uses)

    lines = []
    for record in records:
        if record["kind"] == "print":
            lines.append(record["text"])
        elif record["kind"] == "set":
            lines.append(fill(record["text"], records, uses, names))
        elif uses.get(record["id"], 0) != 1:
            text = fill(record["text"], records, uses, names)
            name = names.get(record["id"])
            lines.append(f"local {name} = {text}" if name else text)
    return lines


def ordered(layer):
    records = [dict(record, kind=record["kind"]) for record in layer["transcript"]]
    for call in layer["calls"]:
        arguments = ", ".join(quote(argument) for argument in call["arguments"])
        records.append(
            {
                "kind": "print",
                "step": call["step"],
                "text": f"{call['name']}({arguments})",
            }
        )
    records.sort(key=lambda record: record["step"])
    return records


def helper_uses(records):
    uses = {}
    for record in records:
        for reference in references(record["text"]):
            uses[reference] = uses.get(reference, 0) + 1
    return uses


def references(text):
    found = []
    index = text.find("#")
    while index != -1:
        digits = ""
        while index + 1 + len(digits) < len(text) and text[index + 1 + len(digits)].isdigit():
            digits += text[index + 1 + len(digits)]
        if digits:
            found.append(int(digits))
        index = text.find("#", index + 1)
    return found


def helper_names(records, uses):
    names = {}
    taken = set()
    for record in records:
        if record["kind"] != "call" or uses.get(record["id"], 0) < 2:
            continue
        names[record["id"]] = unique(suggest(record["text"], record["id"]), taken)
    return names


def suggest(text, identifier):
    start = text.find(CONSTRUCTOR)
    if start == -1:
        return f"v{identifier}"
    rest = text[start + len(CONSTRUCTOR) :]
    if not rest.startswith('"'):
        return f"v{identifier}"
    end = rest.find('"', 1)
    name = rest[1:end]
    return name if name.isidentifier() else f"v{identifier}"


def unique(name, taken):
    candidate, suffix = name, 1
    while candidate in taken:
        suffix += 1
        candidate = f"{name}_{suffix}"
    taken.add(candidate)
    return candidate


def fill(text, records, uses, names):
    by_id = {record["id"]: record for record in records if record.get("id")}
    for reference in sorted(set(references(text)), reverse=True):
        if reference in names:
            replacement = names[reference]
        elif uses.get(reference) == 1 and reference in by_id:
            replacement = fill(by_id[reference]["text"], records, uses, names)
        else:
            replacement = f"v{reference}"
        text = text.replace(f"#{reference}", replacement)
    return text
