import os

from afterglow.models import AnalysisResult

from . import decompiler as decompile
from . import emitter as emit

WIDTH = 56


def chunk(result: AnalysisResult):
    """The recovered payload as a Lua 5.1 chunk, for any decompiler."""
    payload = result.payload_instructions
    if payload:
        ordered = walked_payload(payload, result.payload_path)
        data, _emitted, _considered = emit.lua_chunk(
            ordered or payload,
            children=result.payload_children or None,
            linearize=not bool(ordered),
        )
        return data
    bodies, names, children, paths = [], [], [], []
    for layer in result.layers:
        payload = set(layer.get("payload", ()))
        by_id = {}
        for function in layer["functions"]:
            if "payload" in layer and function["id"] not in payload:
                continue
            body = [entry for entry in layer["instructions"] if entry["function"] == function["id"]]
            if body:
                by_id[function["id"]] = body
        referenced = {
            entry["child"]
            for body in by_id.values()
            for entry in body
            if entry.get("child") in by_id
        }
        roots = sorted(set(by_id) - referenced) or sorted(by_id)
        for root in roots:
            bodies.append(by_id[root])
            names.append("func %d" % root)
            children.append(by_id)
            paths.append(root)
    return emit.bundle(bodies, names, children, paths)


def walked_payload(instructions, path):
    """Lay out an observed iterator payload in its actual execution order.

    Luraph may execute opaque setup blocks before entering the script's first
    basic block. For an iterator payload, the nearest table construction that
    feeds the first witnessed host call is a concrete boundary: from there the
    observed path covers initialization, both iterator arms, the loop body,
    its back edge, and return. Each pc is emitted once; its recovered jumps
    preserve subsequent iterations.
    """
    by_pc = {entry.get("pc"): entry for entry in instructions if entry.get("pc") is not None}
    if not path or not any(entry.get("name") == "TFORLOOP" for entry in instructions):
        return []
    first_call = next((at for at, pc in enumerate(path) if by_pc.get(pc, {}).get("called")), None)
    if first_call is None:
        return []
    start = next(
        (
            at
            for at in range(first_call, -1, -1)
            if by_pc.get(path[at], {}).get("name") == "NEWTABLE"
        ),
        None,
    )
    if start is None:
        return []
    ordered, seen = [], set()
    for pc in path[start:]:
        if pc in seen or pc not in by_pc:
            continue
        seen.add(pc)
        ordered.append(by_pc[pc])
    loop_at = next(
        (at for at, entry in enumerate(ordered) if entry.get("name") == "TFORLOOP"), None
    )
    if loop_at is None:
        return ordered
    loop = ordered[loop_at]
    loop_pc = loop["pc"]
    occurrences = [at for at, pc in enumerate(path[start:]) if pc == loop_pc]
    if len(occurrences) < 2:
        return ordered
    first, last = occurrences[0], occurrences[-1]
    body_pcs, exit_pcs = path[start + first + 1 : start + occurrences[1]], path[start + last + 1 :]
    body = [by_pc[pc] for pc in dict.fromkeys(body_pcs) if pc in by_pc]
    exit_body = [by_pc[pc] for pc in dict.fromkeys(exit_pcs) if pc in by_pc]
    preheader = {
        "function": loop.get("function", 0),
        "pc": None,
        "op": -1,
        "name": "JMP",
        "operands": {},
        "roles": {"to": loop_pc},
    }
    return ordered[:loop_at] + [preheader] + body + [loop] + exit_body


def pctrace(result):
    """Every call the payload made, in order, with its arguments filled in."""
    return "\n".join(result.program) + "\n"


def listing(result):
    lines = [f"; afterglow {result.source_path}"]
    found = result.payload_constants
    if found:
        lines.append("")
        lines.append("; ---- payload constants (decrypted by the VM) ----")
        for slot, value in found:
            shown = quoted(value) if isinstance(value, str) else str(value)
            lines.append(";   [%d] = %s" % (slot, shown))
    lines.extend(payload_code(result))

    if not result.payload_instructions or os.environ.get("AFTERGLOW_FULL"):
        for current_layer in result.layers:
            payload = set(current_layer.get("payload", ()))
            only = None if os.environ.get("AFTERGLOW_FULL") or not payload else payload
            lines.extend(render_layer(current_layer, only))
    return "\n".join(lines) + "\n"


def payload_code(result):
    """The payload's own instructions, read out of the running VM.

    These come from watching the VM build them rather than from the
    container, but they are the same opcode space, so they are named from
    the same map the container decode lifted and printed the same way.
    """
    body = result.payload_instructions
    if not body:
        return []
    walked = result.payload_path
    lines = ["", "payload:   ; %d instructions, recovered by running it" % len(body)]
    if walked:
        from afterglow.recovery import observation

        length, count, block = observation.iterations(walked)
        lines.append(";   %d steps executed" % len(walked))
        if count > 1:
            lines.append(
                ";   loop: %d instructions, %d iterations, pcs %s"
                % (length, count, " ".join(str(pc) for pc in block))
            )
    for entry in body:
        line = render_instruction(entry)
        going = entry.get("observed") or []
        if len(going) > 1:
            line += "  also went to %s" % " ".join(str(pc) for pc in going[1:])
        lines.append(line)
    return lines


def render_layer(layer, only=None):
    functions = [
        function
        for function in layer["functions"]
        if only is None or function["id"] in only
    ]
    instructions = layer["instructions"]
    shown_instructions = [
        entry for entry in instructions if only is None or entry["function"] in only
    ]
    lines = [
        "; %d functions, %d instructions, %d strings"
        % (len(functions), len(shown_instructions), len(layer["strings"]))
    ]
    payload = set(layer.get("payload", ()))
    if payload:
        lines.append("; payload functions: %s" % " ".join(str(value) for value in sorted(payload)))
        unresolved = unresolved_constants(instructions, payload)
        if unresolved:
            indexed = sum(
                1 for entry in unresolved if (entry.get("roles") or {}).get("from") is not None
            )
            lines.append(
                "; unresolved payload constants: %d (%d indexed, %d missing index)"
                % (len(unresolved), indexed, len(unresolved) - indexed)
            )
        confidence = confidence_counts(instructions, payload)
        lines.append(
            "; confidence: %s"
            % " ".join(
                "%s %d" % (label, confidence.get(name, 0))
                for name, label in (("witnessed", "seen"), ("static", "static"), ("inferred", "inf"), ("unresolved", "unres"))
            )
        )
    for value in layer["strings"]:
        lines.append("; %s" % quoted(value))
    lines.extend(render_constants(layer))
    lines.extend(render_environment(layer))

    for function in functions:
        body = [entry for entry in instructions if entry["function"] == function["id"]]
        if not body:
            continue
        lines.append("")
        notes = []
        if function["id"] in payload:
            notes.append("payload")
        if not function["complete"]:
            notes.append("partial")
        suffix = "   ; " + ", ".join(notes) if notes else ""
        lines.append("func %d:%s" % (function["id"], suffix))
        for current_instruction in body:
            lines.append(render_instruction(current_instruction))
    return lines


def unresolved_constants(instructions, payload):
    return [
        entry
        for entry in instructions
        if entry["function"] in payload
        and entry["name"] == "LOADK"
        and "constant" not in entry
    ]


def confidence_counts(instructions, payload):
    found = {}
    for entry in instructions:
        if entry["function"] not in payload:
            continue
        name = entry.get("confidence", "unresolved")
        found[name] = found.get(name, 0) + 1
    return found


def render_constants(layer):
    """The container's whole constant pool, by index.

    An instruction's constant operand is an index into this, so the pool is
    what makes the listing readable on its own: a K[214] in a body can be
    looked up here without running anything.
    """
    flat = layer.get("flat") or []
    if not flat:
        return []
    lines = ["", "; constants: %d" % len(flat)]
    for index, item in enumerate(flat, start=1):
        lines.append(";   [%d] = %s" % (index, render_value(item)))
    return lines


def render_environment(layer):
    """Luraph's cached-global table, slot by slot."""
    slots = layer.get("environment") or {}
    if not slots:
        return []
    lines = ["", "; environment: %d slots" % len(slots)]
    for slot in sorted(slots):
        kind, value = slots[slot]
        shown = quoted(value) if kind == "string" else value
        lines.append(";   env[%d] = %s" % (slot, shown))
    return lines


def render_value(value):
    if isinstance(value, bytes):
        return quoted(value.decode("latin-1"))
    if isinstance(value, str):
        return quoted(value)
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float) and value.is_integer():
        return "%d" % int(value)
    return str(value)


def format_operand(value):
    """An operand as the listing spells it.

    A constant column holds the payload's own strings, so not every operand
    formats as a number.
    """
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return "%g" % value
    return repr(value)


def render_instruction(instruction):
    operands = " ".join(
        f"{slot}={format_operand(value)}" for slot, value in sorted(instruction["operands"].items())
    )
    code = instruction.get("text") or ""
    line = "  %4d  %-3d %-11s %s" % (
        instruction["pc"],
        instruction["op"],
        instruction["name"],
        code,
    )
    notes = []
    if operands:
        notes.append(operands)
    if "patched_from" in instruction:
        notes.append("patched over %d at runtime" % instruction["patched_from"])
    if not notes:
        return line.rstrip()
    return "%-*s ; %s" % (WIDTH, line[:WIDTH], "  ".join(notes))


def quoted(value):
    out = ['"']
    for char in value:
        if char == '"':
            out.append('\\"')
        elif char == "\\":
            out.append("\\\\")
        elif char == "\n":
            out.append("\\n")
        elif not 32 <= ord(char) < 127:
            out.append("\\%d" % ord(char))
        else:
            out.append(char)
    out.append('"')
    return "".join(out)


def source(result):
    """The rebuilt functions with exact runtime evidence kept as comments."""
    function_lines = render_functions(result)
    if not function_lines:
        return ""
    return (
        "\n".join(
            [f"-- afterglow {result.source_path}"]
            + credit()
            + helper_payload(result)
            + function_lines
        )
        + "\n"
    )


def helper_payload(result):
    """What running the payload gave up: its calls and its own constants.

    Everything under `-- func` below this is Luraph's runtime — the container
    holds the VM, not the script. This is the script.
    """
    found = result.payload_constants
    watched = result.observation or {}
    calls = watched.get("printed") or watched.get("calls") or []
    if not found and not calls:
        return []

    lines = ["", "-- ---- recovered payload ----"]
    if calls:
        lines.append("-- calls the payload made, in order:")
        for call in calls:
            lines.append("--   " + call)
    if found:
        lines.append("-- constants the VM decrypted (absent from the container):")
        for slot, value in found:
            shown = quoted(value) if isinstance(value, str) else repr(value)
            lines.append("--   [%d] = %s" % (slot, shown))
    return lines


def decompiled(result):
    """The rebuilt functions on their own, for when the trace is its own file."""
    lines = (
        [f"-- afterglow {result.source_path}"]
        + credit()
        + helper_payload(result)
        + render_functions(result)
    )
    return "\n".join(lines) + "\n"


def credit():
    """Which decompiler rebuilt the bodies. They disagree, and the browser
    cannot run the same one the terminal does, so the file says."""
    name = decompile.used()
    return [f"-- functions decompiled by {name}"] if name else []


def render_functions(result):
    lines = []
    for layer in result.layers:
        for function in layer["code"]:
            lines.append("")
            share = "%d/%d" % (function["emitted"], function.get("considered") or function["total"])
            if not function["lines"]:
                lines.append(f"-- func {function['function']} {share} (nothing read)")
                continue
            partial = (
                ""
                if function["emitted"] * 2 >= (function.get("considered") or function["total"])
                else " (partial)"
            )
            lines.append(f"-- func {function['function']} {share}{partial}")
            lines.extend(function["lines"])
    return lines
