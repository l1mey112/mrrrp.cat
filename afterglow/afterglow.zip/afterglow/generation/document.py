def document(result):
    return {
        "source": str(result.source_path),
        "program": result.program,
        "strings": merge(result, "strings"),
        "instructions": merge(result, "instructions"),
        "code": merge(result, "code"),
    }


def merge(result, field):
    merged = []
    for layer in result.layers:
        for item in layer[field]:
            if item not in merged:
                merged.append(item)
    return merged
