import os
import struct

from afterglow.recovery import control_flow as structure
from afterglow.recovery import environment as environ

MOVE, LOADK, LOADBOOL, LOADNIL = 0, 1, 2, 3
GETUPVAL, GETGLOBAL, GETTABLE = 4, 5, 6
SETGLOBAL, SETUPVAL, SETTABLE, NEWTABLE, SELF = 7, 8, 9, 10, 11
ADD, SUB, MUL, DIV, MOD, POW = 12, 13, 14, 15, 16, 17
UNM, NOT, LEN, CONCAT, JMP = 18, 19, 20, 21, 22
EQ, LT, LE, TEST = 23, 24, 25, 26
CALL, RETURN, TFORLOOP, SETLIST, CLOSURE, VARARG = 28, 30, 33, 34, 36, 37

ARITHMETIC = {"ADD": ADD, "SUB": SUB, "MUL": MUL, "DIV": DIV, "MOD": MOD, "POW": POW}
UNARY = {"UNM": UNM, "NOT": NOT, "LEN": LEN}

COMPARISON = {
    "EQ": (EQ, 1),
    "NE": (EQ, 0),
    "LT": (LT, 1),
    "GE": (LT, 0),
    "LE": (LE, 1),
    "GT": (LE, 0),
}
MAX_UPVALUE = 64

MAX_ARGUMENTS = 8
MAX_REGISTER = 180
MAX_CONSTANT = 255


class Chunk:

    def __init__(self):
        self.names = []
        self.code = []
        self.constants = []
        self.index = {}
        self.highest = 1
        self.upvalues = 0
        self.scratch = MAX_REGISTER + 1
        self.protos = []
        self.children = None
        self.path = ()
        self.iterators = {}
        self.iterator_entries = {}

    def closure(self):
        self.protos.append(placeholder())
        return len(self.protos) - 1

    def nest(self, proto):
        self.protos.append(proto)
        return len(self.protos) - 1

    def upvalue(self, index):
        self.upvalues = max(self.upvalues, index + 1)
        return index

    def constant(self, value):
        key = (type(value).__name__, value)
        if key not in self.index:
            self.index[key] = len(self.constants)
            self.constants.append(value)
        return self.index[key]

    def uses(self, register):
        self.highest = max(self.highest, register)
        return register

    @property
    def registers(self):
        return min(self.highest + 2, 250)


DEEP = 6


def lua_chunk(instructions, children=None, linearize=True):
    chunk, emitted, considered = lowered(instructions, children, linearize=linearize)
    return write(chunk), emitted, considered


def bundle(bodies, names=(), children=(), paths=()):
    """Every recovered function in one chunk, as ordinary Lua 5.1 bytecode.

    Which decompiler reads this best is not afterglow's question to settle —
    recovering the bytecode is the work, and turning stock 5.1 bytecode back
    into source is a problem with many tools and no shortage of opinions. So
    hand the reader the chunk and let them take it wherever they like.
    """
    nested, code = [], []
    for index, instructions in enumerate(bodies):
        descendants = children[index] if index < len(children) else None
        path = (paths[index],) if index < len(paths) else ()
        chunk, _emitted, _considered = lowered(instructions, descendants, path)
        named = names[index] if index < len(names) else None
        nested.append(helper_proto(chunk, named=named))
        code.append(encode_bx(CLOSURE, index, index))

        code.extend(encode(MOVE, 0, 0, 0) for _ in range(chunk.upvalues))
    code.append(encode(RETURN, 0, 1, 0))

    main = Chunk()
    main.code = code
    main.highest = max(len(bodies), 1)
    return header() + helper_proto(main, nested)


def lowered(instructions, children=None, path=(), linearize=True):
    chunk = Chunk()
    chunk.children = children
    chunk.path = path
    instructions = structure.linear(instructions) if linearize else list(instructions)
    built = helper_built(instructions)

    count_arguments(instructions, built, ())
    theirs = bookkeeping(instructions)

    built = helper_built(instructions, theirs)
    count_arguments(instructions, built, theirs)
    chunk.scratch = helper_scratch(instructions)
    plan_iterators(chunk, instructions)

    chunk.names = locals(instructions)
    positions, emitted, jumps, skipped = {}, [], [], 0
    for index, instruction in enumerate(instructions):
        standing = stands_still(instructions, index)
        mine = standing or index in theirs or scaffolding(instruction, built)
        lowered = None if mine else lower(chunk, instruction, built)
        if instruction["pc"] is not None:
            pc = instruction["pc"]
            positions[pc] = len(chunk.code)
            chunk.code.extend(chunk.iterator_entries.get(pc, ()))
        if lowered is None:
            skipped += bool(mine)
            continue
        words, jump_at = lowered
        start = len(chunk.code)
        chunk.code.extend(words)
        if jump_at is not None:
            jumps.append((start, start + jump_at, instruction))
        emitted.append(instruction)
    resolve_jumps(chunk, jumps, positions)
    chunk.code.append(encode(RETURN, 0, 1, 0))
    fit_registers(chunk)
    return chunk, len(emitted), len(instructions) - skipped


def plan_iterators(chunk, instructions):
    """Reserve canonical Lua 5.1 iterator registers before lowering.

    Luraph's iterator handler writes yielded values beside its virtual base,
    while Lua 5.1 reserves A..A+2 for the iterator triple and writes results
    at A+3. Keep the triple in scratch registers and copy yielded values at
    the loop body entry. Planning this first lets every jump to that entry
    land on the copies, including backward and out-of-order control flow.
    """
    calls = {}
    for instruction in instructions:
        if instruction["name"] != "CALL" or instruction.get("called") not in ("pairs", "ipairs"):
            continue
        function = (instruction.get("roles") or {}).get("function")
        if function is not None:
            calls[int(function)] = instruction
    for instruction in instructions:
        if instruction["name"] != "TFORLOOP":
            continue
        roles = instruction.get("roles") or {}
        base, landing, count = roles.get("target"), roles.get("to"), roles.get("count")
        if (
            base is None
            or landing is None
            or int(base) not in calls
            or count is None
            or not 0 < count <= MAX_ARGUMENTS
        ):
            continue
        base, landing, count = int(base), int(landing), int(count)
        scratch = chunk.scratch
        chunk.scratch += 3 + count
        chunk.iterators[base] = scratch
        copies = []
        for offset in range(1, count + 1):
            chunk.uses(base + offset)
            chunk.uses(scratch + 2 + offset)
            copies.append(encode(MOVE, base + offset, scratch + 2 + offset, 0))
        chunk.iterator_entries[landing] = copies


JUMPS = ("JMP", "JMPIF", "FORLOOP", "TFORLOOP")

KEYWORDS = {
    "and",
    "break",
    "do",
    "else",
    "elseif",
    "end",
    "false",
    "for",
    "function",
    "if",
    "in",
    "local",
    "nil",
    "not",
    "or",
    "repeat",
    "return",
    "then",
    "true",
    "until",
    "while",
}

NAMED = ("GETGLOBAL", "GETTABLE", "SELF")

POOL = "imports"


def names(instructions):
    return locals(structure.linear(instructions))


def locals(instructions):
    proposed = {}
    for instruction in instructions:
        register = helper_target(instruction)
        if register is None:
            continue
        found = suggestion(instruction)
        if found:
            proposed.setdefault(register, []).append(found)

    names, taken = {}, helper_reached(instructions)
    for register in pools(instructions):
        names[register] = unique(POOL, taken)
    for register, options in proposed.items():
        if register in names:
            continue
        chosen = max(set(options), key=options.count)
        if options.count(chosen) * 2 >= len(options):
            names[register] = unique(chosen, taken)
    return names


def helper_reached(instructions):
    found = set()
    for instruction in instructions:
        if instruction["name"] != "GETGLOBAL":
            continue
        constant = instruction.get("constant")
        if isinstance(constant, str) and constant.isidentifier():
            found.add(constant)
    return found


def pools(instructions):
    found = set()
    for instruction in instructions:
        roles = instruction.get("roles") or {}
        if roles.get("table_kind") == "POOL" and roles.get("table") is not None:
            found.add(int(roles["table"]))
    return sorted(found)


def suggestion(instruction):
    if instruction["name"] not in NAMED:
        return None
    constant = instruction.get("constant")
    if not isinstance(constant, str) or constant in KEYWORDS:
        return None
    if not constant.isidentifier() or not constant.isascii():
        return None
    return constant


def unique(name, taken):
    candidate, suffix = name, 1
    while candidate in taken:
        suffix += 1
        candidate = "%s_%d" % (name, suffix)
    taken.add(candidate)
    return candidate


def stands_still(instructions, index):
    """A jump onto the instruction after it — including a test whose two arms
    are the same instruction, which decides nothing."""
    instruction = instructions[index]
    went = (instruction.get("roles") or {}).get("to")

    if (
        instruction["name"] not in ("JMP", "JMPIF", "FORLOOP")
        or went is None
        or index + 1 >= len(instructions)
    ):
        return False
    return instructions[index + 1].get("pc") == int(went)


BOOKKEEPING = ("JUNK", "SETUP", "STORE")


def scaffolding(instruction, built):
    if instruction["name"] in BOOKKEEPING:
        return True
    if instruction["name"] not in ("SETTABLE", "LOADNIL"):
        return False
    roles = instruction.get("roles") or {}
    register = roles.get("table" if instruction["name"] == "SETTABLE" else "target")
    return register is not None and int(register) not in built


def count_arguments(instructions, built, theirs=()):
    """How many registers above the callee were filled in as its arguments.

    The obfuscator does not leave a call next to the loads that set it up: it
    shuffles the blocks apart and threads its own bookkeeping between them.
    None of that bookkeeping reaches the chunk, so none of it can disturb an
    argument register, and the walk back has to step over it rather than stop
    at it — stopping is what leaves a call reporting one argument when three
    were laid out for it.
    """
    for index, instruction in enumerate(instructions):
        if instruction["name"] != "CALL":
            continue
        callee = (instruction.get("roles") or {}).get("function")
        if callee is None:
            continue
        filled = set()
        for back in range(index - 1, -1, -1):
            earlier = instructions[back]
            roles = earlier.get("roles") or {}
            if earlier["name"] == "RETURN":
                break
            if earlier["name"] == "JMP":
                went = roles.get("to")
                if went is None or instructions[back + 1].get("pc") != int(went):
                    break
                continue
            if roles.get("to") is not None or back in theirs or scaffolding(earlier, built):
                continue
            target = roles.get("target")
            if target is None:
                target = earlier.get("writes")
            if target is None:
                continue
            if not callee < target <= callee + MAX_ARGUMENTS:
                break
            filled.add(int(target))
        instruction["fills"] = max(filled) - int(callee) if filled else 0


READS = {
    "MOVE": ("from",),
    "UNM": ("from",),
    "NOT": ("from",),
    "LEN": ("from",),
    "ADD": ("left", "right"),
    "SUB": ("left", "right"),
    "MUL": ("left", "right"),
    "DIV": ("left", "right"),
    "MOD": ("left", "right"),
    "POW": ("left", "right"),
    "CONCAT": ("left", "right"),
    "GETTABLE": ("table",),
    "SELF": ("table",),
    "SETTABLE": ("table", "from"),
    "SETGLOBAL": ("from",),
    "SETUPVAL": ("from",),
    "CALL": ("function",),
    "RETURN": ("from",),
}

STORES = (
    "SETTABLE",
    "SETGLOBAL",
    "SETUPVAL",
    "STORE",
    "SETUP",
    "RETURN",
    "JMP",
    "JMPIF",
    "FORLOOP",
    "TFORLOOP",
)


def reads(instruction):
    roles = instruction.get("roles") or {}
    if instruction["name"] == "SETTABLE" and roles.get("value") is not None:
        roles = {key: value for key, value in roles.items() if key != "from"}
    found = set()
    if instruction["name"] == "CALL":

        function = roles.get("function")
        if function is not None and 0 <= function <= MAX_REGISTER:
            count = roles.get("arguments")
            if count is None:
                count = instruction.get("fills") or 0
            for offset in range(1, int(count) + 1):
                if function + offset <= MAX_REGISTER:
                    found.add(int(function) + offset)
    for role in READS.get(instruction["name"], ()):
        value = roles.get(role)
        if value is None or roles.get(role + "_kind") in ("IMM", "NUM"):
            continue
        if 0 <= value <= MAX_REGISTER:
            found.add(int(value))
    return found


def helper_target(instruction):
    if instruction["name"] in STORES:
        return None
    roles = instruction.get("roles") or {}
    target = roles.get("target")
    if target is None and instruction["name"] == "CALL":
        target = roles.get("function")
    if target is None:
        target = instruction.get("writes")
    if target is None or not 0 <= target <= MAX_REGISTER:
        return None
    return int(target)


def interpreters(instructions):
    """Registers holding the interpreter's own state, not the payload's.

    The payload never indexes a local it has not assigned. A register read as
    a table or called, that no instruction ever gives a value of its own —
    every write to it reads it first — was never the payload's; it is the VM
    showing through the register window, and the chain hanging off it is the
    VM's own work rather than the program being recovered.
    """
    reached, writers = set(), {}
    for instruction in instructions:
        roles = instruction.get("roles") or {}
        for role in ("table", "function"):
            value = roles.get(role)
            if value is not None and 0 <= value <= MAX_REGISTER:
                reached.add(int(value))
        target = helper_target(instruction)
        if target is not None:
            writers.setdefault(target, []).append(instruction)

    interpreter_registers = set()
    for register in reached:
        register_writers = writers.get(register)
        if not register_writers:
            continue
        used_by_every_writer = True
        for instruction in register_writers:
            if register not in reads(instruction):
                used_by_every_writer = False
                break
        if used_by_every_writer:
            interpreter_registers.add(register)
    return interpreter_registers


def bookkeeping(instructions):
    """Which instructions are the interpreter's own work rather than the payload's.

    Seeded by the registers the VM keeps its state in, then followed back
    through whatever fills them: the constants loaded to call one of its
    helpers are as much its own as the call. An instruction that nothing reads
    is left alone — that is the shape of payload code whose consumer went
    missing, and dropping it would take real logic with it.
    """
    theirs = interpreters(instructions)
    marked = {
        index
        for index, instruction in enumerate(instructions)
        if helper_target(instruction) in theirs
    }

    changed = True
    while changed:
        changed = False
        for index, instruction in enumerate(instructions):
            if index in marked or helper_target(instruction) is None:
                continue
            readers = helper_readers(instructions, index, helper_target(instruction))
            if readers and all(other in marked for other in readers):
                marked.add(index)
                changed = True
    return marked


def helper_readers(instructions, index, register):
    """Everything that reads what this instruction left, until it is overwritten."""
    found = []
    for at in range(index + 1, len(instructions)):
        if register in reads(instructions[at]):
            found.append(at)
        if helper_target(instructions[at]) == register:
            break
    return found


def helper_built(instructions, theirs=()):
    made = set()
    for index, instruction in enumerate(instructions):
        if index in theirs:
            continue
        if instruction["name"] in ("LOADNIL", "SETTABLE", "SETGLOBAL", "JUNK"):
            continue
        target = (instruction.get("roles") or {}).get("target")
        if target is None:
            target = instruction.get("writes")
        if target is not None:
            made.add(int(target))
    return made


def lower(chunk, instruction, built=None):
    """Lower one recovered instruction to Lua 5.1 words.

    Returns None when nothing faithful can be built, otherwise the words and
    the index of the one that jumps, for `_resolve_jumps` to fill in later.
    """
    name = instruction["name"]
    roles = instruction.get("roles") or {}
    constant = instruction.get("constant")

    def given(role):
        value = roles.get(role)
        if value is None and role == "target":
            value = instruction.get("writes")
        if value is None or not 0 <= value <= MAX_REGISTER:
            return None
        return chunk.uses(int(value))

    def reaching(role):
        """An operand as RK: a register, or a constant when the lifter said so."""
        value = roles.get(role)
        if value is None:
            if roles.get(role + "_kind") in ("IMM", "POOL") and constant is not None:
                return helper_key(chunk, constant)
            return None
        if roles.get(role + "_kind") in ("IMM", "NUM"):
            return helper_key(chunk, None, value)
        return given(role)

    target = given("target")

    if name == "LOADK" and constant is not None and target is not None:
        return helper_one(encode_bx(LOADK, target, chunk.constant(constant)))
    if (
        name == "LOADK"
        and target is not None
        and roles.get("from_kind") in ("IMM", "NUM")
        and roles.get("from") is not None
    ):
        return helper_one(encode_bx(LOADK, target, chunk.constant(roles["from"])))
    if name == "LOADBOOL" and target is not None and roles.get("value") is not None:
        return helper_one(encode(LOADBOOL, target, int(bool(roles["value"])), 0))
    if name == "LOADN" and target is not None and roles.get("value") is not None:
        return helper_one(encode_bx(LOADK, target, chunk.constant(roles["value"])))

    if name == "GETGLOBAL" and isinstance(constant, str) and target is not None:
        return helper_one(encode_bx(GETGLOBAL, target, chunk.constant(constant)))
    if name == "SETGLOBAL" and isinstance(constant, str) and given("from") is not None:
        return helper_one(encode_bx(SETGLOBAL, given("from"), chunk.constant(constant)))
    if name == "SETUPVAL" and given("from") is not None:
        index = chunk.upvalue(upvalue(roles, "upvalue"))
        return helper_one(encode(SETUPVAL, given("from"), index, 0))
    if name == "MOVE" and target is not None and given("from") is not None:
        return helper_one(encode(MOVE, target, given("from"), 0))
    if name == "GETUPVAL" and target is not None:
        return helper_one(encode(GETUPVAL, target, chunk.upvalue(upvalue(roles)), 0))
    if name == "GETFENV" and target is not None:
        return helper_one(encode_bx(GETGLOBAL, target, chunk.constant("_G")))
    if name == "LOADNIL":
        first = target if target is not None else given("from")
        if first is None or (built is not None and first not in built):
            return None
        last = given("through")
        return helper_one(encode(LOADNIL, first, max(first, last or first), 0))
    if name in ARITHMETIC and target is not None:
        left, right = reaching("left"), reaching("right")
        if left is None or right is None or left == right == target:
            return None
        return helper_one(encode(ARITHMETIC[name], target, left, right))
    if name in UNARY and target is not None and given("from") is not None:
        return helper_one(encode(UNARY[name], target, given("from"), 0))
    if name in COMPARISON and target is not None:
        return compare(chunk, name, target, reaching("left"), reaching("right"))
    if name == "CONCAT" and target is not None:
        return joined(chunk, roles, constant, given, target)
    if name == "GETTABLE" and target is not None:
        resolved = instruction.get("env")
        table = given("table")
        if resolved is not None:
            if instruction.get("env_kind") == "string":
                return helper_one(encode_bx(LOADK, target, chunk.constant(resolved)))
            if environ.plain(resolved):
                return helper_one(encode_bx(GETGLOBAL, target, chunk.constant(resolved)))
            key = helper_key(chunk, resolved)
            if table is not None and key is not None:
                return helper_one(encode(GETTABLE, target, table, key))
        key = reaching("key") if roles.get("key_kind") == "REG" else helper_key(chunk, constant, roles.get("key"))
        if table is None or key is None:
            return None
        return helper_one(encode(GETTABLE, target, table, key))
    if name == "SETTABLE":
        table = given("table")
        if built is not None and table is not None and table not in built:
            return None
        key = reaching("key") if roles.get("key_kind") == "REG" else helper_key(chunk, constant, roles.get("key"))

        value = helper_key(chunk, None, roles.get("value"))
        if value is None and roles.get("from_kind") in ("IMM", "NUM"):
            value = helper_key(chunk, None, roles.get("from"))
        if value is None:
            value = given("from")
        if table is None or key is None or value is None:
            return None
        return helper_one(encode(SETTABLE, table, key, value))
    if name == "SELF" and target is not None:

        table, key = given("table"), helper_key(chunk, constant, roles.get("key"))
        if table is None or key is None:
            return None
        return helper_one(encode(SELF, target, table, key))
    if name == "CLOSURE" and target is not None:
        wanted = instruction.get("child")
        body = (chunk.children or {}).get(wanted)
        if body and wanted not in chunk.path and len(chunk.path) < DEEP:
            inner, _emitted, _considered = lowered(body, chunk.children, chunk.path + (wanted,))
            spot = chunk.nest(helper_proto(inner, named="func %d" % wanted))

            words = [encode_bx(CLOSURE, target, spot)]
            words.extend(encode(MOVE, 0, 0, 0) for _ in range(inner.upvalues))
            return words, None
        return helper_one(encode_bx(CLOSURE, target, chunk.closure()))
    if name == "NEWTABLE" and target is not None:
        return helper_one(encode(NEWTABLE, target, 0, 0))
    if name == "SETLIST" and target is not None:
        count = roles.get("count")
        offset = roles.get("offset", 0)
        if (
            count is None
            or offset is None
            or count <= 0
            or offset < 0
            or int(count) != count
            or int(offset) != offset
            or count > MAX_REGISTER - target
        ):
            return None

        if int(offset) % 50:
            return None
        for register in range(target + 1, target + int(count) + 1):
            chunk.uses(register)
        block = int(offset) // 50 + 1
        return helper_one(encode(SETLIST, target, int(count), block))
    if name == "TFORLOOP" and target is not None:
        count = roles.get("count")
        iterator = chunk.iterators.get(target)
        if iterator is None or count is None or not 0 < count <= MAX_ARGUMENTS:
            return None

        return [encode(TFORLOOP, iterator, 0, int(count)), encode_sbx(JMP, 0, 0)], 1
    if name == "VARARG" and target is not None:

        last = given("through")
        wanted = last - target + 1 if last is not None and last >= target else 1
        return helper_one(encode(VARARG, target, min(wanted, MAX_ARGUMENTS * 4) + 1, 0))
    if name == "CALL":
        function = given("function")
        if function is None:
            return None
        results = roles.get("results")
        chunk.uses(function + (results or 0))
        words = []
        called = instruction.get("called")
        if isinstance(called, str) and called.isidentifier():
            words.append(encode_bx(GETGLOBAL, function, chunk.constant(called)))
        iterator = called in ("pairs", "ipairs")
        result_count = results
        if result_count is None:
            result_count = 1
        required = result_count + 1
        if iterator:
            required = 4
        argument_count = arguments(instruction, function) + 1
        words.append(encode(CALL, function, argument_count, required))
        if iterator:
            scratch = chunk.iterators.get(function)
            if scratch is not None:
                for offset in range(3):
                    chunk.uses(scratch + offset)
                    words.append(encode(MOVE, scratch + offset, function + offset, 0))
        return words, None
    if name == "RETURN":
        first = given("from")
        count = roles.get("count")
        if first is None or count is None:
            return helper_one(encode(RETURN, 0, 1, 0))
        if count == -1:
            return helper_one(encode(RETURN, first, 0, 0))
        if not isinstance(count, (int, float)) or count < 0 or int(count) != count:
            return None
        if count:
            chunk.uses(first + int(count) - 1)
        return helper_one(encode(RETURN, first, int(count) + 1, 0))
    if name in ("JMPIF", "FORLOOP"):
        tested = helper_tested(chunk, roles, reaching)
        return (tested + [encode_sbx(JMP, 0, 0)], len(tested)) if tested is not None else None
    if name == "JMP":
        return helper_one(encode_sbx(JMP, 0, 0), jump_at=0)
    return None


def helper_one(word, jump_at=None):
    return [word], jump_at


def upvalue(roles, role="from"):
    index = roles.get(role)
    if index is None or not 0 <= index < MAX_UPVALUE:
        return 0
    return int(index)


REGISTER_ROLES = ("target", "from", "left", "right", "table", "function", "through")


def helper_scratch(instructions):
    """Two registers clear of everything the payload names, to build concats in.

    Nothing can land between the two loads and the concat that reads them, so
    sitting above the payload's own registers is all these have to do.
    """
    highest = 0
    for instruction in instructions:
        roles = instruction.get("roles") or {}
        for role in REGISTER_ROLES:
            value = roles.get(role)
            if value is None or roles.get(role + "_kind") in ("IMM", "NUM"):
                continue
            if 0 <= value <= MAX_REGISTER:
                highest = max(highest, int(value))
        written = instruction.get("writes")
        if written is not None and 0 <= written <= MAX_REGISTER:
            highest = max(highest, int(written))
    return min(highest + MAX_ARGUMENTS + 1, MAX_REGISTER + 1)


def joined(chunk, roles, constant, given, target):
    left = helper_side(roles, constant, "left", given)
    right = helper_side(roles, constant, "right", given)
    if left is None or right is None:
        return None
    if left[0] == "register" and right[0] == "register" and right[1] == left[1] + 1:
        return helper_one(encode(CONCAT, target, left[1], right[1]))
    first, second = chunk.scratch, chunk.scratch + 1
    chunk.uses(second)
    return [
        placed(chunk, first, left),
        placed(chunk, second, right),
        encode(CONCAT, target, first, second),
    ], None


def helper_side(roles, constant, side, given):
    """One end of a concat: a register to copy in, or a constant to load."""
    kind = roles.get(side + "_kind")
    if roles.get(side) is None:

        return ("constant", constant) if kind in ("IMM", "POOL") and constant is not None else None
    if kind in ("IMM", "NUM"):
        return ("constant", roles[side])
    register = given(side)
    return ("register", register) if register is not None else None


def placed(chunk, register, held):
    kind, value = held
    if kind == "register":
        return encode(MOVE, register, value, 0)
    return encode_bx(LOADK, register, chunk.constant(value))


def compare(chunk, name, target, left, right):
    """A comparison whose result the payload keeps: test, then two LOADBOOLs.

    Lua has no compare-into-register opcode; this is the shape luac itself
    emits for `x = a < b`.
    """
    if left is None or right is None:
        return None
    opcode, flag = COMPARISON[name]
    return [
        encode(opcode, flag, left, right),
        encode_sbx(JMP, 0, 1),
        encode(LOADBOOL, target, 0, 1),
        encode(LOADBOOL, target, 1, 0),
    ], None


FALLS_THROUGH = {
    "==": (EQ, 0),
    "~=": (EQ, 1),
    "<": (LT, 0),
    ">=": (LT, 1),
    "<=": (LE, 0),
    ">": (LE, 1),
    "true": (TEST, 0),
    "false": (TEST, 1),
}


def helper_tested(chunk, roles, reaching):
    test = roles.get("test")
    if test not in FALLS_THROUGH or roles.get("to") is None:
        return None
    opcode, flag = FALLS_THROUGH[test]
    if opcode == TEST:
        if roles.get("left_kind") != "REG":
            return None
        register = reaching("left")
        return None if register is None else [encode(TEST, register, 0, flag)]
    left, right = reaching("left"), reaching("right")
    if left is None or right is None:
        return None
    return [encode(opcode, flag, left, right)]


RK_CONSTANT = 256


def helper_key(chunk, constant, literal=None):
    value = constant if constant is not None else literal
    if value is None:
        return None
    index = chunk.constant(value)
    return None if index >= RK_CONSTANT else RK_CONSTANT + index


def arguments(instruction, function):
    count = (instruction.get("roles") or {}).get("arguments")
    if count is not None:
        return int(count)
    filled = instruction.get("fills")
    return filled if filled else 1


TESTSET, TAILCALL, FORLOOP, FORPREP = 27, 29, 31, 32


def reaches(word):
    """The highest register this instruction touches.

    Lua verifies every register against the prototype's stack size when it
    loads a chunk, and rejects the whole file if one is out of range. Counting
    only the registers an operand names misses the ones an instruction reaches
    implicitly -- a CALL reads its arguments above the callee, SELF writes the
    slot above its target -- and one such miss anywhere in 656 prototypes
    fails the chunk with nothing more specific than "bad code".
    """
    op = word & 0x3F
    a = (word >> 6) & 0xFF
    c = (word >> 14) & 0x1FF
    b = (word >> 23) & 0x1FF
    highest = a
    if op in (GETTABLE, SELF) and b < 256:
        highest = max(highest, b)
    if op == SELF:
        highest = max(highest, a + 1)
    if op in (MOVE, UNM, NOT, LEN, TESTSET):
        highest = max(highest, b)
    if op == LOADNIL:
        highest = max(highest, b)
    if op == CONCAT:
        highest = max(highest, b, c)
    if op in (CALL, TAILCALL):

        highest = max(highest, a + max(b, c) - 1)
    if op == RETURN and b > 0:
        highest = max(highest, a + b - 2)
    if op == VARARG and b > 0:
        highest = max(highest, a + b - 2)
    if op == SETLIST:
        highest = max(highest, a + b)
    if op in (FORLOOP, FORPREP):
        highest = max(highest, a + 3)
    if op == TFORLOOP:
        highest = max(highest, a + 2 + c)
    for operand in (b, c):
        if op in (ADD, SUB, MUL, DIV, MOD, POW, EQ, LT, LE, SETTABLE) and operand < 256:
            highest = max(highest, operand)
    return highest


def fit_registers(chunk):
    for word in chunk.code:
        chunk.uses(reaches(word))


def resolve_jumps(chunk, jumps, positions):
    landing, spans = {}, {}
    for start, offset, instruction in jumps:
        target = (instruction.get("roles") or {}).get("to")
        if target is None or int(target) not in positions:
            erase(chunk, start, offset)
            continue
        jump = positions[int(target)] - offset - 1
        if not -131071 <= jump <= 131071:
            erase(chunk, start, offset)
            continue
        if jump == 0:

            erase(chunk, start, offset)
            continue
        if jump == -1:

            erase(chunk, start, offset)
            continue
        landing[offset], spans[offset] = positions[int(target)], start
        chunk.code[offset] = encode_sbx(JMP, 0, jump)


def erase(chunk, start, offset):
    """Drop a jump that leads nowhere, and the test that was steering it."""
    for at in range(start, offset + 1):
        chunk.code[at] = encode(MOVE, 0, 0, 0)


def cycles(landing):
    spinning = set()
    for start in landing:
        seen, at = set(), start
        while at in landing and at not in seen:
            seen.add(at)
            at = landing[at]
        if at == start:
            spinning |= seen
    return spinning


def encode(opcode, a, b, c):
    return (opcode & 0x3F) | ((a & 0xFF) << 6) | ((c & 0x1FF) << 14) | ((b & 0x1FF) << 23)


def encode_bx(opcode, a, bx):
    return (opcode & 0x3F) | ((a & 0xFF) << 6) | ((bx & 0x3FFFF) << 14)


def encode_sbx(opcode, a, sbx):
    return encode_bx(opcode, a, sbx + 131071)


SIZE_T = int(os.environ.get("AFTERGLOW_SIZE_T") or struct.calcsize("P"))


def widths(size_t):
    """Write chunks for a reader of this pointer width."""
    global SIZE_T
    SIZE_T = size_t


def header():
    return bytes([0x1B]) + b"Lua" + bytes([0x51, 0, 1, 4, SIZE_T, 4, 8, 0])


def size():
    return "<Q" if SIZE_T == 8 else "<I"


def write(chunk):
    return header() + helper_proto(chunk)


def helper_proto(chunk, nested=(), named=None):
    out = bytearray()

    out += string(named)
    out += struct.pack("<II", 0, 0)
    out += bytes([chunk.upvalues, 0, 2, chunk.registers])
    out += struct.pack("<I", len(chunk.code))
    for instruction in chunk.code:
        out += struct.pack("<I", instruction & 0xFFFFFFFF)
    out += helper_constants(chunk.constants)
    protos = list(nested) + chunk.protos
    out += struct.pack("<I", len(protos))
    for proto in protos:
        out += proto
    out += struct.pack("<II", 0, 0)
    out += struct.pack("<I", chunk.upvalues)
    for index in range(chunk.upvalues):
        out += string("upvalue_%d" % index)
    return bytes(out)


def placeholder():
    """A function with no body, for a closure whose body was not attributed here.

    The payload's functions are all listed in their own right; what this stands
    for is the fact that one was made at this point.
    """
    out = bytearray()
    out += string(None)
    out += struct.pack("<II", 0, 0)
    out += bytes([0, 0, 2, 2])
    out += struct.pack("<I", 1)
    out += struct.pack("<I", encode(RETURN, 0, 1, 0) & 0xFFFFFFFF)
    out += struct.pack("<I", 0)
    out += struct.pack("<I", 0)
    out += struct.pack("<III", 0, 0, 0)
    return bytes(out)


def helper_constants(constants):
    out = bytearray(struct.pack("<I", len(constants)))
    for value in constants:
        if isinstance(value, bool):
            out += bytes([1, int(value)])
        elif isinstance(value, (int, float)):
            out += bytes([3]) + struct.pack("<d", float(value))
        else:
            out += bytes([4]) + string(value)
    return bytes(out)


def string(value):
    if value is None:
        return struct.pack(size(), 0)
    data = value.encode("latin-1", "replace") + b"\0"
    return struct.pack(size(), len(data)) + data
