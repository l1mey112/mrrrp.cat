import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from afterglow.config import VENDOR_ROOT
from afterglow.parsing.tokenizer import tokenize

from . import emitter as emit
from . import optimizer as fold

TIMEOUT = 120

CLUA = VENDOR_ROOT / "cluadecompiler"
JAR = VENDOR_ROOT / "unluac.jar"

active_decompiler = None
active_decompiler_name = None
last_decompiler_name = None


def decompiler(run, name="custom"):
    global active_decompiler, active_decompiler_name
    active_decompiler = run
    active_decompiler_name = name


def used():
    """Which decompiler produced the last output, for the file to say so."""
    return last_decompiler_name


class Backend:
    """A decompiler afterglow can hand a chunk to.

    `folds` says whether it leaves the temporaries where the bytecode put
    them. unluac writes one statement per instruction and expects someone
    else to put the expressions back together; cLuaDecompiler reads the chunk
    into SSA and does that itself, so folding its output again would only
    take it apart.
    """

    __slots__ = ("name", "command", "folds")

    def __init__(self, name, command, folds):
        self.name = name
        self.command = command
        self.folds = folds

    def run(self, path):
        try:
            done = subprocess.run(
                self.command + [str(path)], capture_output=True, text=True, timeout=TIMEOUT
            )
        except (OSError, subprocess.SubprocessError):
            return None
        if done.returncode != 0 or not done.stdout.strip():
            return None
        return done.stdout


def backends():
    """The decompilers available here, best first.

    unluac leads because it is the literal one. cLuaDecompiler reads better —
    it recovers method calls and constants unluac leaves spelled out — but it
    drops what it believes is dead, and a chunk afterglow recovered is lossy
    enough that "dead" often means the consumer is what went missing. On
    `gui.lua` it deletes a store to a table field, which is a side effect no
    decompiler may drop, and substitutes `nil` for registers it cannot
    resolve. Being wrong quietly is worse than being verbose.

    Set `AFTERGLOW_DECOMPILER` to one of their names to pin the choice.
    """
    found = []
    if JAR.is_file() and shutil.which("java"):
        found.append(Backend("unluac", ["java", "-jar", str(JAR)], folds=True))
    if CLUA.is_file() and os.access(CLUA, os.X_OK):
        found.append(Backend("cluadecompiler", [str(CLUA), "--dec"], folds=False))
    wanted = os.environ.get("AFTERGLOW_DECOMPILER")
    if wanted:
        return [backend for backend in found if backend.name == wanted]
    return found


def available():
    return active_decompiler is not None or bool(backends())


def source(instructions, children=None):
    if not instructions or not available():
        return None
    chunk, emitted, considered = emit.lua_chunk(instructions, children)
    recovered = decompiled(chunk)
    if recovered is None:
        return None
    lines, folds = recovered
    lines = fold.fold(lines) if folds else trimmed(lines)
    return {
        "lines": renamed(lines, emit.names(instructions)),
        "emitted": emitted,
        "total": len(instructions),
        "considered": considered,
    }


def renamed(lines, names):
    if not names:
        return lines
    text = "\n".join(lines)
    out, at = [], 0
    for token in tokenize(text):
        if token.kind != "name":
            continue
        found = local(token.text, names)
        if found is None:
            continue
        out.append(text[at : token.start])
        out.append(found)
        at = token.start + len(token.text)
    out.append(text[at:])
    return "".join(out).split("\n")


def local(text, names):
    if not text.startswith("L"):
        return None
    register, _, version = text[1:].partition("_")
    if not register.isdigit() or not version.isdigit():
        return None
    found = names.get(int(register))
    if found is None:
        return None
    return found if version == "1" else "%s_%s" % (found, version)


def decompiled(chunk):
    global last_decompiler_name
    if active_decompiler is not None:
        text = active_decompiler(chunk)
        if not text:
            return None
        last_decompiler_name = active_decompiler_name
        return text.splitlines(), True

    with tempfile.TemporaryDirectory(prefix="afterglow-luac-") as scratch:
        path = Path(scratch) / "function.luac"
        path.write_bytes(chunk)
        for backend in backends():
            text = backend.run(path)
            if text is not None:
                last_decompiler_name = backend.name
                return text.splitlines(), backend.folds
    return None


def trimmed(lines):
    """Drop the banner a decompiler prints above what it recovered."""
    start = 0
    while start < len(lines) and (
        not lines[start].strip() or lines[start].lstrip().startswith("--")
    ):
        start += 1
    end = len(lines)
    while end > start and not lines[end - 1].strip():
        end -= 1
    return lines[start:end]
