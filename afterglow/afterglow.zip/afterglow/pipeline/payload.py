import json

from afterglow import log
from afterglow.generation import decompiler as decompile
from afterglow.generation import disassembler as disasm
from afterglow.recovery import lifter as lift
from afterglow.recovery import resolver as resolve

FUSE_SPAN = 4


def helper_witnessed(found):
    """The opcode stream of the prototype the locator pinned as the payload.

    The locator already ranks its own evidence -- a missing-host boundary
    first, a witnessed call to a watched global after it -- and reports the
    winner as `payload`, so that is what to take. The older fields stay as a
    fallback for a locator that predates it.
    """
    payload = (found or {}).get("payload")
    if payload:
        return [int(op) for op in payload]
    for entry in (found or {}).get("witnessed") or []:
        code = entry.get("code")
        if code:
            return [int(op) for op in code]
    candidate = (found or {}).get("candidate")
    if candidate:
        return [int(op) for op in candidate]
    return None


def helper_witnessed_pool(found):
    """The payload's own constant pool, identified rather than inferred: it
    is the table holding the wrapper the VM was handed for a global."""
    pool = (found or {}).get("pool")
    if not pool:
        return None
    values = {}
    for key, value in pool.items():
        try:
            values[int(key)] = value
        except (TypeError, ValueError):
            continue

    numbers = [value for value in values.values() if not isinstance(value, str)]
    if len(numbers) > 1 and len(set(numbers)) == 1:
        values = {slot: value for slot, value in values.items() if isinstance(value, str)}
    return values or None


def report(watched):
    """Say what running the payload gave up, while it is still the news."""
    if not watched:
        log.say("the payload did not run under luau")
        return
    calls = watched.get("printed") or watched.get("calls") or []
    for call in calls[:40]:
        log.say("  payload: " + call)
    if len(calls) > 40:
        log.say("  payload: ... and %d more" % (len(calls) - 40))


def dump_constants(values):
    """Print the identified payload pool immediately after Luau observation."""
    values = list(values or [])
    if not values:
        log.say("constant pool: no constants recovered")
        return
    log.say("constant pool: %d constants recovered" % len(values))
    for slot, value in values:
        if isinstance(value, str):
            shown = json.dumps(value, ensure_ascii=True)
        elif value is True:
            shown = "true"
        elif value is False:
            shown = "false"
        elif value is None:
            shown = "nil"
        else:
            shown = str(value)
        log.say("  [%d] = %s" % (slot, shown))


def decompile_payload(body, layers):
    """Hand the payload's instructions to the decompiler.

    The listing is the same shape the container decode produces, so the
    rebuild path takes it unchanged — this is the only reason the payload was
    put in that shape rather than printed straight out.
    """
    if not body or not layers or not decompile.available():
        return
    resolved = resolve.resolved(body, {entry["pc"] for entry in body})
    if not resolved:
        return
    recovered = decompile.source(resolved, {})
    if recovered is None or not recovered["lines"]:
        return
    layers[0]["code"] = [
        {
            "function": "payload",
            "lines": recovered["lines"],
            "decompiled": True,
            "emitted": recovered["emitted"],
            "total": recovered["total"],
            "considered": recovered["considered"] or recovered["total"],
        }
    ]
    log.say("payload decompiled: %d lines" % len(recovered["lines"]))


def fused(sequence, names, fragments, interpreter):
    """Runs of instructions that together perform one operation.

    A handler that only moves values between the interpreter's own locals is
    a fragment: `R=(J);` is not an instruction, and neither is the `R[_]=G;`
    three opcodes later that finally stores the result. A run of them is. Only
    runs made up entirely of fragments are considered, so a complete
    instruction is never swallowed into one.
    """
    register = interpreter.get("register")
    if not register or not fragments:
        return {}
    counter = interpreter.get("counter")
    known = set(interpreter.get("streams") or ()) | {register, interpreter.get("code")}
    groups, at = {}, 0
    while at < len(sequence):
        for span in range(2, FUSE_SPAN + 1):
            run = sequence[at : at + span]
            if len(run) < span:
                break
            if any(names.get(str(op)) not in lift.FRAGMENTS for op in run):
                break
            bodies = [fragments.get(str(op)) for op in run]
            if any(body is None for body in bodies):
                break
            found, where = lift.fuse(bodies, register, counter, None, known)
            if found:
                groups[at] = (span, found, where)
                break
        at += groups.get(at, (1,))[0]
    return groups


def payload_listing(
    watched,
    layers,
    pool,
    prepared,
    located,
    witnessed_pool,
    walked,
    streams=None,
    locator=None,
    function_id=0,
    quiet=False,
):
    """The payload's instructions as listing entries, ready to render.

    Same shape the container decode produces, so the same renderer prints
    them: a name from the lifted opcode map, roles from the column mapping,
    and constants from the pool the VM filled while it ran.
    """
    names, facts, fragments, interpreter = {}, {}, {}, {}
    for layer in layers:
        names.update(layer.get("opcodes") or {})
        fragments.update(layer.get("fragments") or {})
        interpreter.update(layer.get("interpreter") or {})

        for op, seen in (layer.get("semantics") or {}).items():
            facts.setdefault(int(op), {}).update(seen)
        for op, seen in (layer.get("semantics_source") or {}).items():
            facts.setdefault(int(op), {}).update(seen)
    for op, seen in facts.items():
        seen["name"] = names.get(str(op))

    if located is None:
        return []
    from afterglow.recovery import observation

    opcodes_of = located
    rows, opcodes, by_name = None, None, None

    if streams:
        by_name = sorted(streams)
        rows = []
        for at, opcode in enumerate(opcodes_of):
            row = []
            for name in by_name:
                stream = streams[name]
                value = stream[at] if at < len(stream) else None
                row.append(value)
            row.append(opcode)
            rows.append(row)
        opcodes = len(by_name)

    candidates = observation.instructions(watched) if rows is None else ()
    for candidate, guess in candidates:
        if len(candidate) != len(opcodes_of) or not candidate:
            continue
        for column in range(len(candidate[0])):
            if [row[column] for row in candidate] == opcodes_of:
                rows, opcodes = candidate, column
                break
        if rows is not None:
            break
    if rows is None:

        rows = [[op] for op in opcodes_of]
        opcodes = 0
    if not quiet:
        log.say("payload located: %d instructions" % len(rows))

    groups = fused(opcodes_of, names, fragments, interpreter)
    for start, (_span, found, where) in groups.items():
        for role, stream in found["operands"].items():
            if role.endswith("_kind") or where.get(stream) is None:
                continue
            member = opcodes_of[start + where[stream]]
            facts.setdefault(member, {}).setdefault("operands", {})[role] = stream

    everything = observation.merged_constants(watched, pool)
    named = observation.named_slots(watched)

    slots = {
        value
        for row in rows
        for index, value in enumerate(row)
        if index != opcodes and isinstance(value, (int, float)) and not isinstance(value, bool)
    }

    values = witnessed_pool or observation.pool_for(watched, slots) or everything
    if by_name:
        mapping = {}
        for op in set(opcodes_of):
            assigned = {
                role: by_name.index(stream)
                for role, stream in observation.roles(facts, op)
                if stream in streams
            }
            if assigned:
                mapping[op] = assigned
    else:

        mapping = observation.columns(
            rows,
            opcodes,
            facts,
            len(rows),
            pool=everything,
            named=named,
            constant_role=disasm.CONSTANT_ROLE,
        )
        mapping = observation.columns(
            rows,
            opcodes,
            facts,
            len(rows),
            pool=values,
            named=named,
            constant_role=disasm.CONSTANT_ROLE,
        )

    out = []
    for at, row in enumerate(rows, start=1):
        op = row[opcodes]
        entry = {
            "function": function_id,
            "pc": at,
            "op": op,
            "name": names.get(str(op)) or "VM-OP_%d" % op,
            "operands": {
                (by_name[index] if by_name else str(index)): value
                for index, value in enumerate(row)
                if index != opcodes and value is not None and not isinstance(value, dict)
            },
        }

        for value in row:
            if isinstance(value, dict) and value.get("proto"):
                entry["child"] = int(value["proto"])
                break

        roles, literals = {}, {}
        for role, column in (mapping.get(op) or {}).items():
            if column >= len(row) or row[column] is None:
                continue
            found = row[column]
            if isinstance(found, str):
                literals[role] = found
            else:
                roles[role] = found

        for role, value in ((facts.get(op) or {}).get("operands") or {}).items():
            if role in disasm.LITERAL:
                roles[role] = value

        for role, kind in ((facts.get(op) or {}).get("operands") or {}).items():
            if role.endswith("_kind") and role[: -len("_kind")] in roles:
                roles[role] = kind
        if roles:
            entry["roles"] = roles
        if literals:
            entry["literals"] = literals

        role = disasm.CONSTANT_ROLE.get(entry["name"])
        slot = roles.get(role) if role else None
        if role and role in literals:
            entry["constant"] = literals[role]
        elif slot is not None and int(slot) in values:
            entry["constant"] = values[int(slot)]
        entry["text"] = disasm.render(entry)
        out.append(entry)

    for start, (span, found, where) in groups.items():
        head = out[start]
        head["name"] = found["name"]
        gathered = {}
        for role, stream in found["operands"].items():
            if role.endswith("_kind"):
                gathered[role] = stream
                continue
            member = where.get(stream)
            if member is None or start + member >= len(out):
                continue
            value = (out[start + member].get("roles") or {}).get(role)
            if value is not None:
                gathered[role] = value
        head["roles"] = gathered
        role = disasm.CONSTANT_ROLE.get(found["name"])
        slot = gathered.get(role) if role else None
        if isinstance(slot, str):
            head["constant"] = slot
        elif slot is not None and int(slot) in values:
            head["constant"] = values[int(slot)]
        head["text"] = disasm.render(head)
        for step in range(1, span):
            part = out[start + step]
            part["name"] = "..."
            part["roles"] = {}
            part["text"] = "part of %s at pc %d" % (found["name"], head["pc"])

    attach_witnessed_calls(out, locator, opcodes_of)

    went = observation.successors(walked)
    for entry in out:
        for role, value in ((facts.get(entry["op"]) or {}).get("operands") or {}).items():
            if role in disasm.LITERAL and not isinstance(value, str):
                entry.setdefault("roles", {})[role] = value
        going = went.get(entry["pc"])
        if not going:
            continue
        entry["observed"] = list(going)
        roles = entry.setdefault("roles", {})
        if entry["name"] in disasm.JUMPS or len(going) > 1:
            roles["to"] = going[0]
        entry["text"] = disasm.render(entry)
    return out


def attach_witnessed_calls(instructions, found, opcodes):
    """Name CALLs by the host function witnessed at their exact virtual pc."""
    by_pc = {entry["pc"]: entry for entry in instructions}
    for witness in (found or {}).get("witnessed") or []:
        pc = witness.get("pc")
        code = witness.get("code")
        name = witness.get("name")
        if (
            not isinstance(pc, int)
            or not isinstance(name, str)
            or not name.isidentifier()
            or code != opcodes
        ):
            continue
        entry = by_pc.get(pc)
        if entry and entry.get("name") == "CALL":
            entry["called"] = name
