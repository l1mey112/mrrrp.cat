import base64
import json
from pathlib import Path

from afterglow import log
from afterglow.errors import AnalysisError
from afterglow.generation import decompiler as decompile
from afterglow.generation import disassembler as disasm
from afterglow.generation import optimizer as fold
from afterglow.hypocenter import LUA51_HYPOCENTER
from afterglow.lua51 import inspection as bytecode
from afterglow.parsing import expand, state
from afterglow.parsing import prototypes as protos
from afterglow.recovery import dispatcher, semantics
from afterglow.recovery import control_flow as structure
from afterglow.recovery import environment as environ
from afterglow.recovery import interpreter as interpret
from afterglow.recovery import lifter as lift
from afterglow.recovery import resolver as resolve
from afterglow.runtime import lua

MAX_LAYERS = 10
DELIBERATE = ("afterglow_SATURATED", "afterglow_TIME_LIMIT")
WEAK = disasm.WEAK


def peel(prepared, workdir, skip_runtime_decompile=False):
    layers = []
    buffer_file = None
    seen = set()

    for index in range(MAX_LAYERS):
        layer_dir = workdir / ("layer%02d" % index)
        layer_dir.mkdir()
        layer = run_layer(prepared, layer_dir, buffer_file, skip_runtime_decompile)
        layer["index"] = index
        layers.append(layer)

        prepared, buffer_file = next_layer(layer, seen, layer_dir)
        if prepared is None:
            break

    return layers


def next_layer(layer, seen, layer_dir):
    sources = []
    buffers = []
    for capture in layer["captures"]:
        if capture["format"] == "lua" and "text" in capture:
            sources.append(capture["text"])
        elif capture["format"] == "bin" and "base64" in capture:
            buffers.append((capture["size"], capture["base64"]))

    sources.sort(key=len, reverse=True)
    buffers.sort(key=lambda item: item[0], reverse=True)

    buffer_file = None
    if buffers:
        buffer_file = layer_dir / "buffer.bin"
        buffer_file.write_bytes(base64.b64decode(buffers[0][1]))

    for source in sources:
        fingerprint = source[:512]
        if fingerprint not in seen:
            seen.add(fingerprint)
            return source, buffer_file
    return None, None


def run_layer(prepared, capture_dir, buffer_file, skip_runtime_decompile=False):
    run = best(prepared, capture_dir, buffer_file)
    return summarize(run, skip_runtime_decompile)


def best(prepared, capture_dir, buffer_file):
    try:
        run = run_once(prepared, capture_dir, buffer_file, dialect=False)
    except (AnalysisError, lua.LuaError):

        run = run_once(prepared, capture_dir, buffer_file, dialect=True)

    if broke(run) and not run["api"]:
        hosted = retry(prepared, capture_dir, buffer_file, run, api=True)
        if helper_recovered(hosted) > helper_recovered(run):
            return hosted

    if run["dialect"] or not run["result"]["failure"] or helper_recovered(run):
        return run

    return retry(prepared, capture_dir, buffer_file, run, dialect=True)


def retry(prepared, capture_dir, buffer_file, run, dialect=False, api=False):
    try:
        again = run_once(prepared, capture_dir, buffer_file, dialect=dialect, api=api)
    except (AnalysisError, lua.LuaError):
        return run
    return again if helper_recovered(again) > helper_recovered(run) else run


def broke(run):
    failure = run["result"]["failure"]
    return bool(failure) and not any(reason in failure for reason in DELIBERATE)


def helper_recovered(run):
    result = run["result"]
    return (
        result["trace"]["steps"]
        + len(result["calls"])
        + len(result["captures"])
        + len(result["transcript"])
    )


def also(inferred, extra):
    for op, facts in extra.items():
        inferred.setdefault(op, {}).update(
            {key: value for key, value in facts.items() if key not in inferred.get(op, {})}
        )
    return inferred


def lift_dispatcher(prepared, dispatch):
    if not dispatch:
        return {}, {}, None, 0, {}, {}
    bodies = dispatcher.handlers(prepared, dispatch["variable"])
    if not bodies:
        return {}, {}, None, 0, {}, {}
    register, streams, pools = lift.tables(bodies, dispatch["counter"])
    if not register:
        return {}, {}, None, len(bodies), {}, {}
    interpreter = set(streams) | {register, dispatch["code"]}
    globals_pool = dispatch.get("globals") or lift.globals_pool(
        bodies, register, dispatch["counter"]
    )

    lifted, facts = {}, {}
    for op, body in bodies.items():
        found = lift.instruction(body, register, dispatch["counter"], globals_pool, interpreter)
        if found and found["name"]:
            lifted[op] = found["name"]
            facts[op] = {"operands": found["operands"], "handler": body[:200]}
    reader = interpret.Reader(bodies, register, streams, dispatch, pools)

    fragments = {
        str(op): body
        for op, body in bodies.items()
        if lifted.get(op) in lift.FRAGMENTS or op not in lifted
    }
    named = {
        "register": register,
        "counter": dispatch["counter"],
        "code": dispatch["code"],
        "streams": sorted(streams),
        "pools": sorted(pools),
    }
    return lifted, facts, reader, len(bodies), fragments, named


def run_once(prepared, capture_dir, buffer_file, dialect, api=False):
    transforms = []
    run_file = capture_dir / "prepared.lua"
    run_file.write_text(prepared, encoding="latin-1")

    if not dialect:
        dialect = not lua.compiles_as_51(run_file)

    api = api or dialect
    ran = prepared
    if dialect:
        from afterglow.hypocenter.server import TRACED_HYPOCENTER
        from afterglow.parsing.dialect import DialectError, luau_to_lua51

        size = len(prepared)
        if size > 400000:
            guess = "a few minutes"
        elif size > 60000:
            guess = "1-2 minutes"
        else:
            guess = "under a minute"
        log.say("luau payload (%d bytes): observing it, usually %s" % (size, guess))
        try:
            ran, transforms = luau_to_lua51(prepared)
        except DialectError as exc:
            raise AnalysisError("dialect transform failed: %s" % exc) from exc
        run_file.write_text(ran, encoding="latin-1")

    out_file = capture_dir / "state.json"
    if dialect:
        hypocenter = TRACED_HYPOCENTER
    else:
        hypocenter = LUA51_HYPOCENTER
    try:
        lua.run(
            hypocenter, [run_file, out_file, capture_dir, buffer_file or ""], shims=dialect, api=api
        )
        result = json.loads(out_file.read_text())
    except lua.LuaError as exc:
        raise AnalysisError(str(exc)) from exc
    except json.JSONDecodeError as exc:
        raise AnalysisError("hypocenter produced invalid JSON: %s" % exc) from exc

    return {
        "result": result,
        "prepared": prepared,
        "ran": ran,
        "dialect": dialect,
        "api": api,
        "transforms": transforms,
    }


def summarize(run, skip_runtime_decompile=False):
    result = run["result"]
    layer = {
        "dialect": {"applied": run["dialect"], "transforms": run["transforms"]},
        "host_stubs": run["api"],
        "transcript": result["transcript"],
        "failure": result["failure"],
        "dispatch": result["dispatch"],
        "calls": result["calls"],
        "protos": result["protos"],
        "captures": [embed(capture) for capture in result["captures"]],
        "trace": result["trace"],
        "taken": result["taken"],
        "strings": state.strings(result),
        "parse": result.get("parse") or [],
    }
    names = disasm.witnessed_names(layer, set(layer["strings"]))
    log.say("reading the interpreter's handlers...")
    lifted, semantics_of, reader, read, fragments, named = lift_dispatcher(
        run["ran"], result["dispatch"]
    )
    for op, name in lifted.items():

        if name in WEAK and names.get(op) == "CALL":
            continue
        names[op] = name

    for op, name in semantics.jump_kinds(result["effects"]).items():
        if op not in lifted:
            names[op] = name
    layer["semantics_source"] = semantics_of
    layer["fragments"] = fragments
    layer["interpreter"] = named
    layer["handlers"] = {"read": read, "lifted": len(lifted)}
    log.dispatcher(result["dispatch"], layer["handlers"]["read"], len(lifted))
    log.say("listing every prototype from the container...")
    layer["opcodes"] = {str(op): name for op, name in names.items()}

    mine = disasm.payload_functions(layer)
    traced = [function for function in result["protos"] if function["id"] in mine]
    layer["functions"] = protos.functions(result, traced)
    at, spare, closure_slot, flat, flat_columns = expand.catalogue(
        run["prepared"], layer["functions"], layer["parse"]
    )
    layer["flat"] = flat or []
    layer["functions"] = layer["functions"] + spare
    tree_children = {}
    if not at:
        layer["functions"], tree_children = protos.closure_tree(result, layer["functions"])

    if run["dialect"]:
        payload = [function["id"] for function in layer["functions"]]
    else:
        payload = list(mine | set(tree_children.values()))
    layer["payload"] = sorted(payload)

    inferred = semantics.infer(result["effects"], result["protos"])
    inferred = also(inferred, semantics.destinations(result["recent"], result["protos"]))
    for op, facts in semantics_of.items():
        inferred.setdefault(op, {}).update(facts)
    layer["semantics"] = {str(op): facts for op, facts in inferred.items()}
    jump_slots = semantics.jumps(result["taken"], layer["functions"])
    witnessed = result["effects"] + result["recent"]
    constant_slots = semantics.constant_slots(
        result["trace"]["loads"], witnessed, layer["functions"]
    )
    globals_at = semantics.global_names(result["trace"]["loads"])
    layer["instructions"] = disasm.listing(
        layer,
        layer["functions"],
        traced,
        names,
        inferred,
        jump_slots,
        constant_slots,
        globals_at,
        reader,
        semantics.transitions(result["taken"]),
        lifted=set(lifted),
        flat=flat,
        flat_columns=flat_columns,
        loaded_at=semantics.loaded_constants(
            result["trace"]["loads"],
            named.get("register"),
            result["effects"],
            result["recent"],
        ),
        pool_values=semantics.pool_constants(result["trace"].get("pools", ()), named.get("pools")),
    )
    executed = {}
    for prototype in result["protos"]:
        program_counters = set()
        for entry in prototype["code"]:
            program_counters.add(entry["pc"])
        executed[prototype["id"]] = program_counters
    log.say("resolving registers and constants...")
    layer["instructions"] = resolve.annotated(
        layer["instructions"],
        executed,
        protos.value_pools(result, result["protos"]),
        protos.global_names(result, (result["dispatch"] or {}).get("globals")),
    )

    runtime_children = {
        (function["id"], instruction["pc"]): set((instruction.get("children") or {}).values())
        for function in result["protos"]
        for instruction in function["code"]
        if instruction.get("children")
    }
    for entry in layer["instructions"]:
        if entry["name"] != "CLOSURE":
            continue
        child = tree_children.get((entry["function"], entry["pc"]))
        if child is not None:
            entry["child"] = child
            continue
        witnessed_children = runtime_children.get((entry["function"], entry["pc"]), set())
        if len(witnessed_children) == 1:
            entry["child"] = next(iter(witnessed_children))
            continue
        if closure_slot is not None:
            found = (entry.get("operands") or {}).get(closure_slot)
            if found in at:
                entry["child"] = at[found]

    log.ran(
        result["trace"]["steps"],
        len(result["calls"]),
        len(layer["functions"]),
        len(layer["strings"]),
    )

    bodies = {}
    for function in layer["functions"]:
        body = [entry for entry in layer["instructions"] if entry["function"] == function["id"]]
        if body:
            bodies[function["id"]] = resolve.resolved(body, executed.get(function["id"], ()))

    fold.deep(run["dialect"])
    slots = environ.discover(bodies) if run["dialect"] else {}
    if slots:
        log.say("naming %d cached globals..." % len(slots))
        for body in bodies.values():
            environ.annotate(body, slots)
        environ.annotate(layer["instructions"], slots)
        for entry in layer["instructions"]:
            if "env" in entry:
                entry["text"] = disasm.render(entry)
    layer["environment"] = slots

    layer["code"] = []
    if skip_runtime_decompile:
        log.say("payload already recovered; not decompiling the runtime")
        return layer
    referenced = {
        entry["child"]
        for body in bodies.values()
        for entry in body
        if entry.get("child") in bodies
    }
    roots = set(payload) - referenced
    if not roots:
        roots = set(payload)
    log.say("decompiling %d root functions..." % len(roots))
    done_functions = 0
    for function in layer["functions"]:
        if function["id"] not in roots:
            continue
        body = bodies.get(function["id"])
        if not body:
            continue
        recovered = decompile.source(body, bodies)
        if recovered is None:
            lines = structure.code(body)
            named = sum(1 for entry in body if not entry["name"].startswith("VM-OP"))
            log.function(function["id"], len(body), named, len(body), len(lines))
            if lines:
                layer["code"].append(
                    {
                        "function": function["id"],
                        "lines": lines,
                        "decompiled": False,
                        "emitted": len(body),
                        "considered": len(body),
                        "total": len(body),
                    }
                )
            continue
        lines = recovered["lines"]
        named = sum(1 for entry in body if not entry["name"].startswith("VM-OP"))
        log.function(function["id"], len(body), named, recovered["emitted"], len(lines))
        done_functions += 1
        if done_functions % 10 == 0:
            log.say("decompiled %d/%d" % (done_functions, len(roots)))
        layer["code"].append(
            {
                "function": function["id"],
                "lines": lines,
                "decompiled": True,
                "emitted": recovered["emitted"],
                "considered": recovered["considered"] or recovered["total"],
                "total": recovered["total"],
            }
        )
    return layer


def embed(capture):
    capture = dict(capture)
    file = capture.pop("file", None)
    if file and Path(file).is_file():
        data = Path(file).read_bytes()
        if capture["format"] == "lua":
            capture["text"] = data.decode("latin-1")
        else:
            capture["base64"] = base64.b64encode(data).decode("ascii")
        if capture["format"] == "luc":
            chunk = bytecode.describe(data)
            if chunk:
                capture["chunk"] = chunk
    return capture
