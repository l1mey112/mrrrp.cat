import os
import tempfile
from pathlib import Path

from afterglow import log
from afterglow.errors import AnalysisError
from afterglow.generation.program import source as program_source
from afterglow.lua51 import inspection as bytecode
from afterglow.models import AnalysisResult
from afterglow.parsing.source import SourceError, prepare
from afterglow.runtime import lua

from .layers import peel
from .payload import (
    decompile_payload,
    dump_constants,
    helper_witnessed,
    helper_witnessed_pool,
    payload_listing,
    report,
)


def analyze(path):
    text = path.read_text(encoding="latin-1")
    log.bytes_read(path.name, len(text))
    try:
        prepared = prepare(text)
    except SourceError as exc:
        raise AnalysisError(str(exc)) from exc

    watched, located, witnessed_pool, walked = None, None, None, []
    found = None
    with tempfile.TemporaryDirectory(prefix="afterglow-") as scratch:
        workdir = Path(scratch)
        chunk = bytecode.of_source(path, workdir)

        dialect_payload = not lua.compiles_as_51(written(prepared, workdir))
        if dialect_payload:
            from afterglow.recovery import observer

            log.say("luau is still currently a work in progress. dumping constant pool...")
        if dialect_payload and not observer.available():
            log.say(
                "no luau runtime here: the listing below is Luraph's runtime, not the payload"
            )
        if dialect_payload and observer.available():
            log.say("observing the payload under luau...")
            watched = observer.observe(text, workdir)
            found = observer.locate(text, workdir)
            located = helper_witnessed(found)
            walked = (found or {}).get("path") or []
            witnessed_pool = helper_witnessed_pool(found)
            report(watched)
            if witnessed_pool:
                dump_constants(sorted(witnessed_pool.items()))

        if watched and not os.environ.get("AFTERGLOW_FULL"):
            os.environ["AFTERGLOW_DISPATCH_ONLY"] = "1"
            try:
                layers = peel(prepared, workdir, skip_runtime_decompile=True)
            finally:
                os.environ.pop("AFTERGLOW_DISPATCH_ONLY", None)
        else:
            layers = peel(prepared, workdir, skip_runtime_decompile=bool(watched))

    program = [line for layer in layers for line in program_source(layer)]
    if any(layer["dialect"]["applied"] for layer in layers):
        log.say("luau payload: container decoded from the parse stream")

    pool = None
    payload_constants = sorted(witnessed_pool.items()) if witnessed_pool else []
    if watched:
        from afterglow.recovery import observation

        seen = {value for layer in layers for value in layer["strings"]}
        for layer in layers:
            seen.update(str(v) for v in (layer.get("flat") or []) if isinstance(v, (str, bytes)))
        pool = observation.payload_pool(watched, seen)
        calls = watched.get("printed") or watched.get("calls") or []
        if not payload_constants:
            payload_constants = observation.constants(pool)
        if not witnessed_pool:
            dump_constants(payload_constants)
        log.say(
            "payload observed: %d calls, %d recovered constants"
            % (len(calls), len(payload_constants))
        )
        if calls and not program:
            program = list(calls)

    body = payload_listing(
        watched,
        layers,
        pool,
        prepared,
        located,
        witnessed_pool,
        walked,
        streams=(found or {}).get("columns"),
        locator=found,
    )

    children = {}
    for child in (found or {}).get("protos") or []:
        listing = payload_listing(
            watched,
            layers,
            pool,
            prepared,
            [int(op) for op in child["code"]],
            witnessed_pool,
            walked,
            streams=child.get("columns"),
            locator=found,
            function_id=int(child["id"]),
            quiet=True,
        )
        if listing:
            children[int(child["id"])] = listing
    if children:
        log.say(
            "payload closures: %d recovered, %d instructions"
            % (len(children), sum(len(one) for one in children.values()))
        )
    decompile_payload(body, layers)

    return AnalysisResult(
        source_path=path,
        bytecode=chunk,
        container=bytecode.largest_string(chunk),
        program=program,
        layers=layers,
        observation=watched,
        payload_constants=payload_constants,
        payload_instructions=body,
        payload_children=children,
        payload_path=walked,
    )


def written(prepared, workdir):
    path = workdir / "probe.lua"
    path.write_text(prepared, encoding="latin-1")
    return path
