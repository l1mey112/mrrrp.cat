import tempfile
from pathlib import Path

from . import log
from .api import analyze_file
from .generation import artifacts as files
from .generation import decompiler as decompile
from .generation import emitter as emit
from .runtime import lua

ACCOUNT_REQUIRED_MESSAGE = (
    "Luau deobfuscation requires an account because it runs on our servers. "
    "Account creation is not available yet."
)


def deobfuscate(name, text, run_lua, write_log, run_luadec=None):
    log.to(write_log)
    lua.runner(guard(run_lua))

    with tempfile.TemporaryDirectory() as scratch:
        safe_name = Path(name).name or "script.lua"
        source = Path(scratch) / safe_name
        source.write_text(text, encoding="latin-1")

        if requires_account(safe_name, source):
            return {
                "status": "account_required",
                "message": ACCOUNT_REQUIRED_MESSAGE,
            }

        emit.widths(4)
        if run_luadec is not None:
            decompile.decompiler(
                lambda chunk: run_luadec(bytes(chunk)),
                name="unluac-rs (wasm)",
            )

        result = analyze_file(source)

        result.source_path = Path(safe_name)

    return {
        "status": "complete",
        "lua": files.decompiled(result),
        "asm": files.listing(result),
        "pctrace": files.pctrace(result),
        "luac": files.chunk(result),
    }


def requires_account(name, source):
    if Path(name).suffix.lower() == ".luau":
        return True
    return not lua.compiles_as_51(source)


def guard(run):
    def call(script, args):
        args = list(args)
        if args and args[-1] in ("", "shims", "api", "shims,api"):
            args[-1] = (args[-1] + ",limit=300").lstrip(",")
        try:
            return run(script, args)
        except Exception as exc:
            detail = str(exc).strip().splitlines()
            raise lua.LuaError(detail[-1] if detail else "runner failed") from exc

    return call
