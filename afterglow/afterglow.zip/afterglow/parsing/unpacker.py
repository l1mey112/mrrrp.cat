from .tokenizer import tokenize

MAGIC = "LPH"
BASE = 85
FIRST = 33
BLANK = "z"
WORD = 4
GROUP = 5
LIMIT = (1 << 32) - 1


def payload(source):
    found = ""
    for token in tokenize(source):
        if token.kind == "string" and token.text.startswith("["):
            body = inside(token.text)
            if len(body) > len(found):
                found = body
    return found


def inside(text):
    level = text.index("[", 1) + 1
    body = text[level : len(text) - level]
    return body[1:] if body.startswith("\n") else body


def unpacked(text):
    if text.startswith(MAGIC):
        text = text[len(MAGIC) + 1 :]
    out = bytearray()
    group = []
    for letter in text:
        if letter == BLANK and not group:
            out += bytes(WORD)
            continue
        group.append(ord(letter) - FIRST)
        if len(group) == GROUP:
            out += word(group)
            group = []
    if group:
        spare = len(group)
        group += [BASE - 1] * (GROUP - spare)
        out += word(group)[: spare - 1]
    return bytes(out)


def word(group):
    value = 0
    for digit in group:
        value = value * BASE + digit
    return (value & LIMIT).to_bytes(WORD, "little")
