MIN_STRING = 2
MAX_BINARY = 256
TEXT = 0.9


def walk(node, path):
    if isinstance(node, dict):
        yield path, node
        for key, value in node.items():
            if key != "$id":
                yield from walk(value, f"{path}.{key}")
    elif isinstance(node, list):
        for index, value in enumerate(node):
            yield from walk(value, f"{path}[{index}]")


def tables(dump):
    for root in dump.get("roots", []):
        yield from walk(root.get("value"), root.get("label", "?"))


def entries(table):
    return [(key, value) for key, value in table.items() if key != "$id"]


def strings(dump):
    found = []
    seen = set()
    for _, table in tables(dump):
        for _, value in entries(table):
            if isinstance(value, str) and not value.startswith("<"):
                if len(value) >= MIN_STRING and value not in seen and is_text(value):
                    seen.add(value)
                    found.append(value)
    return found


def is_text(value):
    if len(value) <= MAX_BINARY:
        return True
    printable = sum(1 for char in value if 32 <= ord(char) < 127 or char in "\n\t")
    return printable / len(value) >= TEXT


def quote(value):
    out = ['"']
    for char in value:
        if char in '"\\':
            out.append("\\" + char)
        elif char == "\n":
            out.append("\\n")
        elif char == "\t":
            out.append("\\t")
        elif not 32 <= ord(char) < 127:
            out.append("\\%d" % ord(char))
        else:
            out.append(char)
    out.append('"')
    return "".join(out)
