PAYLOAD_CALL = "(...)"


class SourceError(RuntimeError):
    pass


def prepare(text):
    text = text.strip().rstrip(";").rstrip()
    if text.endswith(PAYLOAD_CALL):
        return text[: -len(PAYLOAD_CALL)]
    if text.endswith(")"):
        return text
    raise SourceError(
        "this does not look like a protected file: it should end in a call, "
        "normally `(...)`, and this one ends with %r" % text[-24:]
    )
