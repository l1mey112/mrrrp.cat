from .state import is_text


def functions(dump, traced):
    tables = index(dump)
    holders = helper_holders(tables)

    found = []
    for function in traced:
        code = match(tables, function["code"])
        if code is None:
            found.append(from_trace(function))
            continue
        streams = helper_streams(holders.get(id(code)), code, tables) or root_streams(dump, code)
        found.append(
            {
                "id": function["id"],
                "complete": True,
                "constants": helper_constants(streams),
                "pools": helper_pools(streams),
                "instructions": helper_instructions(code, streams, function["code"]),
            }
        )
    return found


def index(dump):
    tables = {}

    def walk(node):
        if isinstance(node, dict):
            if "$id" in node and node["$id"] not in tables:
                tables[node["$id"]] = node
                for key, value in node.items():
                    if key != "$id":
                        walk(value)
        elif isinstance(node, list):
            for value in node:
                walk(value)

    for root in dump.get("roots", []):
        walk(root.get("value"))
    return tables


def closure_tree(dump, functions):
    tables = index(dump)
    roots = {
        root["label"].split(".")[-1]: resolve(root.get("value"), tables)
        for root in dump.get("roots", [])
    }
    code = roots.get((dump.get("dispatch") or {}).get("code"))
    if not isinstance(code, dict):
        return functions, {}
    holders = helper_holders(tables)
    holder = holders.get(id(code))
    if holder is None:
        return functions, {}
    aliases = {}
    code_slot = None
    for slot, value in holder.items():
        stream = resolve(value, tables)
        if stream is code:
            code_slot = slot
        elif isinstance(stream, dict):
            names = [name for name, root in roots.items() if root is stream]
            if len(names) == 1:
                aliases[slot] = names[0]
    if code_slot is None or not aliases:
        return functions, {}
    traced = {function["id"]: function for function in dump["protos"]}
    root_id = None
    for identity, function in traced.items():
        if match(tables, function["code"]) is code:
            root_id = identity
            break
    if root_id is None:
        return functions, {}
    identities = {holder["$id"]: root_id}
    pending = [holder]
    rebuilt, links = {}, {}
    next_id = max((function["id"] for function in functions), default=0) + 1
    for record in pending:
        identity = identities[record["$id"]]
        body = resolve(record[code_slot], tables)
        streams = {}
        for slot, name in aliases.items():
            stream = resolve(record.get(slot), tables)
            if isinstance(stream, dict):
                streams[name] = stream
        for stream in streams.values():
            for pc, value in stream.items():
                child = resolve(value, tables)
                if not pc.isdigit() or not isinstance(child, dict):
                    continue
                if set(child) != set(holder):
                    continue
                child_code = resolve(child.get(code_slot), tables)
                if not isinstance(child_code, dict) or not valid_code(child_code):
                    continue
                child_key = child["$id"]
                if child_key not in identities:
                    identities[child_key] = next_id
                    next_id += 1
                    pending.append(child)
                links.setdefault((identity, int(pc)), set()).add(identities[child_key])
        witnessed = traced.get(identity, {}).get("code", [])
        rebuilt[identity] = {
            "id": identity,
            "complete": True,
            "stream_names": list(streams),
            "constants": helper_constants(streams),
            "pools": helper_pools(streams),
            "instructions": helper_instructions(body, streams, witnessed),
        }
    result = [rebuilt.pop(function["id"], function) for function in functions]
    result.extend(rebuilt.values())
    return result, {key: next(iter(value)) for key, value in links.items() if len(value) == 1}


def valid_code(code):
    entries = {key: value for key, value in code.items() if key != "$id"}
    return bool(entries) and all(
        key.isdigit() and int(key) > 0 and type(value) is int
        for key, value in entries.items()
    )


def resolve(value, tables):
    if isinstance(value, dict) and "$ref" in value:
        return tables.get(value["$ref"])
    return value


def helper_holders(tables):
    holders = {}
    for table in tables.values():
        for key, value in table.items():
            if key == "$id":
                continue
            child = resolve(value, tables)
            if isinstance(child, dict):
                holders.setdefault(id(child), table)
    return holders


AGREEMENT = 0.6


def match(tables, traced_code):
    if not traced_code:
        return None
    wanted = [(str(entry["pc"]), entry["op"]) for entry in traced_code]
    best, best_score = None, 0
    for table in tables.values():
        score = sum(1 for pc, op in wanted if table.get(pc) == op)
        if score > best_score:
            best, best_score = table, score
    if best_score < AGREEMENT * len(wanted):
        return None
    return best


def root_streams(dump, code):
    streams = {}
    for root in dump.get("roots", []):
        value = root.get("value")
        if isinstance(value, dict) and value is not code:
            streams[root["label"].split(".")[-1]] = value
    return streams


def helper_streams(record, code, tables):
    streams = {}
    if not isinstance(record, dict):
        return streams
    for key, value in record.items():
        if key == "$id":
            continue
        stream = resolve(value, tables)
        if isinstance(stream, dict) and stream is not code:
            streams[key] = stream
    return streams


def helper_instructions(code, streams, traced_code):
    executed = {entry["pc"]: entry["op"] for entry in traced_code}
    instructions = []
    for pc in sorted(int(key) for key in code if key != "$id"):
        operands = {}
        present = []
        for slot, stream in sorted(streams.items()):
            key = str(pc)
            if key in stream:
                present.append(slot)
            value = stream.get(key)
            if isinstance(value, (int, float, bool)):
                operands[slot] = value
        stored = code[str(pc)]
        ran = executed.get(pc)
        instruction = {
            "pc": pc,
            "op": ran if ran is not None else stored,
            "operands": operands,
            "present": present,
        }
        if ran is not None and ran != stored:
            instruction["patched_from"] = stored
        constant = constant_at(pc, streams)
        if constant is not None:
            instruction["constant"] = constant
        instructions.append(instruction)
    return instructions


def constant_at(pc, streams):
    found = []
    for stream in streams.values():
        value = stream.get(str(pc))
        if isinstance(value, str) and not value.startswith("<") and is_text(value):
            found.append(value)
    return found[0] if len(set(found)) == 1 else None


def scalar(value):
    if value is None:
        return False
    return isinstance(value, (str, int, float))


def helper_pools(streams):
    pools = {}
    for slot, stream in streams.items():
        values = {
            key: value
            for key, value in stream.items()
            if key != "$id"
            and scalar(value)
            and not (isinstance(value, str) and (value.startswith("<") or not is_text(value)))
        }
        if values:
            pools[slot] = values
    return pools


def helper_constants(streams):
    constants = []
    for slot, stream in streams.items():
        for key, value in stream.items():
            if key == "$id" or not key.lstrip("-").isdigit():
                continue
            if isinstance(value, str) and not value.startswith("<") and is_text(value):
                constants.append({"slot": slot, "index": int(key), "value": value})
    constants.sort(key=lambda entry: (entry["slot"], entry["index"]))
    return constants


def from_trace(function):
    return {
        "id": function["id"],
        "complete": False,
        "constants": [],
        "pools": {},
        "instructions": [
            {"pc": entry["pc"], "op": entry["op"], "operands": entry["operands"]}
            for entry in function["code"]
        ],
    }


POOL_ENTRIES = 20
POOL_TEXT = 0.3
POOL_NAME = 3


def value_pools(dump, traced=()):
    tables = index(dump)
    machinery = {
        root["value"].get("$id")
        for root in dump.get("roots", [])
        if isinstance(root.get("value"), dict)
    }
    machinery |= prototypes(tables, traced)
    found = {}
    for identity, table in tables.items():
        if identity in machinery:
            continue
        keys = [key for key in table if key != "$id"]
        numbered = [key for key in keys if key.lstrip("-").isdigit()]
        text = sum(1 for key in numbered if name_like(table[key]))
        if len(numbered) < POOL_ENTRIES or text < POOL_TEXT * len(numbered):
            continue
        found[identity] = {int(key): table[key] for key in numbered}
    return found


def name_like(value):
    return isinstance(value, str) and len(value) >= POOL_NAME and not value.startswith("<")


def prototypes(tables, traced):
    holders = helper_holders(tables)
    found = set()
    for function in traced:
        code = match(tables, function["code"])
        if code is None:
            continue
        found.add(code.get("$id"))
        holder = holders.get(id(code))
        if not isinstance(holder, dict):
            continue
        for key, value in holder.items():
            if key == "$id":
                continue
            sibling = resolve(value, tables)
            if isinstance(sibling, dict):
                found.add(sibling.get("$id"))
    return found


def global_names(dump, holder):
    for root in dump.get("roots", []):
        label = root.get("label") or ""
        value = root.get("value")
        if label.rpartition(".")[2] != holder or not isinstance(value, dict):
            continue
        found = {}
        for name, entry in value.items():
            if name == "$id" or not isinstance(entry, dict):
                continue
            identity = entry.get("$id") or entry.get("$ref")
            if identity is not None:
                found.setdefault(identity, name)
        return found
    return {}
