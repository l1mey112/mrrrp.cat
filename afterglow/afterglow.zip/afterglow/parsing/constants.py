"""The flat constant array of a Luraph container, decoded from a parse log.

The container stores every constant of every prototype in one flat array:
`[header varint][0x00][entry]* [00 00 00 00]`. An entry is a tag byte plus
a payload whose width the tag picks; tags are randomised per file. The
deserializer reads the array with `buffer.read*` calls, and a log of those
reads (the hypocenter records them) pins almost every tag outright: a
readu16 names the tag byte immediately before it, a readstring names the
byte before its length varint. Only two kinds are invisible in the log,
because their payload is read as plain readu8: the one-byte numbers and
the tag-only marks (booleans and nil, which carry their value in the tag
itself). Those are resolved per segment between anchored reads: a segment
must tile exactly with two-byte pairs and one-byte marks, and the same
byte must mean the same kind everywhere.

A file may end its constants with a run of raw one-byte values (read as
plain readu8 with no tags at all); the tail of the section that nothing
tiles and nothing anchors is that run.
"""

import struct

WIDTH = {"u8": 1, "i8": 1, "u16": 2, "i16": 2, "u32": 4, "i32": 4, "f32": 4, "u64": 8, "f64": 8}
MULTI = {"i32": "readi32", "u16": "readu16", "i16": "readi16", "f32": "readf32", "f64": "readf64"}
MAX_TILINGS = 64
MAX_STATES = 4096
MAX_SEGMENT = 4096


def varint_size(value):
    lead = 1
    while value >= 128**lead:
        lead += 1
    return lead


class Section:
    """One constants section: bytes, the reads that parsed it, a stop."""

    def __init__(self, data, reads, stop):
        self.data = data
        self.stop = stop
        self.ordered = [(off, kind, arg, val) for kind, off, arg, val in reads if 4 <= off < stop]
        self.by_off = {}
        for off, kind, arg, val in self.ordered:
            self.by_off.setdefault(off, []).append((kind, arg, val))

    def anchors(self):
        """[(payload_off, kind, payload_len)] for reads that name a tag."""
        found = []
        consumed = set()
        for i, (off, kind, arg, val) in enumerate(self.ordered):
            if i in consumed:
                continue
            if kind == "readstring":
                found.append((off, "str", int(arg)))
            elif kind in MULTI.values():
                name = kind[4:]
                found.append((off, name, WIDTH[name]))
            elif kind == "readu32":
                nxt = self.ordered[i + 1] if i + 1 < len(self.ordered) else None

                if nxt is not None and nxt[1] == "readu32" and nxt[0] == off + 4:
                    found.append((off, "u64", 8))
                    consumed.add(i + 1)
                else:
                    found.append((off, "u32", 4))
        return found

    def lead(self, off):
        reads = self.by_off[off]
        for kind, arg, val in reads:
            if kind == "readstring":
                return varint_size(int(arg))
        return 1

    def entry_size(self, at, kind):
        if kind == "str":
            size = self.data[at + 1]
            lead = 2
            if size & 0x80:
                size = (size & 0x7F) | (self.data[at + 2] << 7)
                lead = 3
            return lead + size
        return 1 + WIDTH.get(kind, 0)

    def tilings(self, start, end, kinds):
        """Every tiling of [start, end) consistent with `kinds`, bounded."""
        if end - start > MAX_SEGMENT:
            return []
        out = []
        stack = [(start, kinds)]
        while stack and len(out) < MAX_TILINGS:
            at, state = stack.pop()
            if at == end:
                out.append(state)
                continue
            if at > end:
                continue
            tag = self.data[at]
            known = state.get(tag)
            if known == "u8":
                if at + 2 <= end:
                    stack.append((at + 2, state))
                continue
            if known == "MARK":
                stack.append((at + 1, state))
                continue
            if known is not None:
                continue

            marked = dict(state)
            marked[tag] = "MARK"
            stack.append((at + 1, marked))
            if at + 2 <= end:
                paired = dict(state)
                paired[tag] = "u8"
                stack.append((at + 2, paired))
        return out

    def solve(self):
        """Return (kinds, values) for the section, or None."""
        anchors = self.anchors()
        kinds = {}
        for off, kind, _ in anchors:
            tag_off = off - (self.lead(off) + 1 if kind == "str" else 1)
            kinds[self.data[tag_off]] = kind

        spans = []
        cursor = 4
        for off, kind, size in anchors:
            tag_off = off - (self.lead(off) + 1 if kind == "str" else 1)
            if tag_off > cursor:
                spans.append((cursor, tag_off))
            cursor = off + size
        tail = (cursor, self.stop) if self.stop > cursor else None

        state = dict(kinds)
        beam = [state]
        for start, end in spans:
            nxt = []
            for one in beam:
                for tiled in self.tilings(start, end, one):
                    nxt.append(tiled)
            if not nxt:
                return None
            nxt.sort(
                key=lambda one: (
                    sum(1 for v in one.values() if v == "MARK"),
                    sum(1 for v in one.values() if v == "u8"),
                )
            )
            seen = set()
            beam = []
            for one in nxt:
                key = tuple(sorted(one.items()))
                if key in seen:
                    continue
                seen.add(key)
                beam.append(one)
                if len(beam) >= MAX_STATES:
                    break
        for state in beam:
            values = self.decode(state) if tail is None else None
            if values is not None and self.replays(state):
                return state, values

        if tail is not None:
            run = list(self.data[tail[0] : tail[1]])
            for state in beam:
                got = self.decode_with_run(state, tail, run)
                if got[0] is not None:
                    return got
        return None

    def decode_with_run(self, state, tail, run):
        values = self.decode_to(state, tail[0])
        if values is None:
            return None, None
        values.extend(run)
        kinds = state
        if self.replays_run(kinds, tail, len(run)):
            return kinds, values
        return None, None

    def decode(self, kinds):
        return self.decode_to(kinds, self.stop)

    def decode_to(self, kinds, end):
        data = self.data
        values = []
        at = 4
        while at < end:
            kind = kinds.get(data[at])
            if kind is None:
                return None
            if kind == "MARK":
                values.append("mark")
                at += 1
            elif kind == "str":
                size = data[at + 1]
                lead = 2
                if size & 0x80:
                    size = (size & 0x7F) | (data[at + 2] << 7)
                    lead = 3
                values.append(data[at + lead : at + lead + size])
                at += lead + size
            elif kind == "u64":
                lo = int.from_bytes(data[at + 1 : at + 5], "little")
                hi = int.from_bytes(data[at + 5 : at + 9], "little")
                values.append(lo + hi * 4294967296)
                at += 9
            elif kind == "f64":
                values.append(struct.unpack("<d", data[at + 1 : at + 9])[0])
                at += 9
            elif kind == "f32":
                values.append(struct.unpack("<f", data[at + 1 : at + 5])[0])
                at += 5
            elif kind == "u8":
                values.append(data[at + 1])
                at += 2
            else:
                width = WIDTH[kind]
                value = int.from_bytes(data[at + 1 : at + 1 + width], "little")
                if kind[0] == "i" and value >= 1 << (8 * width - 1):
                    value -= 1 << (8 * width)
                values.append(value)
                at += 1 + width
        return values if at == end else None

    def replays(self, kinds):
        return self.replays_run(kinds, None, 0)

    def replays_run(self, kinds, tail, run_len):
        mine = self.reads_of(kinds, tail, run_len)
        theirs = [(off, kind) for off, kind, _, _ in self.ordered]
        if tail is not None:
            stop_read = (self.stop, "readu32")
            theirs = theirs + [stop_read]
        return mine == theirs

    def reads_of(self, kinds, tail, run_len):
        data = self.data
        end = tail[0] if tail is not None else self.stop
        mine = []
        at = 4
        while at < end:
            kind = kinds.get(data[at])
            if kind is None:
                return None
            if kind == "MARK":
                mine.append((at, "readu8"))
                at += 1
            elif kind == "u8":
                mine.append((at, "readu8"))
                mine.append((at + 1, "readu8"))
                at += 2
            elif kind == "str":
                size = data[at + 1]
                lead = 2
                if size & 0x80:
                    size = (size & 0x7F) | (data[at + 2] << 7)
                    lead = 3
                mine.append((at, "readu8"))
                for i in range(lead - 1):
                    mine.append((at + 1 + i, "readu8"))
                mine.append((at + lead, "readstring"))
                at += lead + size
            elif kind == "u64":
                mine.append((at, "readu8"))
                mine.append((at + 1, "readu32"))
                mine.append((at + 5, "readu32"))
                at += 9
            else:
                mine.append((at, "readu8"))
                mine.append((at + 1, MULTI.get(kind, "read" + kind)))
                at += 1 + WIDTH[kind]
        if tail is not None:
            for i in range(run_len):
                mine.append((tail[0] + i, "readu8"))
            mine.append((self.stop, "readu32"))
        return mine


def stop_of(reads):
    for kind, off, arg, val in reads:
        if kind == "readu32" and val in ("n:0", 0):
            return off
    return None


def decode(data, reads):
    """(kinds, values) for the container in `data`, given its parse reads."""
    stop = stop_of(reads)
    if stop is None:
        return None, None
    solved = Section(data, reads, stop).solve()
    return solved if solved is not None else (None, None)
