KEYWORDS = frozenset("""
and break do else elseif end false for function if in local nil not or
repeat return then true until while
""".split())

NAME_START = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
NAME = NAME_START | set("0123456789")
DIGITS = set("0123456789")
HEX = set("0123456789abcdefABCDEF")
SPACE = set(" \t\r\n")

OPERATORS = (
    "...",
    "..",
    "==",
    "~=",
    "<=",
    ">=",
    "+",
    "-",
    "*",
    "/",
    "%",
    "^",
    "#",
    "<",
    ">",
    "=",
    "(",
    ")",
    "{",
    "}",
    "[",
    "]",
    ";",
    ":",
    ",",
    ".",
)


class Token:
    __slots__ = ("kind", "text", "start")

    def __init__(self, kind, text, start):
        self.kind = kind
        self.text = text
        self.start = start

    def __repr__(self):
        return f"{self.kind}:{self.text}"

    def is_(self, kind, text=None):
        return self.kind == kind and (text is None or self.text == text)


def tokenize(source):
    tokens = []
    i, n = 0, len(source)
    while i < n:
        char = source[i]

        if char in SPACE:
            i += 1
        elif source.startswith("--", i):
            i = skip_comment(source, i)
        elif char in NAME_START:
            start = i
            while i < n and source[i] in NAME:
                i += 1
            text = source[start:i]
            tokens.append(Token("keyword" if text in KEYWORDS else "name", text, start))
        elif char in DIGITS or (char == "." and i + 1 < n and source[i + 1] in DIGITS):
            start = i
            i = skip_number(source, i)
            tokens.append(Token("number", source[start:i], start))
        elif char in "\"'":
            start = i
            i = skip_string(source, i)
            tokens.append(Token("string", source[start:i], start))
        elif char == "[" and long_bracket(source, i):
            start = i
            i = long_bracket(source, i)
            tokens.append(Token("string", source[start:i], start))
        else:
            for operator in OPERATORS:
                if source.startswith(operator, i):
                    tokens.append(Token("operator", operator, i))
                    i += len(operator)
                    break
            else:
                i += 1
    return tokens


def skip_comment(source, i):
    end = long_bracket(source, i + 2)
    if end is not None:
        return end
    while i < len(source) and source[i] != "\n":
        i += 1
    return i


def skip_number(source, i):
    n = len(source)
    if source.startswith(("0x", "0X"), i):
        i += 2
        while i < n and source[i] in HEX:
            i += 1
        return i
    while i < n and (source[i] in DIGITS or source[i] == "."):
        i += 1
    if i < n and source[i] in "eE":
        i += 1
        if i < n and source[i] in "+-":
            i += 1
        while i < n and source[i] in DIGITS:
            i += 1
    return i


def skip_string(source, i):
    quote = source[i]
    i += 1
    while i < len(source):
        if source[i] == "\\":
            i += 2
            continue
        if source[i] == quote:
            return i + 1
        i += 1
    return i


def long_bracket(source, i):
    if i >= len(source) or source[i] != "[":
        return None
    j = i + 1
    while j < len(source) and source[j] == "=":
        j += 1
    if j >= len(source) or source[j] != "[":
        return None
    closer = "]" + "=" * (j - i - 1) + "]"
    end = source.find(closer, j + 1)
    return len(source) if end == -1 else end + len(closer)


def number(text):
    try:
        if text.lower().startswith("0x"):
            return int(text, 16)
        return int(text)
    except ValueError:
        try:
            return float(text)
        except ValueError:
            return None


OPENERS = ("if", "while", "for", "function", "repeat")
CLOSERS = ("end", "until")


def closing(tokens, start):
    depth = 0
    for index in range(start, len(tokens)):
        token = tokens[index]
        if token.kind != "operator":
            continue
        if token.text in "([{":
            depth += 1
        elif token.text in ")]}":
            depth -= 1
            if depth == 0:
                return index
    return None


def block_end(tokens, at):
    depth, header = 0, False
    for index in range(at, len(tokens)):
        token = tokens[index]
        if token.kind != "keyword":
            continue
        if token.text in ("while", "for"):
            depth += 1
            header = True
        elif token.text == "do":
            if header:
                header = False
            else:
                depth += 1
        elif token.text in ("if", "function", "repeat"):
            depth += 1
        elif token.text in CLOSERS:
            if depth == 0:
                return index
            depth -= 1
    return None


def header_end(tokens, at, text):
    depth = 0
    for index in range(at, len(tokens)):
        token = tokens[index]
        if token.kind != "keyword":
            continue
        if token.text in OPENERS:
            depth += 1
        elif token.text in CLOSERS:
            depth -= 1
        elif token.text == text and depth == 0:
            return index
    return None


def next_arm(tokens, at, end):
    depth, header = 0, False
    for index in range(at, end):
        token = tokens[index]
        if token.kind != "keyword":
            continue
        if token.text in ("while", "for"):
            depth += 1
            header = True
        elif token.text == "do":
            if header:
                header = False
            else:
                depth += 1
        elif token.text in ("if", "function", "repeat"):
            depth += 1
        elif token.text in CLOSERS:
            depth -= 1
        elif token.text in ("else", "elseif") and depth == 0:
            return index
    return None


def split(tokens, text=","):
    parts, depth, cut = [], 0, 0
    for index, token in enumerate(tokens):
        if token.kind != "operator":
            continue
        if token.text in "([{":
            depth += 1
        elif token.text in ")]}":
            depth -= 1
        elif token.text == text and depth == 0:
            parts.append(tokens[cut:index])
            cut = index + 1
    parts.append(tokens[cut:])
    return parts
