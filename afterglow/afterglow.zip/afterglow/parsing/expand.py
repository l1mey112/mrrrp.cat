import collections

from . import container
from . import unpacker as unpack

SURE = 0.9


def catalogue(source, traced, parse=None):
    empty = ({}, [], None, [], {})
    data = unpack.unpacked(unpack.payload(source))
    if not data:
        return empty
    found = container.decode(data, parse)
    protos, column = found["protos"], found["opcodes"]
    if column is None or not protos:
        return empty
    pairs = matched(protos, column, traced)
    if not pairs:
        return empty
    naming = slots(protos, column, traced, pairs)
    if len(naming) != container.COLUMNS - 1:
        return empty

    flat = found.get("constants", []) or []

    taken = set(pairs.values())
    spare = max((function["id"] for function in traced), default=0) + 1
    extra, at = [], {}
    for number, proto in enumerate(protos):
        if number in taken:
            continue
        at[number] = spare
        extra.append(
            {
                "id": spare,
                "complete": True,
                "constants": {},
                "pools": {},
                "flat": flat,
                "instructions": helper_body(proto, column, naming),
            }
        )
        spare += 1
    for one, number in pairs.items():
        at[number] = one
    return (
        at,
        extra,
        closure_slot(protos, column, naming, len(protos)),
        flat,
        constant_columns(protos, column, pairs, traced, flat),
    )


def constant_columns(protos, column, pairs, traced, flat):
    """Per opcode, the container column whose raw value is the flat
    constant's index. Voted from traced functions: every constant their
    pools remember, checked against the matched prototype's raw rows."""
    by_id = {function["id"]: function for function in traced}
    votes = {}
    for identity, number in pairs.items():
        function = by_id.get(identity)
        rows = protos[number]["code"]
        if not function:
            continue
        for pool in (function.get("pools") or {}).values():
            for key, value in pool.items():
                if not str(key).isdigit():
                    continue
                pc = int(key)
                if not 0 < pc <= len(rows) or isinstance(value, dict):
                    continue
                op = rows[pc - 1][column]
                for spot in range(len(rows[pc - 1])):
                    index = rows[pc - 1][spot] >> 3
                    if 0 < index <= len(flat) and same(flat[index - 1], value):
                        votes.setdefault(op, {})
                        votes[op][spot] = votes[op].get(spot, 0) + 1
                        break
    return {
        op: max(spots, key=spots.get)
        for op, spots in votes.items()
        if sum(spots.values()) >= 3 and max(spots.values()) >= sum(spots.values()) * 0.8
    }


def same(flat_value, seen):
    if isinstance(flat_value, bytes):
        return isinstance(seen, str) and flat_value.decode("latin-1") == seen
    if isinstance(flat_value, float) and isinstance(seen, float):
        return abs(flat_value - seen) < 1e-9 * max(1.0, abs(seen))
    return flat_value == seen and not isinstance(flat_value, bool)


def closure_slot(protos, column, naming, count):
    votes = collections.Counter()
    for proto in protos:
        for at, row in enumerate(proto["code"]):
            for slot, name in naming.items():
                value = container.operand(row[slot], at)
                if 0 <= value < count:
                    votes[name] += 1
    return votes.most_common(1)[0][0] if votes else None


def matched(protos, column, traced):
    by_size = collections.defaultdict(list)
    for number, proto in enumerate(protos):
        by_size[len(proto["code"])].append(number)

    pairs = {}
    for function in traced:
        body = function["instructions"]
        if not body:
            continue
        size = max(one["pc"] for one in body)
        best, score = None, 0
        for number in by_size.get(size, []):
            if number in pairs.values():
                continue
            code = protos[number]["code"]
            agree = sum(
                1
                for one in body
                if 1 <= one["pc"] <= len(code) and code[one["pc"] - 1][column] == one["op"]
            )
            if agree > score:
                best, score = number, agree
        if best is not None and score > len(body) * SURE:
            pairs[function["id"]] = best
    return pairs


def slots(protos, column, traced, pairs):
    votes = collections.defaultdict(collections.Counter)
    others = [slot for slot in range(container.COLUMNS) if slot != column]
    for function in traced:
        number = pairs.get(function["id"])
        if number is None:
            continue
        code = protos[number]["code"]
        for one in function["instructions"]:
            at = one["pc"] - 1
            if not 0 <= at < len(code):
                continue
            values = {slot: container.operand(code[at][slot], at) for slot in others}
            for name, value in (one.get("operands") or {}).items():
                for slot, found in values.items():
                    if found == value:
                        votes[slot][name] += 1

    ranked = []
    for slot, tally in votes.items():
        ranked.extend((count, slot, name) for name, count in tally.items())
    taken = {}
    for _, slot, name in sorted(ranked, reverse=True):
        if slot in taken or name in taken.values():
            continue
        taken[slot] = name
    return taken


def helper_body(proto, column, naming):
    body = []
    for at, row in enumerate(proto["code"]):
        operands = {name: container.operand(row[slot], at) for slot, name in naming.items()}

        body.append({"pc": at + 1, "op": row[column], "operands": operands, "row": list(row)})
    return body
