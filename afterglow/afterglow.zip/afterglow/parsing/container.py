"""The Luraph container: a flat constant array followed by code blocks.

Layout, as the deserializer itself reads it:

    [header varint][0x00]
    [flat constants: [tag][payload] entries]
    [00 00 00 00]
    [blocks: [K varint][K header varints][marker = key + n]
             [4 interleaved columns x n rows][spare varints][00 00 00 00]]

Everything per file is randomised: the constant tags, the block key, which
column carries opcodes. The deserializer's own behaviour — recorded by the
hypocenter as one chronological stream of buffer reads and table creates —
pins all of it, so the decode here is a replay of that stream rather than
a guess: constants.decode derives the tag map, and the block walk takes
its boundaries and sizes from the recorded creates and separator reads.

Without that stream the old heuristic decode still runs, but it cannot
find every block: it stops once a chain of blocks covers most of the
container, and the tail it abandns is where the payload's larger
prototypes live.
"""

from . import constants

CONTROL = frozenset(range(0, 9)) | {11, 12} | frozenset(range(14, 32))
LONGEST = 4096
END = b"\0\0\0\0"
COLUMNS = 4
FORWARD = 1
BACKWARD = 4
SHIFT = 3
MASK = 7
HEADER = 64
SPARE = 4
LEAST = 4
CHANCES = 4
TRIES = 8
COVERED = 0.9
STREAMS = 7


def events_of(stream):
    """The hypocenter parse stream -> [(kind, offset, size, value), ...] and
    [create sizes], in order."""
    reads, creates = [], []
    for entry in stream or []:
        parts = entry.split(":")
        if parts[0] == "C":
            creates.append(int(parts[1]))
        elif parts[0] == "R":
            kind, off, size = parts[1], int(parts[2]), int(parts[3])
            value = None
            if len(parts) > 4 and parts[4] != "":
                try:
                    value = float(parts[4])
                    if value == int(value) and abs(value) < 2**53:
                        value = int(value)
                except ValueError:
                    value = None
            reads.append((kind, off, size, value))
    return reads, creates


def varint(data, at):
    value, shift = 0, 0
    while at < len(data):
        byte = data[at]
        at += 1
        value |= (byte & 0x7F) << shift
        if not byte & 0x80:
            break
        shift += 7
    return value, at


def decode(data, stream=None):
    """Decode the container, replaying the parse stream when there is one."""
    if stream:
        found = replay(data, stream)
        if found is not None:
            return found
    return heuristic(data)


def heuristic(data):
    """The old search, kept for payloads whose parse was not recorded."""
    bias, (protos, start, read) = helper_best(data)
    texts = helper_texts(data, varint(data, 0)[1] + 1, start - len(END))
    return {
        "texts": texts,
        "protos": protos,
        "bias": bias,
        "opcodes": opcodes(protos),
        "code": start,
        "read": read,
        "size": len(data),
    }


def replay(data, stream):
    reads, creates = events_of(stream)
    if len(reads) < 8:
        return None

    solved = constants.decode(data, reads_for_constants(reads))
    if solved[0] is None:
        return None
    kinds, values = solved

    stop = None
    for kind, off, size, value in reads:
        if kind == "u32" and value == 0:
            stop = off
            break
    if stop is None:
        return None

    blocks = blocks_merged(data, stream, stop)
    if not blocks:
        return None
    protos = [one for one in blocks if one is not None]
    if not protos:
        return None
    return {
        "texts": [v for v in values if isinstance(v, bytes)],
        "constants": values,
        "kinds": kinds,
        "protos": protos,
        "bias": blocks[0]["key"] if blocks[0] else None,
        "opcodes": opcodes(protos),
        "code": stop + 4,
        "read": last_end(reads),
        "size": len(data),
    }


def reads_for_constants(reads):
    out = []
    for kind, off, size, value in reads:
        name = "readstring" if kind == "str" else "read" + kind
        out.append((name, off, str(size), ("n:%.17g" % value) if value is not None else ""))
    return out


def last_end(reads):
    end = 0
    for kind, off, size, _ in reads:
        span = off + (size if kind == "str" else width_of(kind))
        if span > end:
            end = span
    return end


def width_of(kind):
    return {"u8": 1, "i8": 1, "u16": 2, "i16": 2, "u32": 4, "i32": 4, "f32": 4, "f64": 8}.get(
        kind, 1
    )


def blocks_merged(data, stream, stop):
    merged = []
    for entry in stream:
        parts = entry.split(":")
        if parts[0] == "C":
            merged.append(("C", int(parts[1])))
        else:
            value = None
            if len(parts) > 4 and parts[4] != "":
                try:
                    value = float(parts[4])
                    if value == int(value) and abs(value) < 2**53:
                        value = int(value)
                except ValueError:
                    value = None
            merged.append(("R", parts[1], int(parts[2]), int(parts[3]), value))

    blocks = []
    key = None
    total = len(merged)
    index = 0
    while index < total:
        entry = merged[index]
        if entry[0] == "R" and entry[1] == "u32" and entry[2] == stop and entry[4] == 0:
            index += 1
            break
        index += 1
    cursor = stop + 4
    while index < total:

        run_at = None
        at = index
        while at < total:
            if merged[at][0] != "C":
                at += 1
                continue
            size = merged[at][1]
            end = at
            while end < total and merged[end][0] == "C" and merged[end][1] == size:
                end += 1
            if end - at >= STREAMS:
                run_at = at
                run_end = at + STREAMS
                break
            at = end
        if run_at is None:
            break
        n = merged[run_at][1]
        preamble = merged[index:run_at]
        last_create = max((i for i, e in enumerate(preamble) if e[0] == "C"), default=None)
        header_reads = (
            [e for e in preamble[last_create + 1 :] if e[0] == "R"]
            if last_create is not None
            else []
        )
        if last_create is None or not header_reads:
            index = run_end
            continue
        k = preamble[last_create][1]
        index = run_end
        row_reads = []
        while index < total:
            entry = merged[index]
            if entry[0] == "R" and entry[1] == "u32" and entry[4] == 0:
                break
            if entry[0] == "R":
                row_reads.append(entry)
                index += 1
            else:
                break
        if not row_reads:
            continue
        header_start = min(r[2] for r in header_reads)
        header_end = max(r[2] + (r[3] if r[1] == "str" else width_of(r[1])) for r in header_reads)
        rows_start = row_reads[0][2]
        rows_end = max(r[2] + (r[3] if r[1] == "str" else width_of(r[1])) for r in row_reads)
        block = parse_block(data, cursor, header_start, header_end, rows_start, rows_end, k, n, key)
        if block is None:
            continue
        if key is None:
            key = block["key"]
        blocks.append(block)
        cursor = rows_end
        while index < total:
            entry = merged[index]
            if entry[0] == "R" and entry[1] == "u32" and entry[4] == 0:
                index += 1
                break
            index += 1
    return blocks


def parse_block(data, cursor, header_start, header_end, rows_start, rows_end, k, n, key):
    """Parse one block's bytes: header varints then 4n interleaved rows."""
    at = header_start

    if at > cursor:
        back = at - 1
        while back > cursor and data[back] & 0x80:
            back -= 1
        at = back
    values = []
    while at < header_end:
        value, at = varint(data, at)
        values.append(value)
    if not values:
        return None
    marker = values[-1]
    if key is not None and marker - n != key:
        return None
    found = {
        "key": marker - n,
        "n": n,
        "header": values[:-1],
        "head": values[:-1],
        "k": k,
        "code": [],
    }
    at = rows_start
    rows = []
    while at < rows_end and len(rows) < n:
        row = []
        for _ in range(COLUMNS):
            value, at = varint(data, at)
            row.append(value)
        rows.append(row)
    if len(rows) != n:
        return None
    found["code"] = rows
    return found


def opcodes(protos):
    if not protos:
        return None
    spread = [set() for _ in range(COLUMNS)]
    for proto in protos:
        for row in proto["code"]:
            for column, value in enumerate(row):
                spread[column].add(value)
    sizes = [len(one) for one in spread]
    return sizes.index(min(sizes))


def helper_texts(data, at, stop):
    if stop <= at:
        return []
    tag = max(range(256), key=lambda one: len(helper_reads(data, at, stop, one)))
    return [text for _, text in helper_reads(data, at, stop, tag)]


def helper_reads(data, at, stop, tag):
    found = []
    mark = bytes([tag])
    while at < stop:
        spot = data.find(mark, at, stop)
        if spot < 0:
            break
        size, after = varint(data, spot + 1)
        body = data[after : after + size]
        if (
            0 <= size <= LONGEST
            and after + size <= stop
            and not any(byte in CONTROL for byte in body)
        ):
            found.append((spot, body.decode("latin-1")))
            at = after + size
        else:
            at = spot + 1
    return found


def helper_starts(data):
    found = [0]
    cursor = data.find(END)
    while cursor >= 0:
        found.append(cursor + len(END))
        cursor = data.find(END, cursor + 1)
    return found


def scan(data, at, cache):
    if at not in cache:
        values, stops, cursor = [], [], at
        while cursor + len(END) <= len(data) and len(stops) < CHANCES:
            if data[cursor : cursor + len(END)] == END:
                stops.append((len(values), cursor + len(END)))
            value, cursor = varint(data, cursor)
            values.append(value)
        cache[at] = (values, stops)
    return cache[at]


def helper_best(data):
    cache = {}
    starts = helper_starts(data)
    found = (None, ([], 0, 0))
    for bias in offered(data, starts, cache):
        chain = blocks_old(data, bias, starts, cache)
        if weight(chain[0]) > weight(found[1][0]):
            found = (bias, chain)
        if chain[2] - chain[1] > COVERED * (len(data) - chain[1]):
            break
    return found


def weight(protos):
    return sum(len(one["code"]) for one in protos)


def offered(data, starts, cache):
    votes = {}
    for at in starts:
        values, stops = scan(data, at, cache)
        for count, _ in stops:
            for bias in fits(values[:count]):
                votes[bias] = votes.get(bias, 0) + 1
    return sorted(votes, key=votes.get, reverse=True)[:TRIES]


def fits(values):
    found = []
    for head in range(1, min(HEADER, len(values))):
        for spare in range(SPARE):
            rest = len(values) - head - spare
            if rest <= 0 or rest % COLUMNS:
                continue
            length = rest // COLUMNS
            if length >= LEAST:
                found.append(values[head - 1] - length)
    return found


def blocks_old(data, bias, starts, cache):
    best = ([], 0, 0)
    for start in starts:
        found, after = helper_chain(data, start, bias, cache)
        if after - start > best[2] - best[1]:
            best = (found, start, after)
        if after - start > COVERED * (len(data) - start):
            break
    return best


def helper_chain(data, at, bias, cache):
    found = []
    while at < len(data):
        block, cursor = helper_block(data, at, bias, cache)
        if block is None:
            return found, at
        found.append(block)
        at = cursor
    return found, at


def helper_block(data, at, bias, cache):
    values, stops = scan(data, at, cache)
    for count, after in stops:
        shape = helper_shape(values[:count], bias)
        if shape is not None:
            head, length = shape
            return {
                "head": values[: head - 1],
                "code": code(values[head : head + COLUMNS * length], length),
            }, after
    return None, at


def helper_shape(values, bias):
    for head in range(1, min(HEADER, len(values))):
        for spare in range(SPARE):
            rest = len(values) - head - spare
            if rest <= 0 or rest % COLUMNS:
                continue
            length = rest // COLUMNS
            if length > 0 and values[head - 1] - length == bias:
                return head, length
    return None


def code(fields, length):
    return [fields[index * COLUMNS : (index + 1) * COLUMNS] for index in range(length)]


def operand(raw, index):
    value, tag = raw >> SHIFT, raw & MASK
    if tag == FORWARD:
        return index + 1 + value
    if tag == BACKWARD:
        return index + 1 - value
    return value
