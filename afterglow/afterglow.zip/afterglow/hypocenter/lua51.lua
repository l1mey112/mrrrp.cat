-- HYPOCENTER - execution sandbox.
local run_path, out_json, cap_dir, buf_path = arg[1], arg[2], arg[3], arg[4]
if not run_path or not out_json then
    os.exit(1)
end


local flags = arg[5] or ""
local shims = os.getenv("afterglow_SHIMS") == "1" or flags:find("shims", 1, true) ~= nil
local api = os.getenv("afterglow_API") == "1" or flags:find("api", 1, true) ~= nil
local missing = os.getenv("afterglow_MISSING") == "1"

local function read_file(path, mode)
    local fh = io.open(path, mode or "rb")
    if not fh then return nil end
    local data = fh:read("*a")
    fh:close()
    return data
end

local src = assert(read_file(run_path), "cannot read " .. tostring(run_path))


local function esc(s)
    local out = { '"' }
    for i = 1, #s do
        local b = s:byte(i)
        if b == 34 then out[#out + 1] = '\\"'
        elseif b == 92 then out[#out + 1] = "\\\\"
        elseif b == 10 then out[#out + 1] = "\\n"
        elseif b == 13 then out[#out + 1] = "\\r"
        elseif b == 9 then out[#out + 1] = "\\t"
        elseif b < 32 or b > 126 then out[#out + 1] = string.format("\\u%04x", b)
        else out[#out + 1] = s:sub(i, i) end
    end
    out[#out + 1] = '"'
    return table.concat(out)
end

local function num(n)
    if n ~= n then return '"NaN"' end
    if n == math.huge then return '"Inf"' end
    if n == -math.huge then return '"-Inf"' end
    return string.format("%.14g", n)
end


local serialize
do
    local visited = {}
    local budget = 500000
    local deadline = os.clock() + 20
    local next_id = 0

    function serialize(v, depth)
        if budget <= 0 then return '"<budget>"' end
        if os.clock() > deadline then return '"<timeout>"' end
        budget = budget - 1
        local t = type(v)
        if t == "string" then return esc(#v > 8192 and v:sub(1, 8192) or v) end
        if t == "number" then return num(v) end
        if t == "boolean" then return tostring(v) end
        if t == "nil" then return "null" end
        if t ~= "table" then return '"<' .. t .. '>"' end
        if visited[v] then return '{"$ref":' .. visited[v] .. "}" end
        if depth > 24 then return '"<deep>"' end
        next_id = next_id + 1
        visited[v] = next_id
        local parts = { '"$id":' .. next_id }
        local keys = {}
        for k in pairs(v) do keys[#keys + 1] = k end
        table.sort(keys, function(a, b)
            if type(a) == "number" and type(b) == "number" then return a < b end
            return tostring(a) < tostring(b)
        end)
        for _, k in ipairs(keys) do
            if not (type(k) == "number" and k > 65536) then
                local key = type(k) == "string" and esc(k) or esc(tostring(k))
                parts[#parts + 1] = key .. ":" .. serialize(v[k], depth + 1)
            end
        end
        return "{" .. table.concat(parts, ",") .. "}"
    end
end

local function object(fields)
    local parts = {}
    for _, pair in ipairs(fields) do
        local v, encoded = pair[2], nil
        if type(v) == "string" then encoded = esc(v)
        elseif type(v) == "number" then encoded = num(v)
        elseif type(v) == "boolean" then encoded = tostring(v)
        elseif type(v) == "table" then encoded = v.raw
        else encoded = "null" end
        parts[#parts + 1] = esc(pair[1]) .. ":" .. encoded
    end
    return "{" .. table.concat(parts, ",") .. "}"
end

local function raw(text) return { raw = text } end

local function array(items) return raw("[" .. table.concat(items, ",") .. "]") end


local env = {}
for _, name in ipairs({
    "string", "table", "math", "unpack", "select", "tostring", "tonumber",
    "type", "pcall", "xpcall", "error", "assert", "setmetatable",
    "getmetatable", "rawget", "rawset", "rawequal", "next", "pairs",
    "ipairs", "getfenv", "setfenv",
}) do
    env[name] = _G[name]
end
env.bit = rawget(_G, "bit") or rawget(_G, "bit32")
env.bit32 = rawget(_G, "bit32")
env._G = env
env._VERSION = _VERSION
env.os = { time = os.time, clock = os.clock }


local CALL_LIMIT = 10000

local calls = {}
local current = { step = 0 }

local function recorder(name)
    return function(...)
        local args = {}
        for i = 1, select("#", ...) do
            args[i] = tostring(select(i, ...))
        end
        calls[#calls + 1] = {
            name = name, args = args,
            op = current.op, proto = current.proto, step = current.step,
        }
        if #calls >= CALL_LIMIT then
            error("afterglow_CALL_LIMIT: the payload made more than "
                .. CALL_LIMIT .. " calls", 0)
        end
    end
end

env.print = recorder("print")


local function int_from(s, pos, size, little, signed)
    local v = 0
    if little then
        for k = size, 1, -1 do v = v * 256 + s:byte(pos + k - 1) end
    else
        for k = 1, size do v = v * 256 + s:byte(pos + k - 1) end
    end
    if signed and v >= 2 ^ (size * 8 - 1) then v = v - 2 ^ (size * 8) end
    return v
end

local function int_to(n, size, little)
    local bytes = {}
    if n < 0 then n = 2 ^ (size * 8) + n end
    n = math.floor(n)
    for k = 1, size do
        bytes[k] = n % 256
        n = math.floor(n / 256)
    end
    if not little then
        local rev = {}
        for k = 1, size do rev[k] = bytes[size + 1 - k] end
        bytes = rev
    end
    return string.char(unpack(bytes))
end

local INT_SIZES = { b = 1, B = 1, h = 2, H = 2, i = 4, I = 4, l = 8, L = 8, j = 8, J = 8, T = 4 }


local function format_reader(fmt)
    local little, i = false, 1
    while i <= #fmt do
        local c = fmt:sub(i, i)
        if c == "<" then little = true; i = i + 1
        elseif c == ">" or c == "=" or c == "!" then little = false; i = i + 1
        else break end
    end
    return little, function()
        if i > #fmt then return nil end
        local code = fmt:sub(i, i)
        i = i + 1
        local digits = ""
        while i <= #fmt and fmt:sub(i, i) >= "0" and fmt:sub(i, i) <= "9" do
            digits = digits .. fmt:sub(i, i)
            i = i + 1
        end
        return code, (digits ~= "" and tonumber(digits) or nil)
    end
end

local function pack_shim(fmt, ...)
    local little, next_code = format_reader(fmt)
    local vals, vi, out = { ... }, 0, {}
    for code, size in next_code do
        if code == "x" then
            out[#out + 1] = "\0"
        elseif INT_SIZES[code] then
            vi = vi + 1
            out[#out + 1] = int_to(vals[vi] or 0, size or INT_SIZES[code], little)
        elseif code == "s" or code == "z" then
            vi = vi + 1
            local str = tostring(vals[vi])
            if code == "s" then out[#out + 1] = int_to(#str, size or 8, little) end
            out[#out + 1] = str
            if code == "z" then out[#out + 1] = "\0" end
        elseif code == "c" then
            vi = vi + 1
            out[#out + 1] = tostring(vals[vi]):sub(1, size or 0)
        else
            error("string.pack shim: unsupported format '" .. code .. "'", 2)
        end
    end
    return table.concat(out)
end

local function unpack_shim(fmt, s, pos)
    pos = pos or 1
    local little, next_code = format_reader(fmt)
    local vals = {}
    for code, size in next_code do
        if code == "x" then
            pos = pos + 1
        elseif INT_SIZES[code] then
            local n = size or INT_SIZES[code]
            local signed = code == code:lower() and code ~= "T"
            vals[#vals + 1] = int_from(s, pos, n, little, signed)
            pos = pos + n
        elseif code == "s" then
            local n = size or 8
            local len = int_from(s, pos, n, little, false)
            pos = pos + n
            vals[#vals + 1] = s:sub(pos, pos + len - 1)
            pos = pos + len
        elseif code == "z" then
            local z = s:find("\0", pos, true) or (#s + 1)
            vals[#vals + 1] = s:sub(pos, z - 1)
            pos = z + 1
        elseif code == "c" then
            vals[#vals + 1] = s:sub(pos, pos + (size or 0) - 1)
            pos = pos + (size or 0)
        else
            error("string.unpack shim: unsupported format '" .. code .. "'", 2)
        end
    end
    vals[#vals + 1] = pos
    return unpack(vals)
end

local function bit32_shim(bit)
    local function u(x) return x % 4294967296 end
    return {
        band = function(...) return u(bit.band(...)) end,
        bor = function(...) return u(bit.bor(...)) end,
        bxor = function(...) return u(bit.bxor(...)) end,
        bnot = function(x) return u(bit.bnot(x)) end,
        lshift = function(x, n) return u(bit.lshift(x, n)) end,
        rshift = function(x, n) return u(bit.rshift(x, n)) end,
        arshift = function(x, n) return u(bit.arshift(x, n)) end,
        lrotate = function(x, n) return u(bit.rol(x, n)) end,
        rrotate = function(x, n) return u(bit.ror(x, n)) end,
        bswap = function(x) return u(bit.bswap(x)) end,
        extract = function(...) return u(bit.extract(...)) end,
        replace = function(...) return u(bit.replace(...)) end,
        countlz = function(x)
            x = u(x)
            if x == 0 then return 32 end
            local n, cmp = 0, 2 ^ 31
            while x < cmp do n = n + 1; cmp = cmp / 2 end
            return n
        end,
        countrz = function(x)
            x = u(x)
            if x == 0 then return 32 end
            local n = 0
            while x % 2 == 0 do n = n + 1; x = x / 2 end
            return n
        end,
    }
end


local captures = {}

local function capture(data, chunkname, format)
    local index = #captures + 1
    local path
    if cap_dir and cap_dir ~= "" then
        path = string.format("%s/capture%02d.%s", cap_dir, index, format)
        local cf = io.open(path, "wb")
        if cf then
            cf:write(data)
            cf:close()
        else
            path = nil
        end
    end
    captures[index] = {
        index = index,
        chunkname = tostring(chunkname),
        size = #data,
        format = format,
        file = path,
    }
end

local real_loadstring = loadstring

local function capturing_loadstring(s, name, ...)
    if type(s) == "string" and #s > 0 then
        local bytecode = s:sub(1, 4) == "\27Lua"
        if bytecode or (type(name) == "string" and name:find("Luraph", 1, true)) then
            capture(s, name, bytecode and "luc" or "lua")
        end
    end
    local f, err = real_loadstring(s, name, ...)
    if f then setfenv(f, env) end
    return f, err
end


local function buffer_lib()
    local bytes_of_buffer = setmetatable({}, { __mode = "k" })

    local function bytes_of_string(s)
        local bytes = {}
        for i = 1, #s, 256 do
            local chunk = { s:byte(i, math.min(i + 255, #s)) }
            for j = 1, #chunk do bytes[i + j - 1] = chunk[j] end
        end
        return bytes
    end

    local function make(bytes)
        local proxy = newproxy and newproxy(true) or {}
        local mt = getmetatable(proxy)
        if mt then
            mt.__index = function(_, key)
                if type(key) == "number" then return bytes[key + 1] end
                return nil
            end
            mt.__newindex = function(_, key, value) bytes[key + 1] = value % 256 end
            mt.__len = function() return #bytes end
            mt.__tostring = function()
                local parts = {}
                for i = 1, #bytes, 256 do
                    local chunk = {}
                    for j = 0, 255 do
                        local v = bytes[i + j]
                        if v == nil then break end
                        chunk[#chunk + 1] = v
                    end
                    parts[#parts + 1] = string.char(unpack(chunk))
                end
                return table.concat(parts)
            end
        end
        bytes_of_buffer[proxy] = bytes
        return proxy
    end

    local function bytes_of(b)
        local bytes = bytes_of_buffer[b]
        if bytes then return bytes end
        if type(b) == "string" then
            bytes = bytes_of_string(b)
        elseif type(b) == "table" then
            bytes = {}
            for i = 1, #b do bytes[i] = b[i] or 0 end
        else
            io.stderr:write("[hypocenter] buffer call on " .. type(b) .. "\n")
            return {}
        end
        bytes_of_buffer[b] = bytes
        return bytes
    end

    local function read_int(b, off, size, signed)
        local bytes = bytes_of(b)
        local v = 0
        for k = 0, size - 1 do v = v + (bytes[off + k + 1] or 0) * 2 ^ (8 * k) end
        if signed and v >= 2 ^ (size * 8 - 1) then v = v - 2 ^ (size * 8) end
        return v
    end

    local function write_int(b, off, size, n)
        local bytes = bytes_of(b)
        if n < 0 then n = 2 ^ (size * 8) + n end
        n = math.floor(n)
        for k = 0, size - 1 do
            bytes[off + k + 1] = n % 256
            n = math.floor(n / 256)
        end
    end


    local function make_float(sign, exp, mant, exp_max, mant_bits, bias)
        if exp == 0 then return sign * mant * 2 ^ (1 - bias - mant_bits) end
        if exp == exp_max then return sign * (mant == 0 and math.huge or (0 / 0)) end
        return sign * (1 + mant / 2 ^ mant_bits) * 2 ^ (exp - bias)
    end

    return {
        create = function(n)
            local bytes = {}
            for i = 1, n do bytes[i] = 0 end
            return make(bytes)
        end,
        fromstring = function(s)
            if type(s) == "string" and #s > 0 then capture(s, "buffer", "bin") end
            return make(bytes_of_string(s))
        end,
        tostring = function(b) return tostring(b) end,
        len = function(b) return #b end,
        readu8 = function(b, o) return read_int(b, o, 1, false) end,
        readi8 = function(b, o) return read_int(b, o, 1, true) end,
        readu16 = function(b, o) return read_int(b, o, 2, false) end,
        readi16 = function(b, o) return read_int(b, o, 2, true) end,
        readu32 = function(b, o) return read_int(b, o, 4, false) end,
        readi32 = function(b, o) return read_int(b, o, 4, true) end,
        readf32 = function(b, o)
            local v = read_int(b, o, 4, false)
            local sign = 1
            if v >= 2 ^ 31 then sign = -1; v = v - 2 ^ 31 end
            return make_float(sign, math.floor(v / 2 ^ 23) % 256, v % 2 ^ 23, 255, 23, 127)
        end,
        readf64 = function(b, o)
            local lo = read_int(b, o, 4, false)
            local hi = read_int(b, o + 4, 4, false)
            local sign = 1
            if hi >= 2 ^ 31 then sign = -1; hi = hi - 2 ^ 31 end
            local exp = math.floor(hi / 2 ^ 20) % 2048
            return make_float(sign, exp, (hi % 2 ^ 20) * 2 ^ 32 + lo, 2047, 52, 1023)
        end,
        readstring = function(b, o, len)
            local bytes = bytes_of(b)
            local out = {}
            for i = 0, len - 1 do out[#out + 1] = string.char(bytes[o + i + 1] or 0) end
            return table.concat(out)
        end,
        writeu8 = function(b, o, v) write_int(b, o, 1, v) end,
        writei8 = function(b, o, v) write_int(b, o, 1, v) end,
        writeu16 = function(b, o, v) write_int(b, o, 2, v) end,
        writei16 = function(b, o, v) write_int(b, o, 2, v) end,
        writeu32 = function(b, o, v) write_int(b, o, 4, v) end,
        writei32 = function(b, o, v) write_int(b, o, 4, v) end,
        writestring = function(b, o, s)
            local bytes = bytes_of(b)
            for i = 0, #s - 1 do bytes[o + i + 1] = s:byte(i + 1) end
        end,
        copy = function(b, so, dst, doff, len)
            local from, to = bytes_of(b), bytes_of(dst)
            for i = 0, (len or #from) - 1 do to[doff + i + 1] = from[so + i + 1] end
        end,
        fill = function(b, o, v, len)
            local bytes = bytes_of(b)
            for i = 0, (len or (#bytes - o)) - 1 do bytes[o + i + 1] = v % 256 end
        end,
    }
end

if shims then
    if not env.string.pack or not env.string.unpack then
        env.string = setmetatable(
            { pack = env.string.pack or pack_shim, unpack = env.string.unpack or unpack_shim },
            { __index = env.string })
    end
    if not env.bit32 and env.bit then env.bit32 = bit32_shim(env.bit) end
    env.coroutine = coroutine
    env.buffer = buffer_lib()
    env.loadstring = capturing_loadstring
    env.load = function(s, name, ...)
        if type(s) == "function" then return s end
        return capturing_loadstring(s, name and tostring(name) or nil, ...)
    end
    env.__luau_iter = function(x)
        if type(x) == "function" then return x end
        return pairs(x)
    end
    env.__idiv = function(a, b) return math.floor(a / b) end
end


local WAITS = 5000
local waits = 0

local function waited()
    waits = waits + 1
    if waits > WAITS then
        error("afterglow_WAIT_LIMIT: the payload is waiting in a loop", 0)
    end
    return 0
end


local LOOKUPS = {
    FindFirstChild = true, findFirstChild = true, FindFirstChildOfClass = true,
    FindFirstChildWhichIsA = true, FindFirstDescendant = true,
    FindFirstAncestor = true, FindFirstAncestorOfClass = true,
    FindFirstAncestorWhichIsA = true, GetAttribute = true,
}

local HOSTS = {

    "game", "workspace", "Workspace", "script", "plugin", "shared", "Enum",
    "settings", "UserSettings", "PluginManager", "DebuggerManager", "stats",
    "printidentity", "version", "require", "LoadLibrary", "gcinfo", "ypcall",
    "elapsedTime", "DateTime",

    "Axes", "BrickColor", "CatalogSearchParams", "CFrame", "Color3",
    "ColorSequence", "ColorSequenceKeypoint", "Content", "Faces",
    "FloatCurveKey", "Font", "Instance", "NumberRange", "NumberSequence",
    "NumberSequenceKeypoint", "OverlapParams", "PathWaypoint",
    "PhysicalProperties", "Random", "Ray", "RaycastParams", "Rect", "Region3",
    "Region3int16", "RotationCurveKey", "SharedTable", "TweenInfo", "UDim",
    "UDim2", "Vector2", "Vector2int16", "Vector3", "Vector3int16",

    "getgenv", "getrenv", "getreg", "getgc", "getloadedmodules", "getscripts",
    "getinstances", "getnilinstances", "getconnections", "getcallingscript",
    "getscriptclosure", "getscripthash", "getsenv", "gethui", "cloneref",
    "compareinstances", "clonefunction", "checkcaller", "hookfunction",
    "hookmetamethod", "newcclosure", "iscclosure", "islclosure",
    "isexecutorclosure", "getrawmetatable", "setrawmetatable", "setreadonly",
    "isreadonly", "getnamecallmethod", "setnamecallmethod", "identifyexecutor",
    "getexecutorname", "setclipboard", "setfpscap", "getfpscap", "isrbxactive",
    "keypress", "keyrelease", "mouse1click", "mouse1press", "mouse1release",
    "mouse2click", "mouse2press", "mouse2release", "mousemoverel",
    "firesignal", "firetouchinterest", "fireclickdetector",
    "fireproximityprompt", "replicatesignal", "queue_on_teleport", "messagebox",
    "protectgui", "unprotectgui", "request", "http_request", "http", "WebSocket",
    "Drawing", "crypt", "base64", "readfile", "writefile", "appendfile",
    "listfiles", "isfile", "isfolder", "makefolder", "delfile", "delfolder",
    "syn", "krnl", "fluxus", "secure_call", "decompile",
}

local transcript = {}
local stubs = setmetatable({}, { __mode = "k" })
local call_count = 0
local depth = 0
local repeats = {}

local RECORD_LIMIT = 2
local DEPTH_LIMIT = 3


local function shape(text)
    local out, i = {}, 1
    while i <= #text do
        local char = text:sub(i, i)
        if char == "#" then
            out[#out + 1] = "#"
            i = i + 1
            while i <= #text and text:sub(i, i) >= "0" and text:sub(i, i) <= "9" do
                i = i + 1
            end
        else
            out[#out + 1] = char
            i = i + 1
        end
    end
    return table.concat(out)
end


local function write(record)
    local key = shape(record.text)
    local seen = (repeats[key] or 0) + 1
    repeats[key] = seen
    if seen <= RECORD_LIMIT then
        record.depth = depth
        transcript[#transcript + 1] = record
    elseif seen == RECORD_LIMIT + 1 then
        record.depth = depth
        record.repeated = true
        transcript[#transcript + 1] = record
    end
end


local WAITS_ON = { Wait = true, wait = true, Yield = true, yield = true }

local render

local function stub(expression, parent, key)
    local proxy = {}
    local info = { expression = expression, parent = parent, key = key }

    local function call(self, ...)
        local args, count = { ... }, select("#", ...)
        local rendered, text = {}, nil
        local method = info.parent and args[1] == info.parent
        if method then
            for i = 2, count do rendered[#rendered + 1] = render(args[i]) end
            text = stubs[info.parent].expression .. ":" .. tostring(info.key)
                .. "(" .. table.concat(rendered, ", ") .. ")"
        else
            for i = 1, count do rendered[#rendered + 1] = render(args[i]) end
            text = info.expression .. "(" .. table.concat(rendered, ", ") .. ")"
        end
        if method and WAITS_ON[info.key] then waited() end

        call_count = call_count + 1
        local id = call_count
        write({ kind = "call", id = id, text = text, step = current.step })


        if depth < DEPTH_LIMIT then
            for i = 1, count do
                if type(args[i]) == "function" then
                    depth = depth + 1
                    write({ kind = "enter", id = id, text = text, step = current.step })
                    pcall(args[i])
                    depth = depth - 1
                    write({ kind = "leave", id = id, text = text, step = current.step })
                end
            end
        end


        if missing and method and LOOKUPS[info.key] then
            return nil
        end
        return stub("#" .. id)
    end

    local function operator(symbol)
        return function(a, b)
            return stub("(" .. render(a) .. " " .. symbol .. " " .. render(b) .. ")")
        end
    end

    setmetatable(proxy, {
        __index = function(_, name)
            return stub(expression .. "." .. tostring(name), proxy, name)
        end,
        __newindex = function(_, name, value)
            write({
                kind = "set", step = current.step,
                text = expression .. "." .. tostring(name) .. " = " .. render(value),
            })
        end,
        __call = call,
        __tostring = function() return expression end,
        __concat = operator(".."),
        __add = operator("+"), __sub = operator("-"),
        __mul = operator("*"), __div = operator("/"),
        __unm = function(a) return stub("-" .. render(a)) end,
        __len = function() return 0 end,
        __eq = function() return false end,
        __lt = function() return false end,
        __le = function() return false end,
    })
    stubs[proxy] = info
    return proxy
end

function render(value)
    local known = stubs[value]
    if known then return known.expression end
    local kind = type(value)
    if kind == "string" then return string.format("%q", value) end
    if kind == "number" or kind == "boolean" then return tostring(value) end
    if kind == "nil" then return "nil" end
    if kind == "function" then return "function() --[[ payload ]] end" end
    if kind == "table" then
        local parts = {}
        for k, v in pairs(value) do
            parts[#parts + 1] = (type(k) == "number" and "" or tostring(k) .. " = ")
                .. render(v)
            if #parts >= 12 then break end
        end
        return "{" .. table.concat(parts, ", ") .. "}"
    end
    return "<" .. kind .. ">"
end


local function luau_library()
    env.coroutine = coroutine
    env.table.find = env.table.find or function(list, value, from)
        for i = from or 1, #list do
            if list[i] == value then return i end
        end
        return nil
    end
    env.table.create = env.table.create or function(count, value)
        local made = {}
        for i = 1, count do made[i] = value end
        return made
    end
    env.table.clear = env.table.clear or function(list)
        for key in pairs(list) do list[key] = nil end
    end
    env.table.pack = env.table.pack or function(...)
        return { n = select("#", ...), ... }
    end
    env.table.unpack = env.table.unpack or unpack
    env.math.clamp = env.math.clamp or function(x, low, high)
        return math.min(math.max(x, low), high)
    end
    env.math.round = env.math.round or function(x)
        return math.floor(x + 0.5)
    end
    env.math.sign = env.math.sign or function(x)
        return x > 0 and 1 or (x < 0 and -1 or 0)
    end
    env.string.split = env.string.split or function(text, separator)
        separator = separator or ","
        local parts, position = {}, 1
        while true do
            local at = text:find(separator, position, true)
            if not at then
                parts[#parts + 1] = text:sub(position)
                return parts
            end
            parts[#parts + 1] = text:sub(position, at - 1)
            position = at + #separator
        end
    end
end

if api then
    luau_library()
    for _, name in ipairs(HOSTS) do
        if env[name] == nil then env[name] = stub(name) end
    end


    env.typeof = function(value)
        if stubs[value] then return "Instance" end
        return type(value)
    end
    env.tick = os.time
    env.time = os.clock
    env.warn = recorder("warn")
    env.wait = function(seconds)
        waited()
        return seconds or 0
    end
    env.spawn = function(fn, ...) if type(fn) == "function" then return fn(...) end end
    env.delay = function(_, fn, ...) if type(fn) == "function" then return fn(...) end end
    env.task = {
        wait = env.wait,
        spawn = env.spawn,
        defer = env.spawn,
        delay = env.delay,
        cancel = function() end,
        synchronize = function() end,
        desynchronize = function() end,
    }


end


local LOOP_STARTS = { "repeat local ", "while true do local " }
local SCORE_WINDOW = 4000

local function is_ident_byte(b)
    return b and ((b >= 48 and b <= 57) or (b >= 65 and b <= 90)
        or (b >= 97 and b <= 122) or b == 95)
end

local function read_ident(s, i)
    local j = i
    while is_ident_byte(s:byte(j)) do j = j + 1 end
    if j == i then return nil end
    return s:sub(i, j - 1), j
end


local function read_fetch(s, i)
    local name, table_, index
    name, i = read_ident(s, i)
    if not name or s:sub(i, i) ~= "=" then return nil end
    i = i + 1
    local wrapped = s:sub(i, i) == "("
    if wrapped then i = i + 1 end
    table_, i = read_ident(s, i)
    if not table_ or s:sub(i, i) ~= "[" then return nil end
    index, i = read_ident(s, i + 1)
    if not index or s:sub(i, i) ~= "]" then return nil end
    i = i + 1
    if wrapped then
        if s:sub(i, i) ~= ")" then return nil end
        i = i + 1
    end
    if s:sub(i, i) ~= ";" then return nil end
    return name, table_, index, i + 1
end


local function comparisons(text, from, name)
    local window = text:sub(from, from + SCORE_WINDOW)
    local count, at = 0, 1
    while true do
        at = window:find(name, at, true)
        if not at then return count end
        local after = window:sub(at + #name, at + #name)
        local before = window:sub(at - 1, at - 1)
        if (after == "<" or after == ">" or after == "=" or after == "~")
            and not is_ident_byte(before:byte(1)) then
            count = count + 1
        end
        at = at + #name
    end
end


local function instrument(text)
    local best
    for _, opener in ipairs(LOOP_STARTS) do
        local pos = text:find(opener, 1, true)
        while pos do
            local start = pos + #opener
            local name, table_, index, stop = read_fetch(text, start)
            if name and table_ ~= name then
                local score = comparisons(text, stop, name)
                if not best or score > best.score then
                    best = { score = score, start = start, stop = stop,
                             name = name, table_ = table_, index = index }
                end
            end
            pos = text:find(opener, pos + 1, true)
        end
    end
    if not best then return text, nil end
    return text:sub(1, best.start - 1)
        .. best.name .. "=(__vmtrace(" .. best.table_ .. "," .. best.index .. "));"
        .. text:sub(best.stop),
        { variable = best.name, code = best.table_, counter = best.index }
end


local dispatch
src, dispatch = instrument(src)


local global_names = {}
for name, value in pairs(env) do
    if type(value) == "table" or type(value) == "function" then
        global_names[value] = name
    end
end

local REGISTERS = 40
local SAMPLES = 30
local WINDOW = 20000


local recent = {}
local recent_count = 0


local effects = {}
local sampled = {}

local scan_tables, scan_seen, scan_count = {}, {}, 0
local function offer(name, value)
    if type(value) == "table" and not scan_seen[value] then
        scan_seen[value] = true
        scan_count = scan_count + 1
        local entry = scan_tables[scan_count]
        if entry then
            entry.name, entry.ref = name, value
        else
            scan_tables[scan_count] = { name = name, ref = value }
        end


        if value == env and dispatch then dispatch.globals = name end
    end
end

local pending = { op = nil, pc = nil, proto = nil, before = nil }
local spare = { op = nil, pc = nil, proto = nil, before = nil }
local started = false


local taken = {}
local taken_count = 0


local function tag(v)
    local kind = type(v)
    if kind == "number" then return "n:" .. string.format("%.14g", v) end
    if kind == "string" then return "s:" .. (#v > 120 and v:sub(1, 120) or v) end
    if kind == "boolean" then return "b:" .. tostring(v) end
    if kind == "nil" then return "z:" end
    if v == env.print then return "g:print" end
    return kind:sub(1, 1) .. ":"
end

local steps = 0
local loads = {}
local last_seen = {}
local pool_seen = {}


local function remember_pool(proto, name, index, value)
    local kind = type(value)
    if kind ~= "string" and kind ~= "number" and kind ~= "boolean" then return end
    local key = proto .. ":" .. name .. ":" .. index
    local tagged = tag(value)
    local found = pool_seen[key]
    if not found then
        pool_seen[key] = {
            proto = proto, name = name, index = index, tag = tagged, value = value,
        }
    elseif found.tag ~= tagged then
        found.ambiguous = true
    end
end


local protos = {}
local proto_list = {}


local function proto_of(code)
    local record = protos[code]
    if record then return record end
    record = { id = #proto_list + 1, first_step = steps, code = {}, pcs = {} }
    protos[code] = record
    proto_list[#proto_list + 1] = record
    return record
end


local register_names = {}
local function register_name(name, index)
    local names = register_names[name]
    if not names then
        names = {}
        for k = 0, REGISTERS do names[k] = name .. "[" .. k .. "]" end
        register_names[name] = names
    end
    return names[index]
end


local function each_register(tables, count, visit)
    for at = 1, count do
        local entry = tables[at]
        local name = entry.name
        for k, v in pairs(entry.ref) do
            if type(k) == "number" and k >= 0 and k <= REGISTERS then
                visit(register_name(name, k), k, v)
            end
        end
    end
end

env.__vmtrace = function(code, pc)
    local op = code[pc]
    steps = steps + 1


    local tables, seen_table = scan_tables, scan_seen
    for k in pairs(seen_table) do seen_table[k] = nil end
    scan_count = 0
    local i = 1
    while true do
        local name, value = debug.getlocal(2, i)
        if not name then break end
        offer(name, value)
        i = i + 1
    end
    local proto = proto_of(code)
    current.op, current.proto, current.step = op, proto.id, steps

    local before = {}
    each_register(tables, scan_count, function(key, index, v)
        local name = key:match("^(.*)%[")
        remember_pool(proto.id, name, index, v)
        if before then before[key] = v end


        local shown
        local global_name = global_names[v]
        if global_name then shown = "<global " .. global_name .. ">"
        elseif type(v) == "string" and #v > 1 then shown = v end
        if shown and last_seen[key] ~= shown then
            last_seen[key] = shown
            loads[#loads + 1] = {
                step = steps, pc = pc, op = op, proto = proto.id,
                reg = key, value = shown,
            }
        end
    end)


    if pending and pending.proto == proto.id and pc ~= pending.pc + 1 then
        local key = pending.proto .. ":" .. pending.pc
        if taken[key] == nil then
            taken[key] = { proto = pending.proto, pc = pending.pc,
                           op = pending.op, went_to = pc }
            taken_count = taken_count + 1
        end
    end

    if pending and pending.proto == proto.id then
        local changed = {}
        for key, value in pairs(before) do
            if pending.before[key] ~= value then
                changed[#changed + 1] = { key = key, after = tag(value) }
            end
        end
        for key in pairs(pending.before) do
            if before[key] == nil then
                changed[#changed + 1] = { key = key, after = "z:" }
            end
        end


        if #changed == 1 then
            recent_count = recent_count + 1
            recent[(recent_count - 1) % WINDOW + 1] = {
                op = pending.op, pc = pending.pc, proto = pending.proto,
                register = changed[1].key, after = changed[1].after,
            }
        end


        if #changed <= 1 and (sampled[pending.op] or 0) < SAMPLES then
            sampled[pending.op] = (sampled[pending.op] or 0) + 1
            effects[#effects + 1] = {
                op = pending.op, pc = pending.pc, proto = pending.proto,
                next_pc = pc, changed = changed, before = pending.before,
            }
        end
    end


    spare, pending = pending, spare
    pending.op, pending.pc, pending.proto, pending.before = op, pc, proto.id, before


    if proto.code[pc] == nil then
        local running = debug.getinfo(2, "f")
        if running and running.func then
            local u = 1
            while true do
                local name, value = debug.getupvalue(running.func, u)
                if not name then break end
                offer(name, value)
                u = u + 1
            end
        end


        local operands = {}
        local table_operands = {}
        for at = 1, scan_count do
            local entry = tables[at]
            if entry.ref ~= code then
                local value = rawget(entry.ref, pc)
                if type(value) == "number" then operands[entry.name] = value end
                if type(value) == "table" then table_operands[entry.name] = value end
            end
        end
        proto.code[pc] = { op = op, operands = operands, tables = table_operands }
        proto.pcs[#proto.pcs + 1] = pc
    end

    return op
end


local chunk, load_err = loadstring(src, "=@obfuscated")
if not chunk then
    io.stderr:write("[hypocenter] cannot load prepared source: " .. tostring(load_err) .. "\n")
    os.exit(2)
end
setfenv(chunk, env)

local function traceback(err)
    return tostring(err) .. "\n" .. debug.traceback("", 2)
end


local call_arg
if buf_path and buf_path ~= "" then
    local data = read_file(buf_path)
    if data then call_arg = env.buffer.fromstring(data) end
end


local function protected(fn, argument)
    if argument ~= nil then
        if shims then return xpcall(function() return fn(argument) end, traceback) end
        return pcall(fn, argument)
    end
    if shims then return xpcall(fn, traceback) end
    return pcall(fn)
end

local TIME_LIMIT = 60

local deadline = os.clock() + TIME_LIMIT
debug.sethook(function()
    if os.clock() > deadline then
        error("afterglow_TIME_LIMIT: still running after " .. TIME_LIMIT .. "s", 0)
    end
end, "", 1000000)

local failure = ""
local ok, entry = protected(chunk, call_arg)
if not ok then
    failure = tostring(entry)
elseif type(entry) == "function" then

    local run_ok, run_err = protected(entry)
    if not run_ok then failure = tostring(run_err) end
end
debug.sethook()


local roots = {}
local seen_roots = {}
local walked = {}

local function walk_upvalues(fn, label, depth)
    if walked[fn] or depth > 8 then return end
    walked[fn] = true
    local i = 1
    while true do
        local name, value = debug.getupvalue(fn, i)
        if not name then break end
        if type(value) == "function" then
            walk_upvalues(value, label .. "." .. name, depth + 1)
        elseif value ~= nil and not seen_roots[value] then
            seen_roots[value] = true
            roots[#roots + 1] = { label = label .. "." .. name, value = value }
        end
        i = i + 1
    end
end

if type(entry) == "function" then
    seen_roots[entry] = true
    roots[#roots + 1] = { label = "entry", value = entry }
    walk_upvalues(entry, "entry", 0)
end


local capture_json = {}
for i, cap in ipairs(captures) do
    capture_json[i] = object({
        { "index", cap.index }, { "chunkname", cap.chunkname },
        { "size", cap.size }, { "format", cap.format }, { "file", cap.file },
    })
end

local load_json = {}
for i, entry_ in ipairs(loads) do
    load_json[i] = object({
        { "step", entry_.step }, { "pc", entry_.pc }, { "op", entry_.op },
        { "function", entry_.proto }, { "reg", entry_.reg }, { "value", entry_.value },
    })
end

local pool_json = {}
for _, entry_ in pairs(pool_seen) do
    if not entry_.ambiguous then
        pool_json[#pool_json + 1] = object({
            { "function", entry_.proto }, { "name", entry_.name },
            { "index", entry_.index }, { "value", entry_.value },
        })
    end
end

local call_json = {}
for i, call in ipairs(calls) do
    local arg_json = {}
    for k, value in ipairs(call.args) do arg_json[k] = esc(value) end
    call_json[i] = object({
        { "name", call.name }, { "arguments", array(arg_json) },
        { "op", call.op }, { "function", call.proto }, { "step", call.step },
    })
end

local effect_json = {}
for i, effect in ipairs(effects) do
    local changed_json = {}
    for k, change in ipairs(effect.changed) do
        changed_json[k] = object({ { "register", change.key }, { "after", change.after } })
    end
    local before_json = {}
    for key, value in pairs(effect.before) do
        before_json[#before_json + 1] = esc(key) .. ":" .. esc(tag(value))
    end
    table.sort(before_json)
    effect_json[i] = object({
        { "op", effect.op }, { "pc", effect.pc }, { "function", effect.proto },
        { "next_pc", effect.next_pc },
        { "changed", array(changed_json) },
        { "before", raw("{" .. table.concat(before_json, ",") .. "}") },
    })
end

local transcript_json = {}
for i, entry in ipairs(transcript) do
    transcript_json[i] = object({
        { "kind", entry.kind }, { "id", entry.id }, { "depth", entry.depth or 0 },
        { "repeated", entry.repeated or false },
        { "step", entry.step }, { "text", entry.text },
    })
end

local taken_json = {}
for _, jump in pairs(taken) do
    taken_json[#taken_json + 1] = object({
        { "function", jump.proto }, { "pc", jump.pc },
        { "op", jump.op }, { "went_to", jump.went_to },
    })
end

local recent_json = {}
for _, write in pairs(recent) do
    recent_json[#recent_json + 1] = object({
        { "function", write.proto }, { "pc", write.pc }, { "op", write.op },
        { "register", write.register }, { "after", write.after },
    })
end

local function table_proto(value)
    if type(value) ~= "table" then return nil end
    local found = {}
    local direct = protos[value]
    if direct then found[direct.id] = true end
    for _, child in pairs(value) do
        direct = protos[child]
        if direct then found[direct.id] = true end
        if type(child) == "table" then
            for _, nested in pairs(child) do
                direct = protos[nested]
                if direct then found[direct.id] = true end
            end
        end
    end
    local identity = nil
    for candidate in pairs(found) do
        if identity then return nil end
        identity = candidate
    end
    return identity
end

local root_json = {}
for i, root in ipairs(roots) do
    root_json[i] = '{"label":' .. esc(root.label) .. ',"value":' .. serialize(root.value, 0) .. "}"
end


local proto_json = {}
for i, proto in ipairs(proto_list) do
    table.sort(proto.pcs)
    local code = {}
    for k, pc in ipairs(proto.pcs) do
        local entry = proto.code[pc]
        local operands = {}
        for name, value in pairs(entry.operands) do
            operands[#operands + 1] = esc(name) .. ":" .. num(value)
        end
        table.sort(operands)
        local children = {}
        for name, value in pairs(entry.tables or {}) do
            local child = table_proto(value)
            if child and child ~= proto.id then
                children[#children + 1] = esc(name) .. ":" .. num(child)
            end
        end
        table.sort(children)
        code[k] = object({
            { "pc", pc }, { "op", entry.op },
            { "operands", raw("{" .. table.concat(operands, ",") .. "}") },
            { "children", raw("{" .. table.concat(children, ",") .. "}") },
        })
    end

    proto_json[i] = object({
        { "id", proto.id }, { "first_step", proto.first_step }, { "code", array(code) },
    })
end

local out = assert(io.open(out_json, "wb"))
out:write(object({
    { "failure", failure },
    { "dispatch", dispatch and raw(object({
        { "variable", dispatch.variable }, { "code", dispatch.code },
        { "counter", dispatch.counter }, { "globals", dispatch.globals },
    })) or nil },
    { "calls", array(call_json) },
    { "transcript", array(transcript_json) },
    { "effects", array(effect_json) },
    { "recent", array(recent_json) },
    { "taken", array(taken_json) },
    { "protos", array(proto_json) },
    { "captures", array(capture_json) },
    { "trace", raw(object({
        { "steps", steps },
        { "loads", array(load_json) },
        { "pools", array(pool_json) },
    })) },
    { "roots", array(root_json) },
}))
out:close()

io.write(string.format(
    "%d calls, %d api records, %d captures, %d roots, %d VM steps, %d functions\n",
    #calls, #transcript, #captures, #roots, steps, #proto_list))
