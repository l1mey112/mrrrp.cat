from pathlib import Path

ROOT = Path(__file__).resolve().parent
LUA51_HYPOCENTER = ROOT / "lua51.lua"
