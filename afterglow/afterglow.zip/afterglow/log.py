def stdout(text):
    print(text, flush=True)


writer = stdout


def to(new_writer):
    global writer
    writer = new_writer


def say(text):
    writer(f"[afterglow] {text}")


def bytes_read(name, size):
    say(f"{name}, {size} bytes")


def dispatcher(dispatch, handlers, lifted):
    if not dispatch:
        say("no dispatcher found")
        return
    say(f"dispatcher {dispatch['code']}[{dispatch['counter']}], " f"{lifted}/{handlers} lifted")


def ran(steps, calls, functions, strings):
    say(f"{steps} vm steps, {calls} calls, {functions} functions, {strings} strings")


def function(number, instructions, named, emitted, lines):
    say(f"func {number}: {instructions} ins, {named} named, " f"{emitted} emitted, {lines} lines")


def wrote(path, size):
    say(f"wrote {path}, {size} bytes")
