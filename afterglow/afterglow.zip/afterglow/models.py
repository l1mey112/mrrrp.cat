from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class AnalysisResult:
    source_path: Path
    bytecode: Optional[Dict[str, Any]]
    container: Optional[Dict[str, Any]]
    program: List[str]
    layers: List[Dict[str, Any]]
    observation: Optional[Dict[str, Any]] = None
    payload_constants: List[Tuple[int, Any]] = field(default_factory=list)
    payload_instructions: List[Dict[str, Any]] = field(default_factory=list)
    payload_children: Dict[int, List[Dict[str, Any]]] = field(default_factory=dict)
    payload_path: List[int] = field(default_factory=list)
