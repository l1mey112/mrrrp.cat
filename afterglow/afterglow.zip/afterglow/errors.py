class AfterglowError(RuntimeError):
    pass


class AnalysisError(AfterglowError):
    pass


class LuaError(AfterglowError):
    pass
