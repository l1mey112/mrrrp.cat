from .chunk_format import (
    ChunkFormatError,
    VARIANT_CLASSIC,
    VARIANT_MODERN,
    parse_chunk,
)
from .opcodes import decode


def escape_bytes(data: bytes) -> str:
    out = []
    for byte in data:
        if byte == 0x0A:
            out.append("\\n")
        elif byte == 0x0D:
            out.append("\\r")
        elif byte == 0x09:
            out.append("\\t")
        elif byte == 0x5C:
            out.append("\\\\")
        elif 0x20 <= byte < 0x7F:
            out.append(chr(byte))
        else:
            out.append(f"\\x{byte:02x}")
    return "".join(out)


def normalize_constant(entry):
    kind = entry.get("kind")
    if kind:
        value = entry.get("value")
        if kind == "string" and value is None:
            value = b""
        return (kind, value)
    return ("unknown", None)


class Lua51Dump:
    def __init__(self, header, main, variant):
        self.header = header
        self.main = main
        self.variant = variant
        self.normalize_constants(main)

    @classmethod
    def from_bytes(cls, data: bytes) -> "Lua51Dump":
        errors = []
        for variant in (VARIANT_MODERN, VARIANT_CLASSIC):
            try:
                header, proto, used = parse_chunk(data, variant)
            except Exception as exc:
                errors.append(f"{variant[0]}: {exc}")
                continue
            return cls(header, proto, used)
        raise ChunkFormatError(
            "could not parse chunk with either constant layout: " + "; ".join(errors)
        )

    def normalize_constants(self, proto):
        _, number_tag, string_tag = self.variant
        for entry in proto.constants:
            tag = int(entry.tag)
            if tag == 0:
                entry.kind, entry.value = "nil", None
            elif tag == 1:
                entry.kind, entry.value = "bool", bool(entry.value)
            elif tag == number_tag:
                entry.kind = "number"
            elif tag == string_tag:
                entry.kind = "string"
                if entry.value is None:
                    entry.value = b""
            else:
                entry.kind, entry.value = "unknown", None
        for child in proto.prototypes:
            self.normalize_constants(child)

    def iter_protos(self, proto=None, name="main"):
        if proto is None:
            proto = self.main
        yield name, proto
        for index, child in enumerate(proto.prototypes):
            yield from self.iter_protos(child, f"{name}.{index}")

    def find_proto(self, prefix: str):
        for name, proto in self.iter_protos():
            if name == prefix or name.startswith(prefix + "."):
                yield name, proto

    def stats(self) -> dict:
        protos = list(self.iter_protos())
        instructions = sum(len(p.code) for _, p in protos)
        strings = 0
        numbers = 0
        for _, proto in protos:
            for entry in proto.constants:
                kind, _ = normalize_constant(entry)
                if kind == "string":
                    strings += 1
                elif kind == "number":
                    numbers += 1
        return {
            "prototypes": len(protos),
            "instructions": instructions,
            "string_constants": strings,
            "number_constants": numbers,
        }

    def collect_strings(self, min_len: int = 0):
        found = []
        for name, proto in self.iter_protos():
            for index, entry in enumerate(proto.constants):
                kind, value = normalize_constant(entry)
                if kind == "string" and len(value) >= min_len:
                    found.append((name, index, value))
        return found

    def decode_code(self, proto):
        return [decode(raw) for raw in proto.code]
