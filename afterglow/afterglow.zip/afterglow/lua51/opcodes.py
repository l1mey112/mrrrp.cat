from dataclasses import dataclass

IABC = "iABC"
IABX = "iABx"
IASBX = "iAsBx"

OPCODES = [
    ("MOVE", IABC),
    ("LOADK", IABX),
    ("LOADBOOL", IABC),
    ("LOADNIL", IABC),
    ("GETUPVAL", IABC),
    ("GETGLOBAL", IABX),
    ("GETTABLE", IABC),
    ("SETGLOBAL", IABX),
    ("SETUPVAL", IABC),
    ("SETTABLE", IABC),
    ("NEWTABLE", IABC),
    ("SELF", IABC),
    ("ADD", IABC),
    ("SUB", IABC),
    ("MUL", IABC),
    ("DIV", IABC),
    ("MOD", IABC),
    ("POW", IABC),
    ("UNM", IABC),
    ("NOT", IABC),
    ("LEN", IABC),
    ("CONCAT", IABC),
    ("JMP", IASBX),
    ("EQ", IABC),
    ("LT", IABC),
    ("LE", IABC),
    ("TEST", IABC),
    ("TESTSET", IABC),
    ("CALL", IABC),
    ("TAILCALL", IABC),
    ("RETURN", IABC),
    ("FORLOOP", IASBX),
    ("FORPREP", IASBX),
    ("TFORLOOP", IABC),
    ("SETLIST", IABC),
    ("CLOSE", IABC),
    ("CLOSURE", IABX),
    ("VARARG", IABC),
]

OP_MOVE = 0
OP_LOADK = 1
OP_LOADBOOL = 2
OP_LOADNIL = 3
OP_GETUPVAL = 4
OP_GETGLOBAL = 5
OP_GETTABLE = 6
OP_SETGLOBAL = 7
OP_SETUPVAL = 8
OP_SETTABLE = 9
OP_NEWTABLE = 10
OP_SELF = 11
OP_ARITH_FIRST = 12
OP_ARITH_LAST = 18
OP_UNM = 18
OP_NOT = 19
OP_LEN = 20
OP_CONCAT = 21
OP_JMP = 22
OP_EQ = 23
OP_LT = 24
OP_LE = 25
OP_TEST = 26
OP_TESTSET = 27
OP_CALL = 28
OP_TAILCALL = 29
OP_RETURN = 30
OP_FORLOOP = 31
OP_FORPREP = 32
OP_TFORLOOP = 33
OP_SETLIST = 34
OP_CLOSURE = 36
OP_VARARG = 37

MAXARG_SBX = 131071
RK_OFFSET = 256

OP_NAMES = [name for name, _ in OPCODES]
OP_MODES = [mode for _, mode in OPCODES]

_RK_OPERANDS = {
    OP_GETTABLE,
    OP_SETTABLE,
    OP_SELF,
    OP_EQ,
    OP_LT,
    OP_LE,
} | set(range(OP_ARITH_FIRST, OP_ARITH_LAST))


@dataclass(frozen=True)
class Decoded:
    opcode: int
    A: int
    B: int
    C: int
    Bx: int
    sBx: int


def op_info(op: int):
    if 0 <= op < len(OPCODES):
        return OPCODES[op]
    return (f"OP_{op}", IABC)


def op_name(op: int) -> str:
    return op_info(op)[0]


def op_mode(op: int) -> str:
    return op_info(op)[1]


def uses_rk_operands(op: int) -> bool:
    return op in _RK_OPERANDS


def decode(raw: int) -> Decoded:
    return Decoded(
        opcode=raw & 0x3F,
        A=(raw >> 6) & 0xFF,
        C=(raw >> 14) & 0x1FF,
        B=(raw >> 23) & 0x1FF,
        Bx=(raw >> 14) & 0x3FFFF,
        sBx=((raw >> 14) & 0x3FFFF) - MAXARG_SBX,
    )
