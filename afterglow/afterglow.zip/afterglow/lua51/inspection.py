from . import AVAILABLE, Lua51Dump
from .toolchain import ToolchainError, compile_source

if AVAILABLE:
    from .chunk_format import ChunkFormatError
    from .disassembler import format_instruction
    from .reader import escape_bytes
else:
    ChunkFormatError = Exception

MAX_DISASSEMBLY = 2000
PREVIEW = 120


def of_source(path, workdir):
    if not AVAILABLE:
        return None
    try:
        compiled = compile_source(path, workdir / "source.luc")
    except ToolchainError:
        return None
    return describe(compiled.read_bytes())


def describe(data):
    if not AVAILABLE:
        return None
    try:
        dump = Lua51Dump.from_bytes(data)
    except ChunkFormatError:
        return None

    summary = dump.stats()
    summary["constant_layout"] = dump.variant[0]
    summary["strings"] = [
        {
            "proto": name,
            "index": index,
            "size": len(value),
            "preview": escape_bytes(value[:PREVIEW]),
        }
        for name, index, value in dump.collect_strings(min_len=1)
    ]
    if summary["instructions"] <= MAX_DISASSEMBLY:
        summary["disassembly"] = disassemble(dump)
    return summary


def disassemble(dump):
    listing = []
    for name, proto in dump.iter_protos():
        for pc, raw in enumerate(proto.code):
            listing.append(
                {
                    "proto": name,
                    "pc": pc,
                    "text": format_instruction(proto, pc, raw),
                }
            )
    return listing


def largest_string(summary):
    if not summary or not summary["strings"]:
        return None
    return max(summary["strings"], key=lambda entry: entry["size"])
