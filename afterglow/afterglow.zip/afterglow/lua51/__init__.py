"""Lua 5.1 chunk parsing when `construct` is available."""

try:
    from .chunk_format import parse_chunk
    from .reader import Lua51Dump

    AVAILABLE = True
except ImportError:
    parse_chunk = None
    Lua51Dump = None
    AVAILABLE = False

from .toolchain import ToolchainError, compile_source, dump_source

__version__ = "1.0.0"

__all__ = [
    "parse_chunk",
    "Lua51Dump",
    "compile_source",
    "dump_source",
    "ToolchainError",
    "AVAILABLE",
    "__version__",
]
