from . import opcodes as ops
from .reader import escape_bytes, normalize_constant


def const_preview(proto, index):
    if index < 0 or index >= len(proto.constants):
        return None
    kind, value = normalize_constant(proto.constants[index])
    if kind == "string":
        return f'"{escape_bytes(value)}"'
    if kind == "number":
        return repr(value)
    if kind == "bool":
        return "true" if value else "false"
    return "nil"


def rk(proto, operand):
    if operand >= ops.RK_OFFSET:
        index = operand - ops.RK_OFFSET
        note = const_preview(proto, index)
        text = f"K{index}"
        if note is not None:
            return f"{text}({note})"
        return text
    return f"R{operand}"


def call_counts(ins):
    args = ins.B - 1 if ins.B != 0 else "top"
    returns = ins.C - 1 if ins.C != 0 else "top"
    return f"; {args} args, {returns} returns"


def format_instruction(proto, pc: int, raw: int) -> str:
    ins = ops.decode(raw)
    name, mode = ops.op_info(ins.opcode)
    op = ins.opcode

    if op == ops.OP_MOVE:
        text = f"R{ins.A} := R{ins.B}"
    elif op == ops.OP_LOADK:
        text = f"R{ins.A} := K{ins.Bx}"
        note = const_preview(proto, ins.Bx)
        if note is not None:
            text += f"({note})"
    elif op == ops.OP_LOADBOOL:
        text = f"R{ins.A} := {'true' if ins.B else 'false'}"
        if ins.C:
            text += "; skip next"
    elif op == ops.OP_LOADNIL:
        text = f"R{ins.A}..R{ins.A + ins.B} := nil"
    elif op == ops.OP_GETUPVAL:
        text = f"R{ins.A} := U{ins.B}"
    elif op == ops.OP_GETGLOBAL:
        note = const_preview(proto, ins.Bx)
        text = f"R{ins.A} := _G[{note if note is not None else 'K' + str(ins.Bx)}]"
    elif op == ops.OP_SETGLOBAL:
        note = const_preview(proto, ins.Bx)
        text = f"_G[{note if note is not None else 'K' + str(ins.Bx)}] := R{ins.A}"
    elif op == ops.OP_SETUPVAL:
        text = f"U{ins.B} := R{ins.A}"
    elif op == ops.OP_NEWTABLE:
        text = f"R{ins.A} := {{}}; array={ins.B} hash={ins.C}"
    elif op == ops.OP_CONCAT:
        text = f"R{ins.A} := concat R{ins.B}..R{ins.C}"
    elif op == ops.OP_JMP:
        text = f"=> [{pc + 1 + ins.sBx}]"
    elif op == ops.OP_FORLOOP:
        text = f"R{ins.A} += R{ins.A + 2}; if R{ins.A} <= R{ins.A + 1} => [{pc + 1 + ins.sBx}]"
    elif op == ops.OP_FORPREP:
        text = f"R{ins.A} -= R{ins.A + 2}; => [{pc + 1 + ins.sBx}]"
    elif op == ops.OP_TEST:
        text = f"if (R{ins.A} ~= 0) ~= {ins.C} then pc++"
    elif op == ops.OP_TESTSET:
        text = f"if (R{ins.B} ~= 0) == {ins.C} then R{ins.A} := R{ins.B} else pc++"
    elif op == ops.OP_CALL:
        n_args = ins.B - 1 if ins.B != 0 else None
        args = f"R{ins.A + 1}..R{ins.A + n_args}" if n_args else f"R{ins.A + 1}..top"
        text = f"R{ins.A}({args})"
        text += call_counts(ins)
    elif op == ops.OP_TAILCALL:
        n_args = ins.B - 1 if ins.B != 0 else None
        args = f"R{ins.A + 1}..R{ins.A + n_args}" if n_args else f"R{ins.A + 1}..top"
        text = f"tail R{ins.A}({args}); return"
    elif op == ops.OP_RETURN:
        count = ins.B - 1 if ins.B != 0 else "top"
        text = f"return R{ins.A}(+{count})"
    elif op == ops.OP_TFORLOOP:
        text = f"R{ins.A},R{ins.A + 1} := R{ins.A}(R{ins.A + 1},R{ins.A + 2}); if nil then pc++"
    elif op == ops.OP_SETLIST:
        if ins.B == 0:
            text = f"R{ins.A}[] <- vararg; block={ins.C}"
        else:
            text = f"R{ins.A}[{ins.C * 50}+] <- R{ins.A + 1}..R{ins.A + ins.B}"
    elif op == ops.OP_CLOSURE:
        child = f"{ins.Bx}"
        text = f"R{ins.A} := closure proto[{child}]"
    elif op == ops.OP_VARARG:
        text = f"R{ins.A}.. := vararg({ins.C - 1 if ins.C else 'top'})"
    elif ops.uses_rk_operands(op):
        if op == ops.OP_GETTABLE:
            text = f"R{ins.A} := R{ins.B}[{rk(proto, ins.C)}]"
        elif op == ops.OP_SETTABLE:
            text = f"R{ins.A}[{rk(proto, ins.B)}] := {rk(proto, ins.C)}"
        elif op == ops.OP_SELF:
            text = f"R{ins.A + 1} := R{ins.B}; R{ins.A} := R{ins.B}[{rk(proto, ins.C)}]"
        elif op == ops.OP_EQ:
            text = f"if ({rk(proto, ins.B)} == {rk(proto, ins.C)}) ~= {ins.A} then pc++"
        elif op == ops.OP_LT:
            text = f"if ({rk(proto, ins.B)} < {rk(proto, ins.C)}) ~= {ins.A} then pc++"
        elif op == ops.OP_LE:
            text = f"if ({rk(proto, ins.B)} <= {rk(proto, ins.C)}) ~= {ins.A} then pc++"
        else:
            sym = {
                ops.OP_ARITH_FIRST + 0: "+",
                ops.OP_ARITH_FIRST + 1: "-",
                ops.OP_ARITH_FIRST + 2: "*",
                ops.OP_ARITH_FIRST + 3: "/",
                ops.OP_ARITH_FIRST + 4: "%",
                ops.OP_ARITH_FIRST + 5: "^",
                ops.OP_UNM: "-",
                ops.OP_NOT: "not ",
                ops.OP_LEN: "#",
            }.get(op, "?")
            text = f"R{ins.A} := {rk(proto, ins.B)} {sym} {rk(proto, ins.C)}"
    else:
        text = f"A={ins.A} B={ins.B} C={ins.C}"

    return f"{name:<10} {text}"
