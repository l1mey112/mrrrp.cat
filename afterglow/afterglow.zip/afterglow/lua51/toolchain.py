import os
import shutil
import subprocess
from pathlib import Path

from afterglow.config import BIN_ROOT, RESOURCE_ROOT


class ToolchainError(RuntimeError):
    pass


def is_version_51(tool: Path) -> bool:
    try:
        result = subprocess.run([str(tool), "-v"], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return False
    output = (result.stderr or "") + (result.stdout or "")
    if "LuaJIT" in output:
        return True
    return "5.1" in output and "Lua" in output


def find_tool(name: str) -> Path:
    env = os.environ.get(f"{name.upper()}_BIN")
    if env:
        candidate = Path(env)
        if candidate.is_file():
            return candidate
        raise ToolchainError(f"{env} (from {name.upper()}51_BIN) does not exist")

    vendored = BIN_ROOT / name
    if vendored.is_file() and os.access(vendored, os.X_OK):
        return vendored

    for command in (f"{name}5.1", name):
        found = shutil.which(command)
        if found and is_version_51(Path(found)):
            return Path(found)

    raise ToolchainError(
        f"Lua 5.1 toolchain not found: set {name.upper()}51_BIN, place binaries in "
        f"{BIN_ROOT}, or install lua5.1/luac5.1 on your PATH"
    )


def find_runtime() -> Path:
    try:
        return find_tool("luajit")
    except ToolchainError:
        return find_tool("lua")


def run(command, what: str):
    result = subprocess.run(command, capture_output=True, text=True)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()
        raise ToolchainError(f"{what} failed (exit {result.returncode}): {detail}")


def compile_source(src: Path, out: Path) -> Path:
    luac = find_tool("luac")
    out = out or src.with_suffix(".luc")
    run([str(luac), "-o", str(out), str(src)], f"luac compile of {src}")
    return out


def dump_source(src: Path, out: Path = None) -> Path:
    lua = find_tool("lua")
    helper = RESOURCE_ROOT / "dump_runtime.lua"
    if not helper.is_file():
        raise ToolchainError(f"missing helper script {helper}")
    out = out or src.with_suffix(".luc")
    run([str(lua), str(helper), str(src), str(out)], f"string.dump of {src}")
    return out
