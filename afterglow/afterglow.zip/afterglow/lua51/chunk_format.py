from construct import (
    Byte,
    Bytes,
    Computed,
    Const,
    ExprAdapter,
    Float64b,
    Float64l,
    IfThenElse,
    Int32sb,
    Int32sl,
    Int32ub,
    Int32ul,
    Int64sb,
    Int64sl,
    Int64ub,
    Int64ul,
    LazyBound,
    OneOf,
    PrefixedArray,
    Float32b,
    Float32l,
    Struct,
    Switch,
    this,
)

HEADER_SIZE = 12
LUAC_SIGNATURE = b"\x1bLua"
LUAC_VERSION = 0x51

TAG_NIL = 0
TAG_BOOL = 1

VARIANT_CLASSIC = ("5.1.0-5.1.4", 2, 3)
VARIANT_MODERN = ("5.1.5", 3, 4)

Header = Struct(
    "signature" / Const(LUAC_SIGNATURE),
    "version" / Const(LUAC_VERSION, Byte),
    "format" / Const(0, Byte),
    "little_endian" / OneOf(Byte, [0, 1]),
    "size_int" / OneOf(Byte, [4, 8]),
    "size_size_t" / OneOf(Byte, [4, 8]),
    "size_instruction" / Const(4, Byte),
    "size_number" / OneOf(Byte, [4, 8]),
    "integral_number" / Byte,
)

_INT_TYPES = {
    (4, True, True): Int32sl,
    (4, False, True): Int32sb,
    (4, True, False): Int32ul,
    (4, False, False): Int32ub,
    (8, True, True): Int64sl,
    (8, False, True): Int64sb,
    (8, True, False): Int64ul,
    (8, False, False): Int64ub,
}

_NUMBER_TYPES = {
    (4, True): Float32l,
    (4, False): Float32b,
    (8, True): Float64l,
    (8, False): Float64b,
}


class ChunkFormatError(Exception):
    pass


def lua_string(size_t):
    return ExprAdapter(
        Struct(
            "size" / size_t,
            "raw" / IfThenElse(this.size == 0, Computed(b""), Bytes(this.size)),
        ),
        decoder=lambda obj, context: None if obj.size == 0 else obj.raw[:-1],
        encoder=lambda obj, context: obj,
    )


def constant(number_t, string_t, variant):
    _, number_tag, string_tag = variant
    return Struct(
        "tag" / Byte,
        "value"
        / Switch(
            this.tag,
            {
                TAG_NIL: Computed(None),
                TAG_BOOL: Byte,
                number_tag: number_t,
                string_tag: string_t,
            },
        ),
    )


def make_prototype(int_t, size_t, instr_t, number_t, variant):
    string_t = lua_string(size_t)
    return Struct(
        "source" / string_t,
        "linedefined" / int_t,
        "lastlinedefined" / int_t,
        "num_upvalues" / Byte,
        "num_params" / Byte,
        "is_vararg" / Byte,
        "max_stack" / Byte,
        "code" / PrefixedArray(int_t, instr_t),
        "constants" / PrefixedArray(int_t, constant(number_t, string_t, variant)),
        "prototypes"
        / PrefixedArray(
            int_t,
            LazyBound(lambda: make_prototype(int_t, size_t, instr_t, number_t, variant)),
        ),
        "line_info" / PrefixedArray(int_t, int_t),
        "loc_vars"
        / PrefixedArray(
            int_t,
            Struct(
                "name" / string_t,
                "start_pc" / int_t,
                "end_pc" / int_t,
            ),
        ),
        "upvalue_names" / PrefixedArray(int_t, string_t),
    )


def parse_chunk(data: bytes, variant=VARIANT_MODERN):
    if len(data) < HEADER_SIZE:
        raise ChunkFormatError("file too small to be a Lua 5.1 precompiled chunk")
    try:
        header = Header.parse(data)
    except Exception as exc:
        if not data.startswith(LUAC_SIGNATURE):
            raise ChunkFormatError(
                "not a Lua precompiled chunk (missing '\\x1bLua' signature)"
            ) from exc
        raise ChunkFormatError(f"unsupported or corrupted chunk header: {exc}") from exc

    little = header.little_endian == 1
    int_t = _INT_TYPES[(header.size_int, little, True)]
    size_t = _INT_TYPES[(header.size_size_t, little, False)]
    instr_t = _INT_TYPES[(4, little, False)]
    if header.integral_number:
        number_t = _INT_TYPES[(header.size_number, little, True)]
    else:
        number_t = _NUMBER_TYPES[(header.size_number, little)]

    try:
        proto = make_prototype(int_t, size_t, instr_t, number_t, variant).parse(data[HEADER_SIZE:])
    except ChunkFormatError:
        raise
    except Exception as exc:
        raise ChunkFormatError(
            f"truncated or corrupted prototype data ({variant[0]}): {exc}"
        ) from exc
    return header, proto, variant
