from pathlib import Path

from .models import AnalysisResult
from .pipeline.analyzer import analyze


def analyze_file(path: Path) -> AnalysisResult:
    return analyze(path)
