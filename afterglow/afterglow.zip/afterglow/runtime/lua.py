import os
import subprocess

from afterglow import log
from afterglow.config import RESOURCE_ROOT
from afterglow.errors import LuaError
from afterglow.lua51.toolchain import ToolchainError, find_runtime, find_tool

TIMEOUT = 600

PROGRESS = "[progress]"

active_runner = None


def runner(run):
    global active_runner
    active_runner = run


def flags(shims, api):
    return ",".join(name for name, on in (("shims", shims), ("api", api)) if on)


def compiles_as_51(path):
    if active_runner is not None:
        checker = RESOURCE_ROOT / "compile.lua"
        try:
            active_runner(str(checker), [str(path)])
            return True
        except Exception:
            return False
    try:
        luac = find_tool("luac")
    except ToolchainError:
        return True
    result = subprocess.run([str(luac), "-p", str(path)], capture_output=True, timeout=60)
    return result.returncode == 0


def run(script, args, shims=False, api=False):
    if active_runner is not None:
        return active_runner(str(script), [str(a) for a in args] + [flags(shims, api)])

    try:
        runtime = find_runtime() if shims else find_tool("lua")
    except ToolchainError as exc:
        raise LuaError(str(exc)) from exc

    environment = dict(
        os.environ, afterglow_SHIMS="1" if shims else "0", afterglow_API="1" if api else "0"
    )
    command = [str(runtime), str(script)] + [str(a) for a in args] + [flags(shims, api)]
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        errors="replace",
        env=environment,
    )
    kept = []
    for line in process.stdout:
        line = line.rstrip("\n")
        if line.startswith(PROGRESS):
            log.say(line[len(PROGRESS) :].strip())
        else:
            kept.append(line)
    process.stdout.close()
    if process.wait(timeout=TIMEOUT) != 0:
        raise LuaError("%s failed: %s" % (script.name, "\n".join(kept).strip()))
    return "\n".join(kept)
