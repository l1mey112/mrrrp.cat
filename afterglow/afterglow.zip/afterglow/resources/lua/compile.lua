-- Parse a source file without executing it. The browser uses this because it
-- ships a Lua interpreter, not the separate luac executable.
local source = assert(arg[1], "source path required")
local chunk = loadfile(source)
if chunk == nil then os.exit(1) end
