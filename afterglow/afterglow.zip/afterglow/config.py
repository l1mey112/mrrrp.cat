from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_ROOT.parents[1]
RESOURCE_ROOT = PACKAGE_ROOT / "resources" / "lua"
BIN_ROOT = PROJECT_ROOT / "bin"
VENDOR_ROOT = PROJECT_ROOT / "vendor"
